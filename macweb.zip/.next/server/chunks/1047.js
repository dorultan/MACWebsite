"use strict";
exports.id = 1047;
exports.ids = [1047];
exports.modules = {

/***/ 9672:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_vs02.c6530cb4.png","height":181,"width":162,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA80lEQVR4nAHoABf/AZ/WtAABxe6l7wf3+HEYZ6+R6pxRFf0MCfk1E1oBNcNzcF3YKI0uKSsC3ffuACMIEgDT2df+xTHxcwEAn3X/mvc0AE9WR/0UDw8B8PXx/7OqxgOZCvQAAWetiOBzLlsfwbi3/zE4OAHVzsz/QklMAZDRtuEBbJJ8r1QxUFAKCAj8DhAQBAMA+/z4+vgEr860sAF5lH9L2/r+tFcfRAAPFQ37CP8EBajYwgAzGgxMAQDrAABK9o9RE7v8rjrwGADcHPsA4j0HUqvbW68BAAAAAQCrZv+AGC5m3fj/hi0OCHp24OCaAFeFAWEVZuPUPS+ZAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});

/***/ }),

/***/ 91065:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_vs02.c6530cb4.png","height":181,"width":162,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA80lEQVR4nAHoABf/AZ/WtAABxe6l7wf3+HEYZ6+R6pxRFf0MCfk1E1oBNcNzcF3YKI0uKSsC3ffuACMIEgDT2df+xTHxcwEAn3X/mvc0AE9WR/0UDw8B8PXx/7OqxgOZCvQAAWetiOBzLlsfwbi3/zE4OAHVzsz/QklMAZDRtuEBbJJ8r1QxUFAKCAj8DhAQBAMA+/z4+vgEr860sAF5lH9L2/r+tFcfRAAPFQ37CP8EBajYwgAzGgxMAQDrAABK9o9RE7v8rjrwGADcHPsA4j0HUqvbW68BAAAAAQCrZv+AGC5m3fj/hi0OCHp24OCaAFeFAWEVZuPUPS+ZAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});

/***/ })

};
;