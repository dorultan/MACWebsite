"use strict";
exports.id = 8255;
exports.ids = [8255];
exports.modules = {

/***/ 77954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ footer)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/logo/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.e8ff07cb.png","height":3571,"width":8334,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAYElEQVR42mNYevM154FdD6Snv/zIzfD/v0AMEBf8+imW8+eXeObvX5wM7V++Kcz8/CVj6b03tqu33/edef2VQfz/v6p5v37qAhUIMRxdfot9596HUsenXeP4z8DAwoAGABIFL+yA9PQpAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/assets/img/icons/social_icon01.png
/* harmony default export */ const social_icon01 = ({"src":"/_next/static/media/social_icon01.7090286a.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAe1BMVEVRZvZSZvNSZfNQZfhQZfdLZP9JZP8tV/8LW/9fb+5UZehTZvNSZvNSZvNRZvZRZfZRZvZRZvZRZvZRZvVRZvVRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZfdQZfdQZfZYJ6ZBAAAAJXRSTlMAAAAAAAAAAAABAQoKDlZXY2Rmb3CTmZqusbLKy9vi5OXm9fb3MIZmMgAAAEhJREFUeNoNwgkWQCAUBdBHmWWIyFCIL/tfoe65iLlgTPAI+XxofU4ZevIBddi9sla9Gx6XrEvqbhBd4UeQZmja0UigLoGiwg/GNwWASfWUkQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/icons/social_icon02.png
/* harmony default export */ const social_icon02 = ({"src":"/_next/static/media/social_icon02.42e0ce6b.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAx0lEQVR42jWOPQrCQBCFRyLkAiL4k6hRoxBBrAXBTqy8QGoRvISNYGlhv7vByt7SK3gAe/sZrJQkvpDkwbLDm++9XSrVUmwTNL2K7RlZ+5HUto9PhTzNx4HhWQl2NN/bilNH83to+Ew9zcrVnHa1HPqGQwczgMQBhPCOYJ5gwJS0WMb5LPE4kgkFEQeolRziH6AvbjTyk0qhZV8skuL9dGR4SZn8iOegL5mZHfznhcCKoIZiKwPqADaultBDanGTKkFNJRYR0R/b3HrQhgC2sQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/icons/social_icon03.png
/* harmony default export */ const social_icon03 = ({"src":"/_next/static/media/social_icon03.b43fb284.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBUlEQVR42gVAv0rDQBj/fZe7tE2DbRU0tlAIGMTFQdE8gZuLoy46Ooibm6hD3Qq6OPgGbj6BiIJTVwf/DEaLlVQotFZIc9d8hTb2W0fJl2mEfkHNuhKOYVjfCcTNn54OcUq7a4+jrUPPXvALPPoZkGJgql7m/kuPfvfejNhc7KsVP+N455YcM4SjB+Dnd6otOVzetqUMqx8odSWtN+uwTIQMhH+3At3ukD1vsZxTHZayRmCDNM0gQMhZKTICcmIIocYxUdVjemggPyOQLwLW5QVsr8Ky1yUBt6WhI8LBNXNRAXkFp3nG/BmR9fRqJILgGMnVOZJViXGJERvQXYzsvq3tYPlkAsbqZKiRfpaJAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/icons/social_icon04.png
/* harmony default export */ const social_icon04 = ({"src":"/_next/static/media/social_icon04.0330f236.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA60lEQVR42g3IsS4EURSA4f9cM3eWRGKQLSdRyTQSQTE2UWg9CA/gVTaZXqXwADqJrFGIxrI62YYQdpBds+bunMtXfgKwczZMgXxOJIsEDFx/qz8EBrJx+pT+Z69lJC4bT98pIGxZKT10TKiaj5zGl2VdL+Ppri1wtbtSrwrxh9M8eKs12543nOy3bbJkaS+GfE7Vno8dm6FkJmyU8rdh+F6hjSMMAx5fJjCZEaknaKkWNz9+7+J2VB8/f9mDdUf/tapBrZs1hST5fWqhZ4X4wXlwShQZEiNlBR0BSLp3qYE8gswKTKEYK0fA4A/pomYdh+fb2AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/payment_card.png
/* harmony default export */ const payment_card = ({"src":"/_next/static/media/payment_card.9a55f242.png","height":29,"width":314,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAK0lEQVR4nGN8+uDaC6HPBx+fe/qZrfW+PdNUL5l/vFxs/75cv/772qoF8gBR/hNvLhFJ4gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./src/layout/footer/footer.tsx










const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "footer-style-one",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "footer__top-wrap",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-5 col-md-7",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "footer-logo logo",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/contact",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: logo,
                                                    alt: "Logo",
                                                    width: 177,
                                                    height: 40
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "footer-text",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "desc",
                                                    children: "Lorem ipsum dolor sitamet consectur adipiscing Duis esollici tudin augue euismod. Nulla ullam dolor sitamet consectetur"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                    className: "social-title",
                                                    children: [
                                                        "Active ",
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                "With Us ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fas fa-angle-double-right"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "footer-social",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: social_icon01,
                                                                alt: "iocn",
                                                                width: 30,
                                                                height: 30
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: social_icon02,
                                                                alt: "iocn",
                                                                width: 30,
                                                                height: 30
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: social_icon03,
                                                                alt: "iocn",
                                                                width: 30,
                                                                height: 30
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                src: social_icon04,
                                                                alt: "iocn",
                                                                width: 30,
                                                                height: 30
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-2 col-lg-3 col-md-5 col-sm-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-widget widget_nav_menu",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "fw-title",
                                            children: "quick link"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list-wrap menu",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Gaming"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Product"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "All NFTs"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Social Network"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Domain Names"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Collectibles"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-2 col-lg-3 col-md-5 col-sm-6",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-widget widget_nav_menu",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "fw-title",
                                            children: "Supports"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list-wrap menu",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Setting & Privacy"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Help & Support"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Live Auctions"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Item Details"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "24/7 Supports"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        children: "Our News"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-5 col-md-7",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "footer-widget",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "fw-title",
                                            children: "Newsletter"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "footer-newsletter",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Subscribe our newsletter to get our latest update & newsconsectetur"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                    action: "#",
                                                    className: "footer-newsletter-form",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "email",
                                                            placeholder: "Your email address"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            type: "submit",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "flaticon-paper-plane"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "copyright__wrap",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-md-7",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "copyright__text",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            "Copyright \xa9 ",
                                            new Date().getFullYear(),
                                            " - All Rights Reserved By ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Mykd"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-md-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "copyright__card text-center text-md-end",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: payment_card,
                                        alt: "img"
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const footer = (Footer);


/***/ }),

/***/ 67089:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/social_icon01.7090286a.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAe1BMVEVRZvZSZvNSZfNQZfhQZfdLZP9JZP8tV/8LW/9fb+5UZehTZvNSZvNSZvNRZvZRZfZRZvZRZvZRZvZRZvVRZvVRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZvZRZfdQZfdQZfZYJ6ZBAAAAJXRSTlMAAAAAAAAAAAABAQoKDlZXY2Rmb3CTmZqusbLKy9vi5OXm9fb3MIZmMgAAAEhJREFUeNoNwgkWQCAUBdBHmWWIyFCIL/tfoe65iLlgTPAI+XxofU4ZevIBddi9sla9Gx6XrEvqbhBd4UeQZmja0UigLoGiwg/GNwWASfWUkQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 19604:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/social_icon02.42e0ce6b.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAx0lEQVR42jWOPQrCQBCFRyLkAiL4k6hRoxBBrAXBTqy8QGoRvISNYGlhv7vByt7SK3gAe/sZrJQkvpDkwbLDm++9XSrVUmwTNL2K7RlZ+5HUto9PhTzNx4HhWQl2NN/bilNH83to+Ew9zcrVnHa1HPqGQwczgMQBhPCOYJ5gwJS0WMb5LPE4kgkFEQeolRziH6AvbjTyk0qhZV8skuL9dGR4SZn8iOegL5mZHfznhcCKoIZiKwPqADaultBDanGTKkFNJRYR0R/b3HrQhgC2sQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 21345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/social_icon03.b43fb284.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABBUlEQVR42gVAv0rDQBj/fZe7tE2DbRU0tlAIGMTFQdE8gZuLoy46Ooibm6hD3Qq6OPgGbj6BiIJTVwf/DEaLlVQotFZIc9d8hTb2W0fJl2mEfkHNuhKOYVjfCcTNn54OcUq7a4+jrUPPXvALPPoZkGJgql7m/kuPfvfejNhc7KsVP+N455YcM4SjB+Dnd6otOVzetqUMqx8odSWtN+uwTIQMhH+3At3ukD1vsZxTHZayRmCDNM0gQMhZKTICcmIIocYxUdVjemggPyOQLwLW5QVsr8Ky1yUBt6WhI8LBNXNRAXkFp3nG/BmR9fRqJILgGMnVOZJViXGJERvQXYzsvq3tYPlkAsbqZKiRfpaJAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 48796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/social_icon04.0330f236.png","height":200,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA60lEQVR42g3IsS4EURSA4f9cM3eWRGKQLSdRyTQSQTE2UWg9CA/gVTaZXqXwADqJrFGIxrI62YYQdpBds+bunMtXfgKwczZMgXxOJIsEDFx/qz8EBrJx+pT+Z69lJC4bT98pIGxZKT10TKiaj5zGl2VdL+Ppri1wtbtSrwrxh9M8eKs12543nOy3bbJkaS+GfE7Vno8dm6FkJmyU8rdh+F6hjSMMAx5fJjCZEaknaKkWNz9+7+J2VB8/f9mDdUf/tapBrZs1hST5fWqhZ4X4wXlwShQZEiNlBR0BSLp3qYE8gswKTKEYK0fA4A/pomYdh+fb2AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 45843:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/payment_card.9a55f242.png","height":29,"width":314,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAK0lEQVR4nGN8+uDaC6HPBx+fe/qZrfW+PdNUL5l/vFxs/75cv/772qoF8gBR/hNvLhFJ4gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":1});

/***/ })

};
;