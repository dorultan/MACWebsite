exports.id = 4250;
exports.ids = [4250];
exports.modules = {

/***/ 14205:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 47734, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 88709, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7833, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 62698, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 29150, 23))

/***/ }),

/***/ 24993:
/***/ (() => {



/***/ }),

/***/ 68328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vivus__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27293);
/* harmony import */ var vivus__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vivus__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const SvgIconCom = ({ icon, id })=>{
    const svgRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const currentSvgRef = svgRef.current;
        if (currentSvgRef) {
            const vivusInstance = new (vivus__WEBPACK_IMPORTED_MODULE_2___default())(currentSvgRef, {
                duration: 180,
                file: icon.src
            });
            const handleMouseEnter = ()=>{
                vivusInstance.reset().play();
            };
            currentSvgRef.addEventListener("mouseenter", handleMouseEnter);
            return ()=>{
                currentSvgRef.removeEventListener("mouseenter", handleMouseEnter);
            };
        }
    }, [
        icon.src
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "svg-icon",
        id: id,
        ref: svgRef
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconCom);


/***/ }),

/***/ 2305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ header)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/data/menu-data.ts
// type
const menu_data = [
    {
        id: 1,
        title: "Home",
        link: "/"
    },
    {
        id: 3,
        title: "Arcade Arena",
        link: "#"
    },
    {
        id: 2,
        title: "TOURNAMENT",
        link: "#"
    },
    {
        id: 3,
        title: "Roadmap",
        link: "/roadmap"
    },
    {
        id: 3,
        title: "ABOUT US",
        link: "/about"
    },
    //{
    //  id:5,
    //  title:'News',
    //  link:'#',
    //  sub_menu:[
    //    {title:'Our Blog',link:'/blog'},
    //    {title:'Blog Details',link:'/blog-details'}
    //  ]
    //},
    {
        id: 6,
        title: "CONTACT",
        link: "/contact"
    }
];
/* harmony default export */ const data_menu_data = (menu_data);

// EXTERNAL MODULE: ./public/assets/img/logo/logo.png
var logo = __webpack_require__(62294);
;// CONCATENATED MODULE: ./src/hooks/use-sticky.ts
/* __next_internal_client_entry_do_not_use__ default auto */ 
const useSticky = ()=>{
    const [sticky, setSticky] = (0,react_.useState)(false);
    const [isStickyVisible, setIsStickyVisible] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        const headerElement = document.getElementById("sticky-header");
        const headerHeight = headerElement?.offsetHeight || 0;
        const handleScroll = ()=>{
            const windowTop = window.scrollY;
            if (windowTop >= headerHeight) {
                setSticky(true);
            } else {
                setSticky(false);
                setIsStickyVisible(false);
            }
            if (sticky) {
                if (windowTop < lastScrollTop) {
                    setIsStickyVisible(true);
                } else {
                    setIsStickyVisible(false);
                }
            }
            lastScrollTop = windowTop;
        };
        let lastScrollTop = 0;
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, [
        sticky
    ]);
    return {
        sticky,
        isStickyVisible
    };
};
/* harmony default export */ const use_sticky = (useSticky);

// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./src/app/components/common/search-popup.tsx


const SearchPopup = ({ isSearchOpen, setIsSearchOpen })=>{
    // handle close search
    const handleCloseSearch = (audioPath)=>{
        setIsSearchOpen(false);
        const audio = new Audio(audioPath);
        audio.play();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `search__popup-wrap ${isSearchOpen ? "search__active" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "search__layer"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "search__close",
                onClick: ()=>handleCloseSearch("/assets/audio/remove.wav"),
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "flaticon-swords-in-cross-arrangement"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "search__wrap text-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-12",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                    className: "title",
                                    children: [
                                        "... ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Search Here"
                                        }),
                                        " ..."
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "search__form",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                        action: "#",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "text",
                                                name: "search",
                                                placeholder: "Type keywords here",
                                                required: true
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: "search-btn",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "flaticon-loupe"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const search_popup = (SearchPopup);

;// CONCATENATED MODULE: ./src/data/social-data.ts
// type 
const social_data = [
    {
        id: 2,
        link: "https://twitter.com/metaarcadeclub",
        imagePath: "/assets/img/icons/social_icon02.png",
        altText: "Twitter Icon",
        title: "Twitter"
    },
    {
        id: 3,
        link: "https://discord.gg/gNU6xj6tPf",
        imagePath: "/assets/img/icons/social_icon01.png",
        altText: "Discord Icon",
        title: "Discord"
    },
    {
        id: 4,
        link: "https://www.instagram.com/metaarcadeclub/",
        imagePath: "/assets/img/icons/social_icon03.png",
        altText: "Instagram Icon",
        title: "Instagram"
    }
];
/* harmony default export */ const data_social_data = (social_data);

;// CONCATENATED MODULE: ./src/app/components/common/off-canvas.tsx






const OffCanvas = ({ isOffCanvasOpen, setIsOffCanvasOpen })=>{
    // handle close search
    const handleCloseOffCanvas = (audioPath)=>{
        setIsOffCanvasOpen(false);
        const audio = new Audio(audioPath);
        audio.play();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${isOffCanvasOpen ? "offCanvas__menu-visible" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "offCanvas__wrap",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "offCanvas__body",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "offCanvas__top",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "offCanvas__logo logo",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: logo["default"],
                                            alt: "Logo",
                                            width: 177,
                                            height: 40
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "offCanvas__toggle",
                                    onClick: ()=>handleCloseOffCanvas("/assets/audio/remove.wav"),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "flaticon-swords-in-cross-arrangement"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "offCanvas__content",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                    className: "title",
                                    children: [
                                        "Best Seller of Month Ideas for ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "NFT Wallet"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "offCanvas__contact",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "small-title",
                                            children: "CONTACT US"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "offCanvas__contact-list list-wrap",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "tel:93332225557",
                                                        children: "+9 333 222 5557"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "mailto:info@webmail.com",
                                                        children: "info@webmail.com"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "New Central Park W7 Street,New York"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "offCanvas__newsletter",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "small-title",
                                            children: "Subscribe"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                            action: "#",
                                            className: "offCanvas__newsletter-form",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "email",
                                                    placeholder: "Get News & Updates"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    type: "submit",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "flaticon-send"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Subscribe dolor sitamet, consectetur adiping eli. Duis esollici tudin augue."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "offCanvas__social list-wrap",
                                    children: data_social_data.map((s, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: s.link,
                                                target: "_blank",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: s.imagePath,
                                                    alt: s.altText
                                                })
                                            })
                                        }, i))
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "offCanvas__copyright",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "Copyright \xa9 ",
                                    new Date().getFullYear(),
                                    " - By ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "MYKD"
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: ()=>setIsOffCanvasOpen(false),
                className: "offCanvas__overlay"
            })
        ]
    });
};
/* harmony default export */ const off_canvas = (OffCanvas);

;// CONCATENATED MODULE: ./src/app/components/common/mobile-menus.tsx




const MobileMenus = ()=>{
    const [navTitle, setNavTitle] = (0,react_.useState)("");
    //openMobileMenu
    const openMobileMenu = (menu, audioPath)=>{
        const audio = new Audio(audioPath);
        audio.play();
        if (navTitle === menu) {
            setNavTitle("");
        } else {
            setNavTitle(menu);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "navigation",
        children: data_menu_data.map((menu, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
                children: [
                    menu.sub_menu && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "menu-item-has-children",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: menu.link,
                                children: menu.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: "sub-menu",
                                style: {
                                    display: navTitle === menu.title ? "block" : "none"
                                },
                                children: menu.sub_menu.map((sub, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: sub.link,
                                            children: sub.title
                                        })
                                    }, i))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onClick: ()=>openMobileMenu(menu.title, "/assets/audio/click.wav"),
                                className: `dropdown-btn ${navTitle === menu.title ? "open" : ""}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "plus-line"
                                })
                            })
                        ]
                    }),
                    !menu.sub_menu && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: menu.link,
                            children: menu.title
                        })
                    })
                ]
            }, i))
    });
};
/* harmony default export */ const mobile_menus = (MobileMenus);

;// CONCATENATED MODULE: ./src/app/components/common/mobile-offcanvas.tsx







const MobileOffCanvas = ({ openMobileOffCanvas, setOpenMobileOffCanvas })=>{
    // handle close search
    const handleCloseOffCanvas = (audioPath)=>{
        setOpenMobileOffCanvas(false);
        const audio = new Audio(audioPath);
        audio.play();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: openMobileOffCanvas ? "mobile-menu-visible" : "",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tgmobile__menu",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    className: "tgmobile__menu-box",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "close-btn",
                            onClick: ()=>handleCloseOffCanvas("/assets/audio/remove.wav"),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "flaticon-swords-in-cross-arrangement"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "nav-logo",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: logo["default"],
                                    alt: "Logo",
                                    style: {
                                        height: "auto"
                                    }
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "tgmobile__search",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                action: "#",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        placeholder: "Search here..."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "flaticon-loupe"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "tgmobile__menu-outer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(mobile_menus, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "social-links",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: "list-wrap",
                                children: data_social_data.map((s, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: s.link,
                                            target: "_blank",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: s.imagePath,
                                                alt: s.altText
                                            })
                                        })
                                    }, i))
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tgmobile__menu-backdrop",
                onClick: ()=>setOpenMobileOffCanvas(false)
            })
        ]
    });
};
/* harmony default export */ const mobile_offcanvas = (MobileOffCanvas);

// EXTERNAL MODULE: ./src/app/components/common/svg-icon-anim.tsx
var svg_icon_anim = __webpack_require__(68328);
;// CONCATENATED MODULE: ./public/assets/img/icons/shape02.svg
/* harmony default export */ const shape02 = ({"src":"/_next/static/media/shape02.44943d17.svg","height":47,"width":152,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/layout/header/header.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 












const Header = ({ style_2 = false })=>{
    const { sticky, isStickyVisible } = use_sticky();
    const pathname = (0,navigation.usePathname)();
    const [isSearchOpen, setIsSearchOpen] = (0,react_.useState)(false);
    const [isOffCanvasOpen, setIsOffCanvasOpen] = (0,react_.useState)(false);
    const [openMobileOffCanvas, setOpenMobileOffCanvas] = (0,react_.useState)(false);
    // handle open search
    const handleOpenSearch = (audioPath)=>{
        setIsSearchOpen(true);
        const audio = new Audio(audioPath);
        audio.play();
    };
    // handle open offcanvas
    const handleOpenOffCanvas = (audioPath)=>{
        setIsOffCanvasOpen(true);
        const audio = new Audio(audioPath);
        audio.play();
    };
    // handle open search
    const handleOpenMobileOffCanvas = (audioPath)=>{
        setOpenMobileOffCanvas(true);
        const audio = new Audio(audioPath);
        audio.play();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "sticky-header",
                className: `tg-header__area transparent-header ${sticky ? "tg-sticky-menu" : ""} ${isStickyVisible ? "sticky-menu__show" : ""}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container custom-container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-12",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "mobile-nav-toggler",
                                    onClick: ()=>handleOpenMobileOffCanvas("/assets/audio/click.wav"),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fas fa-bars"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "tgmenu__wrap",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                        className: "tgmenu__nav",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "logo",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: logo["default"],
                                                        alt: "Logo",
                                                        style: {
                                                            height: "auto"
                                                        }
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "tgmenu__navbar-wrap tgmenu__main-menu d-none d-xl-flex",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                    className: "navigation",
                                                    children: data_menu_data.map((menu)=>menu.sub_menu ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: `menu-item ${menu.sub_menu && menu.sub_menu.some((sub)=>pathname === sub.link) ? "menu-item-has-children active" : ""}`,
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "#",
                                                                    children: menu.title
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                                    className: "sub-menu",
                                                                    children: menu.sub_menu.map((sub, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                            className: pathname === sub.link ? "active" : "",
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                href: sub.link,
                                                                                children: sub.title
                                                                            })
                                                                        }, i))
                                                                })
                                                            ]
                                                        }, menu.id) : /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: pathname === menu.link ? "active" : "",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: menu.link,
                                                                children: menu.title
                                                            })
                                                        }, menu.id))
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "tgmenu__action d-none d-md-block",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-wrap",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "search",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                onClick: ()=>handleOpenSearch("/assets/audio/click.wav"),
                                                                className: "cursor-pointer",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "flaticon-search-1"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                            className: "header-btn",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                                href: "https://phantom.app/",
                                                                className: `${style_2 ? "tg-btn-3 tg-svg" : "tg-border-btn"}`,
                                                                children: [
                                                                    style_2 && /*#__PURE__*/ jsx_runtime_.jsx(svg_icon_anim["default"], {
                                                                        icon: shape02,
                                                                        id: "svg-2"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "flaticon-edit"
                                                                    }),
                                                                    "Wallet"
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "side-toggle-icon",
                                                            onClick: ()=>handleOpenMobileOffCanvas("/assets/audio/click.wav"),
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(search_popup, {
                setIsSearchOpen: setIsSearchOpen,
                isSearchOpen: isSearchOpen
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(off_canvas, {
                isOffCanvasOpen: isOffCanvasOpen,
                setIsOffCanvasOpen: setIsOffCanvasOpen
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(mobile_offcanvas, {
                openMobileOffCanvas: openMobileOffCanvas,
                setOpenMobileOffCanvas: setOpenMobileOffCanvas
            })
        ]
    });
};
/* harmony default export */ const header = (Header);


/***/ }),

/***/ 24797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ wrapper)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./src/utils/utils.ts
const animationCreate = ()=>{
    if (false) {}
};

;// CONCATENATED MODULE: ./src/lib/back-to-top.ts
function BackToTop(value) {
    const result = document.querySelector(value);
    if (result) {
        document.addEventListener("scroll", ()=>{
            if (window.scrollY > 200) {
                result.classList.add("open");
            } else {
                result.classList.remove("open");
            }
        });
        result.addEventListener("click", ()=>{
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        });
    }
}

;// CONCATENATED MODULE: ./src/app/components/common/back-to-top-com.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


function BackToTopCom() {
    (0,react_.useEffect)(()=>{
        BackToTop(".scroll__top");
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "scroll__top scroll-to-target",
        "data-target": "html",
        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
            className: "flaticon-right-arrow"
        })
    });
}
/* harmony default export */ const back_to_top_com = (BackToTopCom);

// EXTERNAL MODULE: ./node_modules/react-toastify/dist/react-toastify.esm.mjs
var react_toastify_esm = __webpack_require__(93578);
;// CONCATENATED MODULE: ./src/context/app-context.tsx


const AppContext = /*#__PURE__*/ (0,react_.createContext)({});
const useAppContext = ()=>{
    const context = (0,react_.useContext)(AppContext);
    if (!context) {
        console.log("useAppContext must be used within an AppContextProvider");
    }
    return context;
};
const ContextProvider = ({ children })=>{
    const [isEnter, setIsEnter] = (0,react_.useState)(false);
    // handle mouse enter
    const handleMouseEnter = ()=>{
        setIsEnter(true);
    };
    // handle leave
    const handleMouseLeave = ()=>{
        setIsEnter(false);
    };
    const values = {
        isEnter,
        handleMouseEnter,
        handleMouseLeave
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(AppContext.Provider, {
        value: values,
        children: children
    });
};
/* harmony default export */ const app_context = (ContextProvider);

;// CONCATENATED MODULE: ./src/app/components/common/animated-mouse.tsx



const AnimateMouse = ()=>{
    const { isEnter } = useAppContext();
    const eRef = (0,react_.useRef)(null);
    const tRef = (0,react_.useRef)(null);
    const nRef = (0,react_.useRef)(0);
    const iRef = (0,react_.useRef)(0);
    const oRef = (0,react_.useRef)(false);
    (0,react_.useEffect)(()=>{
        const handleMouseMove = (s)=>{
            if (!oRef.current) {
                if (tRef.current) {
                    tRef.current.style.transform = `translate(${s.clientX}px, ${s.clientY}px)`;
                }
            }
            if (eRef.current) {
                eRef.current.style.transform = `translate(${s.clientX}px, ${s.clientY}px)`;
            }
            nRef.current = s.clientY;
            iRef.current = s.clientX;
        };
        window.addEventListener("mousemove", handleMouseMove);
        return ()=>{
            window.removeEventListener("mousemove", handleMouseMove);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                ref: eRef,
                style: {
                    visibility: "visible"
                },
                className: `mouseCursor cursor-outer ${isEnter ? "cursor-big" : ""}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                ref: tRef,
                className: `mouseCursor cursor-inner ${isEnter ? "cursor-big" : ""}`,
                style: {
                    visibility: "visible"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    children: [
                        "View ",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        " Image"
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const animated_mouse = (AnimateMouse);

;// CONCATENATED MODULE: ./src/layout/wrapper.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






if (false) {}
const Wrapper = ({ children })=>{
    (0,react_.useEffect)(()=>{
        animationCreate();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(app_context, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(animated_mouse, {}),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(back_to_top_com, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(react_toastify_esm/* ToastContainer */.Ix, {})
        ]
    });
};
/* harmony default export */ const wrapper = (Wrapper);


/***/ }),

/***/ 16660:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_local_target_css_path_src_app_layout_tsx_import_arguments_src_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff_weight_normal_style_normal_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff2_weight_normal_style_normal_variable_tg_berlin_font_family_variableName_berlin___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(54823);
/* harmony import */ var next_font_local_target_css_path_src_app_layout_tsx_import_arguments_src_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff_weight_normal_style_normal_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff2_weight_normal_style_normal_variable_tg_berlin_font_family_variableName_berlin___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_local_target_css_path_src_app_layout_tsx_import_arguments_src_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff_weight_normal_style_normal_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff2_weight_normal_style_normal_variable_tg_berlin_font_family_variableName_berlin___WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Poppins_arguments_weight_400_500_600_700_800_900_subsets_latin_variable_tg_body_font_family_variableName_poppins___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71659);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Poppins_arguments_weight_400_500_600_700_800_900_subsets_latin_variable_tg_body_font_family_variableName_poppins___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_app_layout_tsx_import_Poppins_arguments_weight_400_500_600_700_800_900_subsets_latin_variable_tg_body_font_family_variableName_poppins___WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Barlow_arguments_weight_300_400_500_600_700_800_900_subsets_latin_variable_tg_heading_font_family_variableName_barlow___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7814);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Barlow_arguments_weight_300_400_500_600_700_800_900_subsets_latin_variable_tg_heading_font_family_variableName_barlow___WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_app_layout_tsx_import_Barlow_arguments_weight_300_400_500_600_700_800_900_subsets_latin_variable_tg_heading_font_family_variableName_barlow___WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _globals_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39675);
/* harmony import */ var _globals_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_scss__WEBPACK_IMPORTED_MODULE_1__);





const metadata = {
    title: "Meta Arcade Club",
    description: "Grab the pixel key to unlock the playground"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            suppressHydrationWarning: true,
            className: `${(next_font_local_target_css_path_src_app_layout_tsx_import_arguments_src_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff_weight_normal_style_normal_path_public_assets_fonts_berlin_sans_fb_demi_bold_webfont_woff2_weight_normal_style_normal_variable_tg_berlin_font_family_variableName_berlin___WEBPACK_IMPORTED_MODULE_2___default().variable)} ${(next_font_google_target_css_path_src_app_layout_tsx_import_Poppins_arguments_weight_400_500_600_700_800_900_subsets_latin_variable_tg_body_font_family_variableName_poppins___WEBPACK_IMPORTED_MODULE_3___default().variable)} ${(next_font_google_target_css_path_src_app_layout_tsx_import_Barlow_arguments_weight_300_400_500_600_700_800_900_subsets_latin_variable_tg_heading_font_family_variableName_barlow___WEBPACK_IMPORTED_MODULE_4___default().variable)}`,
            children: children
        })
    });
}


/***/ }),

/***/ 20685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\layout\header\header.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 9286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\layout\wrapper.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 62294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.e8ff07cb.png","height":3571,"width":8334,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAYElEQVR42mNYevM154FdD6Snv/zIzfD/v0AMEBf8+imW8+eXeObvX5wM7V++Kcz8/CVj6b03tqu33/edef2VQfz/v6p5v37qAhUIMRxdfot9596HUsenXeP4z8DAwoAGABIFL+yA9PQpAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 82819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23785);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 39675:
/***/ (() => {



/***/ })

};
;