exports.id = 7404;
exports.ids = [7404];
exports.modules = {

/***/ 28346:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 41256));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19604));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67089));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45843));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21345));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48796));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62294));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 703));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24369));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99277));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22803));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1841));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55297));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 437));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58481));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 11265))

/***/ }),

/***/ 2316:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_18_image_lightbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11230);



const ImageLightBox = ({ images, open, setOpen, photoIndex, setPhotoIndex })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_18_image_lightbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            mainSrc: images[photoIndex],
            nextSrc: images[(photoIndex + 1) % images.length],
            prevSrc: images[(photoIndex + images.length - 1) % images.length],
            onCloseRequest: ()=>setOpen(false),
            onMovePrevRequest: ()=>setPhotoIndex((photoIndex + images.length - 1) % images.length),
            onMoveNextRequest: ()=>setPhotoIndex((photoIndex + 1) % images.length)
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageLightBox);


/***/ }),

/***/ 41256:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ shop_details_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/data/product-data.ts
var product_data = __webpack_require__(38990);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/app/components/shop/shop-item.tsx




const ShopItem = ({ item })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "shop__item",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__item-thumb",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/shop-details/${item.id}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: item.img,
                            alt: "img",
                            style: {
                                width: "auto",
                                height: "auto"
                            }
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "#",
                        className: "wishlist-button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "far fa-heart"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "shop__item-line"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__item-content",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "shop__item-content-top",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "title",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: `/shop-details/${item.id}`,
                                    children: item.title
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "shop__item-price",
                                children: [
                                    "$",
                                    item.price
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "shop__item-cat",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/shop",
                            children: item.category
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const shop_item = (ShopItem);

;// CONCATENATED MODULE: ./src/app/components/shop-details/related-products.tsx




const RelatedProducts = ()=>{
    const related_prd = product_data/* default */.Z.slice(0, 4);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "related__product-wrapper",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "related-title",
                children: "Related Products"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row justify-content-center row-cols-xl-4 row-cols-lg-3 row-cols-md-2 row-cols-sm-2 row-cols-1",
                children: related_prd.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(shop_item, {
                            item: item
                        })
                    }, item.id))
            })
        ]
    });
};
/* harmony default export */ const related_products = (RelatedProducts);

;// CONCATENATED MODULE: ./public/assets/img/products/shop_nav01.jpg
/* harmony default export */ const shop_nav01 = ({"src":"/_next/static/media/shop_nav01.455184c2.jpg","height":78,"width":76,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAgwz/AP/EABwQAAEDBQAAAAAAAAAAAAAAABQAAREEExUyQv/aAAgBAQABPwBsCLEVRAe3F9f/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/products/shop_nav02.jpg
/* harmony default export */ const shop_nav02 = ({"src":"/_next/static/media/shop_nav02.07e92225.jpg","height":78,"width":76,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAIIWf//EABwQAAEDBQAAAAAAAAAAAAAAABQAERIEBRMiMv/aAAgBAQABPwB7ELGNUQJ0+mdf/8QAFREBAQAAAAAAAAAAAAAAAAAAADH/2gAIAQIBAT8Ar//EABcRAQADAAAAAAAAAAAAAAAAAAEAEUH/2gAIAQMBAT8AW8J//9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/products/shop_nav03.jpg
/* harmony default export */ const shop_nav03 = ({"src":"/_next/static/media/shop_nav03.25a497ff.jpg","height":78,"width":76,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAgwh//8QAGxAAAgEFAAAAAAAAAAAAAAAAARQAERMVIkL/2gAIAQEAAT8AGBUoW2Uztxfn/8QAFxEBAAMAAAAAAAAAAAAAAAAAAQARQf/aAAgBAgEBPwAK1n//xAAXEQADAQAAAAAAAAAAAAAAAAAAASFh/9oACAEDAQE/AFNP/9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/products/shop_details01.jpg
/* harmony default export */ const shop_details01 = ({"src":"/_next/static/media/shop_details01.11391828.jpg","height":545,"width":537,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAgwj/AP/EABwQAAEDBQAAAAAAAAAAAAAAABIAExQEBSIycv/aAAgBAQABPwA7DFFmqkQ9ywf5X//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/products/shop_details02.jpg
/* harmony default export */ const shop_details02 = ({"src":"/_next/static/media/shop_details02.2cb89cc5.jpg","height":545,"width":537,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAIIWf//EABwQAAEDBQAAAAAAAAAAAAAAABIAExQEBSIycv/aAAgBAQABPwA7FFFmpkRNywf5X//EABURAQEAAAAAAAAAAAAAAAAAAAAx/9oACAECAQE/AK//xAAXEQEAAwAAAAAAAAAAAAAAAAABABFB/9oACAEDAQE/AFvAn//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/products/shop_details03.jpg
/* harmony default export */ const shop_details03 = ({"src":"/_next/static/media/shop_details03.80d59c93.jpg","height":545,"width":537,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAhAh//8QAHRAAAQIHAAAAAAAAAAAAAAAAEhMUAAQFESIyUf/aAAgBAQABPwA6A0FGacs9ywXtyP/EABcRAQADAAAAAAAAAAAAAAAAAAEAEUH/2gAIAQIBAT8ACtZ//8QAFxEAAwEAAAAAAAAAAAAAAAAAAAEhYf/aAAgBAwEBPwBTT//Z","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./src/app/components/common/image-lightbox.tsx
var image_lightbox = __webpack_require__(2316);
;// CONCATENATED MODULE: ./src/app/components/shop-details/shop-details-images.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









const active_images = [
    {
        id: "one",
        img: shop_details01
    },
    {
        id: "two",
        img: shop_details02
    },
    {
        id: "three",
        img: shop_details03
    }
];
const ShopDetailsImages = ()=>{
    // photoIndex
    const [photoIndex, setPhotoIndex] = (0,react_.useState)(0);
    // image open state
    const [open, setOpen] = (0,react_.useState)(false);
    // images
    const images = active_images.map((item)=>item.img.src);
    // handleImagePopup
    const handleImagePopup = (index)=>{
        setPhotoIndex(index);
        setOpen(true);
    };
    const nabImgStyle = {
        width: "auto",
        height: "auto"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__details-images-wrap",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "nav nav-tabs",
                        id: "imageTab",
                        role: "tablist",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item",
                                role: "presentation",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "nav-link active",
                                    id: "one-tab",
                                    "data-bs-toggle": "tab",
                                    "data-bs-target": "#one",
                                    type: "button",
                                    role: "tab",
                                    "aria-controls": "one",
                                    "aria-selected": "true",
                                    tabIndex: -1,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: shop_nav01,
                                        alt: "img",
                                        style: nabImgStyle
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item",
                                role: "presentation",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "nav-link",
                                    id: "two-tab",
                                    "data-bs-toggle": "tab",
                                    "data-bs-target": "#two",
                                    type: "button",
                                    role: "tab",
                                    "aria-controls": "two",
                                    "aria-selected": "false",
                                    tabIndex: -1,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: shop_nav02,
                                        alt: "img",
                                        style: nabImgStyle
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item",
                                role: "presentation",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "nav-link",
                                    id: "three-tab",
                                    "data-bs-toggle": "tab",
                                    "data-bs-target": "#three",
                                    type: "button",
                                    role: "tab",
                                    "aria-controls": "three",
                                    "aria-selected": "false",
                                    tabIndex: -1,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: shop_nav03,
                                        alt: "img",
                                        style: nabImgStyle
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tab-content",
                        id: "imageTabContent",
                        children: active_images.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `tab-pane ${item.id === "one" ? "show active" : ""}`,
                                id: item.id,
                                role: "tabpanel",
                                "aria-labelledby": `${item.id}-tab`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    onClick: ()=>handleImagePopup(i),
                                    className: "popup-image cursor-pointer",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: item.img,
                                        alt: "img",
                                        style: {
                                            height: "auto"
                                        }
                                    })
                                })
                            }, item.id))
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(image_lightbox/* default */.Z, {
                images: images,
                open: open,
                setOpen: setOpen,
                photoIndex: photoIndex,
                setPhotoIndex: setPhotoIndex
            })
        ]
    });
};
/* harmony default export */ const shop_details_images = (ShopDetailsImages);

;// CONCATENATED MODULE: ./src/app/components/shop-details/shop-details-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const ShopDetailsArea = ({ product })=>{
    const [model, setModel] = (0,react_.useState)("Gat");
    const [incValue, setIncValue] = (0,react_.useState)(1);
    //hanle increment 
    const handleIncrement = (value)=>{
        if (value === "inc") {
            setIncValue((prev)=>prev + 1);
        } else {
            if (incValue > 1) {
                setIncValue((prev)=>prev - 1);
            }
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "shop-area shop-details-area",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(shop_details_images, {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "shop__details-content",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "shop__details-rating",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-star"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-star"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-star"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-star"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-star"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "rating-count",
                                                children: "( 3 Customer Review )"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: "game controller"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "shop__details-price",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "amount",
                                            children: [
                                                "$",
                                                product.price.toFixed(2),
                                                " ",
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "stock-status",
                                                    children: [
                                                        "- ",
                                                        product.status
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "shop__details-short-description",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: product.description
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "shop__details-model d-flex align-items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "model m-0",
                                                children: "Model:"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                className: "list-wrap d-flex align-items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        onClick: ()=>setModel("Gat"),
                                                        className: model === "Gat" ? "active" : "",
                                                        children: "Gat"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        onClick: ()=>setModel("dat4"),
                                                        className: model === "dat4" ? "active" : "",
                                                        children: "dat4"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        onClick: ()=>setModel("rt30"),
                                                        className: model === "rt30" ? "active" : "",
                                                        children: "rt30"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "shop__details-qty",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "cart-plus-minus d-flex flex-wrap align-items-center",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                    className: "quantity num-block",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            className: "in-num",
                                                            value: incValue,
                                                            readOnly: true
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "qtybutton-box",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    onClick: ()=>handleIncrement("inc"),
                                                                    className: "plus",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "fas fa-angle-up"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    onClick: ()=>handleIncrement("dec"),
                                                                    className: "minus dis",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "fas fa-angle-down"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "shop__details-cart-btn",
                                                    children: "add to cart"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "shop__details-bottom",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "posted_in",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                        children: "Categories :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: "Gamdias,"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: "Apple,"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: "Huawei"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "tagged_as",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                        children: "Tags :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: "Silver,"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: "Pink,"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: "Green"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "product_share",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                        children: "Share :"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fab fa-facebook-f"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fab fa-twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/shop",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "fab fa-instagram"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "product__desc-wrap",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-tabs",
                                        id: "descriptionTab",
                                        role: "tablist",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                role: "presentation",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "nav-link active",
                                                    id: "description-tab",
                                                    "data-bs-toggle": "tab",
                                                    "data-bs-target": "#description",
                                                    type: "button",
                                                    role: "tab",
                                                    "aria-controls": "description",
                                                    "aria-selected": "true",
                                                    tabIndex: -1,
                                                    children: "Description"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                role: "presentation",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "nav-link",
                                                    id: "info-tab",
                                                    "data-bs-toggle": "tab",
                                                    "data-bs-target": "#info",
                                                    type: "button",
                                                    role: "tab",
                                                    "aria-controls": "info",
                                                    "aria-selected": "false",
                                                    tabIndex: -1,
                                                    children: "Additional Information"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                role: "presentation",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "nav-link",
                                                    id: "reviews-tab",
                                                    "data-bs-toggle": "tab",
                                                    "data-bs-target": "#reviews",
                                                    type: "button",
                                                    role: "tab",
                                                    "aria-controls": "reviews",
                                                    "aria-selected": "false",
                                                    tabIndex: -1,
                                                    children: "Reviews (0)"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "tab-content",
                                        id: "descriptionTabContent",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "tab-pane animation-none fade show active",
                                                id: "description",
                                                role: "tabpanel",
                                                "aria-labelledby": "description-tab",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum solliciin is yaugue euismods Nulla ullaorper. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industries standard dummy text ever since the 1500s."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Do not look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there is not anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "tab-pane animation-none fade",
                                                id: "info",
                                                role: "tabpanel",
                                                "aria-labelledby": "info-tab",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("table", {
                                                    className: "table table-sm",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                        scope: "row",
                                                                        children: "General"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "PS5 Digital Platform"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                        scope: "row",
                                                                        children: "Technical Information"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "Qualcomm Snapdragon XR2"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                        scope: "row",
                                                                        children: "Display"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "3664 x 1920"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                        scope: "row",
                                                                        children: "RAM & Storage"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "8GB/256GB"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                                        scope: "row",
                                                                        children: "Included"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                        children: "PS5 VR Streaming Assistant"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "tab-pane animation-none fade",
                                                id: "reviews",
                                                role: "tabpanel",
                                                "aria-labelledby": "reviews-tab",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "product__desc-review",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "product__desc-review-title mb-15",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                className: "title",
                                                                children: "Customer Reviews (0)"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "left-rc",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                children: "No reviews yet"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "right-rc",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                href: "#",
                                                                children: "Write a review"
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "related__product-area",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(related_products, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const shop_details_area = (ShopDetailsArea);


/***/ }),

/***/ 19450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\shop-details\shop-details-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;