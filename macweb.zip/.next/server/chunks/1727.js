"use strict";
exports.id = 1727;
exports.ids = [1727];
exports.modules = {

/***/ 95027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_text_animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24876);
/* __next_internal_client_entry_do_not_use__ default auto */ 


// faq data 
const faq_data = [
    {
        id: "one",
        active: true,
        title: "How do I participate in the Beta phase of your Pong game?",
        desc: "To participate, you must possess a WL role, be at least level 10 on our Discord server, and be an active community member on Discord and Twitter."
    },
    {
        id: "two",
        title: "What benefits do I get as an NFT holder of your project?",
        desc: "As an NFT holder, you will enjoy revenue shares, reduced/free service use, gain multipliers in our PvE games, and more."
    },
    {
        id: "three",
        title: "Can you explain the Play2Earn system in your PvE games?",
        desc: "In our single-player games, you can earn game coins while playing. The methods of earning differ based on the game."
    },
    {
        id: "four",
        title: "How does the pawnshop service work for NFT holders?",
        desc: "You can pledge your NFT as collateral to receive a loan equal to 50% of its current market value. Repay the loan plus a 18.88% fee within one week to reclaim your NFT."
    },
    {
        id: "five",
        title: "What is the LevelUp zone, and how does Move2Earn function?",
        desc: "LevelUp Zone offers psychological support and a supportive community. The Move2Earn system lets users earn Meta Arcade Coin by engaging in physical activities tracked by the platform."
    },
    {
        id: "six",
        title: "How can I participate in the Leisure Raffle and what are the prizes?",
        desc: "Participate in the Leisure Raffle by purchasing one of the 3333 available tickets. Prizes include all-expenses-paid world trips for 33 lucky winners."
    },
    {
        id: "seven",
        title: "Are there any rewards for top players in your PvP games?",
        desc: "Yes, top players are rewarded through tournaments, leaderboards, collaborations, and more."
    },
    {
        id: "eight",
        title: "What other services can we expect from your utility project in the future?",
        desc: "Future services may include different types of events, metaverse, real-life payments with Meta Arcade Coin, etc."
    },
    {
        id: "nine",
        title: "How can I stay updated on the launch of new games and services?",
        desc: "Stay updated by following our Twitter, being active on our Discord, and checking the announcement channel."
    },
    {
        id: "ten",
        title: "Is your platform compatible with both Web3 and Web2 communities?",
        desc: "Yes, our platform is compatible with both Web3 and Web2 communities."
    }
];
const FaqArea = ()=>{
    const [activeIndex, setActiveIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const handleMouseOver = (index)=>{
        setActiveIndex(index);
    };
    const handleMouseOut = (index)=>{
        setActiveIndex(index);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "faq-area",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row align-items-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-lg-6",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "faq__content-wrap",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "section__title text-start",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "sub-title tg__animate-text",
                                        children: "Players Guidebook"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "title",
                                        children: "Decode the Playground"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_text_animation__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        title: "Answers unveiling the essence of our world."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "faq__wrapper",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "accordion",
                                    id: "accordionExample",
                                    children: faq_data.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "accordion-item",
                                            onClick: ()=>handleMouseOver(i),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "accordion-header",
                                                    id: `heading-${item.id}`,
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                        className: `accordion-button ${item.active ? "" : "collapsed"}`,
                                                        type: "button",
                                                        "data-bs-toggle": "collapse",
                                                        "data-bs-target": `#collapse-${item.id}`,
                                                        "aria-expanded": item.active ? "true" : "false",
                                                        "aria-controls": `collapse-${item.id}`,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "count",
                                                                children: i + 1
                                                            }),
                                                            " ",
                                                            item.title
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    id: `collapse-${item.id}`,
                                                    className: `accordion-collapse collapse ${item.active ? "show" : ""}`,
                                                    "aria-labelledby": `heading-${item.id}`,
                                                    "data-bs-parent": "#accordionExample",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "accordion-body",
                                                        children: item.desc
                                                    })
                                                })
                                            ]
                                        }, i))
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FaqArea);


/***/ }),

/***/ 67279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\faq\faq-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;