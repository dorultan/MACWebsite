exports.id = 2000;
exports.ids = [2000];
exports.modules = {

/***/ 99121:
/***/ ((module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "default", ({
    enumerable: true,
    get: function() {
        return dynamic;
    }
}));
const _interop_require_default = __webpack_require__(95967);
const _react = /*#__PURE__*/ _interop_require_default._(__webpack_require__(18038));
const _loadable = /*#__PURE__*/ _interop_require_default._(__webpack_require__(37701));
// Normalize loader to return the module as form { default: Component } for `React.lazy`.
// Also for backward compatible since next/dynamic allows to resolve a component directly with loader
// Client component reference proxy need to be converted to a module.
function convertModule(mod) {
    return {
        default: (mod == null ? void 0 : mod.default) || mod
    };
}
function dynamic(dynamicOptions, options) {
    const loadableFn = _loadable.default;
    const loadableOptions = {
        // A loading component is not required, so we default it
        loading: (param)=>{
            let { error, isLoading, pastDelay } = param;
            if (!pastDelay) return null;
            if (false) {}
            return null;
        }
    };
    if (typeof dynamicOptions === "function") {
        loadableOptions.loader = dynamicOptions;
    }
    Object.assign(loadableOptions, options);
    const loaderFn = loadableOptions.loader;
    const loader = ()=>loaderFn != null ? loaderFn().then(convertModule) : Promise.resolve(convertModule(()=>null));
    return loadableFn({
        ...loadableOptions,
        loader: loader
    });
}
if ((typeof exports.default === "function" || typeof exports.default === "object" && exports.default !== null) && typeof exports.default.__esModule === "undefined") {
    Object.defineProperty(exports.default, "__esModule", {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dynamic.js.map


/***/ }),

/***/ 37701:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "default", ({
    enumerable: true,
    get: function() {
        return _default;
    }
}));
const _interop_require_default = __webpack_require__(95967);
const _react = /*#__PURE__*/ _interop_require_default._(__webpack_require__(18038));
const _dynamicnossr = __webpack_require__(17531);
function Loadable(options) {
    const opts = Object.assign({
        loader: null,
        loading: null,
        ssr: true
    }, options);
    opts.lazy = /*#__PURE__*/ _react.default.lazy(opts.loader);
    function LoadableComponent(props) {
        const Loading = opts.loading;
        const fallbackElement = /*#__PURE__*/ _react.default.createElement(Loading, {
            isLoading: true,
            pastDelay: true,
            error: null
        });
        const Wrap = opts.ssr ? _react.default.Fragment : _dynamicnossr.NoSSR;
        const Lazy = opts.lazy;
        return /*#__PURE__*/ _react.default.createElement(_react.default.Suspense, {
            fallback: fallbackElement
        }, /*#__PURE__*/ _react.default.createElement(Wrap, null, /*#__PURE__*/ _react.default.createElement(Lazy, props)));
    }
    LoadableComponent.displayName = "LoadableComponent";
    return LoadableComponent;
}
const _default = Loadable; //# sourceMappingURL=loadable.js.map


/***/ }),

/***/ 48154:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

!function(e,t){ true?module.exports=t(__webpack_require__(18038)):0}("undefined"!=typeof self?self:this,(e=>(()=>{"use strict";var t={156:t=>{t.exports=e}},r={};function o(e){var n=r[e];if(void 0!==n)return n.exports;var s=r[e]={exports:{}};return t[e](s,s.exports,o),s.exports}o.d=(e,t)=>{for(var r in t)o.o(t,r)&&!o.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},o.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),o.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var n={};return(()=>{o.r(n),o.d(n,{default:()=>l,useStopwatch:()=>u,useTime:()=>m,useTimer:()=>c});var e=o(156);class t{static expiryTimestamp(e){const t=new Date(e).getTime()>0;return t||console.warn("react-timer-hook: { useTimer } Invalid expiryTimestamp settings",e),t}static onExpire(e){const t=e&&"function"==typeof e;return e&&!t&&console.warn("react-timer-hook: { useTimer } Invalid onExpire settings function",e),t}}class r{static getTimeFromSeconds(e){const t=Math.ceil(e),r=Math.floor(t/86400),o=Math.floor(t%86400/3600),n=Math.floor(t%3600/60);return{totalSeconds:t,seconds:Math.floor(t%60),minutes:n,hours:o,days:r}}static getSecondsFromExpiry(e,t){const r=e-(new Date).getTime();if(r>0){const e=r/1e3;return t?Math.round(e):e}return 0}static getSecondsFromPrevTime(e,t){const r=(new Date).getTime()-e;if(r>0){const e=r/1e3;return t?Math.round(e):e}return 0}static getSecondsFromTimeNow(){const e=new Date;return e.getTime()/1e3-60*e.getTimezoneOffset()}static getFormattedTimeFromSeconds(e,t){const{seconds:o,minutes:n,hours:s}=r.getTimeFromSeconds(e);let i="",a=s;return"12-hour"===t&&(i=s>=12?"pm":"am",a=s%12),{seconds:o,minutes:n,hours:a,ampm:i}}}function s(t,r){const o=(0,e.useRef)();(0,e.useEffect)((()=>{o.current=t})),(0,e.useEffect)((()=>{if(!r)return()=>{};const e=setInterval((()=>{o.current&&o.current()}),r);return()=>clearInterval(e)}),[r])}const i=1e3;function a(e){if(!t.expiryTimestamp(e))return null;const o=r.getSecondsFromExpiry(e),n=Math.floor(1e3*(o-Math.floor(o)));return n>0?n:i}function c(){let{expiryTimestamp:o,onExpire:n,autoStart:c=!0}=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};const[u,m]=(0,e.useState)(o),[l,d]=(0,e.useState)(r.getSecondsFromExpiry(u)),[p,f]=(0,e.useState)(c),[g,S]=(0,e.useState)(c),[T,y]=(0,e.useState)(a(u)),h=(0,e.useCallback)((()=>{t.onExpire(n)&&n(),f(!1),y(null)}),[n]),x=(0,e.useCallback)((()=>{f(!1)}),[]),v=(0,e.useCallback)((function(e){let t=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];y(a(e)),S(t),f(t),m(e),d(r.getSecondsFromExpiry(e))}),[]),F=(0,e.useCallback)((()=>{const e=new Date;e.setMilliseconds(e.getMilliseconds()+1e3*l),v(e)}),[l,v]),b=(0,e.useCallback)((()=>{g?(d(r.getSecondsFromExpiry(u)),f(!0)):F()}),[u,g,F]);return s((()=>{T!==i&&y(i);const e=r.getSecondsFromExpiry(u);d(e),e<=0&&h()}),p?T:null),{...r.getTimeFromSeconds(l),start:b,pause:x,resume:F,restart:v,isRunning:p}}function u(){let{autoStart:t,offsetTimestamp:o}=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};const[n,i]=(0,e.useState)(r.getSecondsFromExpiry(o,!0)||0),[a,c]=(0,e.useState)(new Date),[u,m]=(0,e.useState)(n+r.getSecondsFromPrevTime(a||0,!0)),[l,d]=(0,e.useState)(t);s((()=>{m(n+r.getSecondsFromPrevTime(a,!0))}),l?1e3:null);const p=(0,e.useCallback)((()=>{const e=new Date;c(e),d(!0),m(n+r.getSecondsFromPrevTime(e,!0))}),[n]),f=(0,e.useCallback)((()=>{i(u),d(!1)}),[u]),g=(0,e.useCallback)((function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0,t=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];const o=r.getSecondsFromExpiry(e,!0)||0,n=new Date;c(n),i(o),d(t),m(o+r.getSecondsFromPrevTime(n,!0))}),[]);return{...r.getTimeFromSeconds(u),start:p,pause:f,reset:g,isRunning:l}}function m(){let{format:t}=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};const[o,n]=(0,e.useState)(r.getSecondsFromTimeNow());return s((()=>{n(r.getSecondsFromTimeNow())}),1e3),{...r.getFormattedTimeFromSeconds(o,t)}}function l(t){if((0,e.useEffect)((()=>{console.warn("react-timer-hook: default export useTimer is deprecated, use named exports { useTimer, useStopwatch, useTime } instead")}),[]),t.expiryTimestamp){const e=c(t);return{...e,startTimer:e.start,stopTimer:e.pause,resetTimer:()=>{}}}const r=u(t);return{...r,startTimer:r.start,stopTimer:r.pause,resetTimer:r.reset}}})(),n})()));

/***/ })

};
;