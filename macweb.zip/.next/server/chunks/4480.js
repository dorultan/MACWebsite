exports.id = 4480;
exports.ids = [4480];
exports.modules = {

/***/ 88845:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40961));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68459));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 77613));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95181));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 96174));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23723));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6061));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8957));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49927));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68487));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34316));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28166));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52233));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28552));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19604));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67089));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45843));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21345));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48796));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62294))

/***/ }),

/***/ 36019:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ErrorMsg = ({ msg })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            color: "red"
        },
        children: msg
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorMsg);


/***/ }),

/***/ 28552:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71031);
/* harmony import */ var _common_err_message__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36019);
/* harmony import */ var _utils_toast__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23497);
/* __next_internal_client_entry_do_not_use__ default auto */ 




const BlogCommentForm = ()=>{
    const { register, handleSubmit, formState: { errors }, reset } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__/* .useForm */ .cI)();
    const onSubmit = (data)=>{
        // console.log(data)
        if (data) {
            (0,_utils_toast__WEBPACK_IMPORTED_MODULE_3__/* .notifySuccess */ .t)("Message sent successfully!");
        }
        reset();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        className: "comment-form",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "comment-notes",
                children: "Email address will not be published. Required fields are marked *"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-sm-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_err_message__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                msg: errors.name?.message
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "form-grp",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "text",
                                    placeholder: "Name *",
                                    ...register("name", {
                                        required: `Name is required!`
                                    }),
                                    name: "name"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-sm-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_err_message__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                msg: errors.email?.message
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "form-grp",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "email",
                                    placeholder: "Email *",
                                    ...register("email", {
                                        required: `Email is required!`
                                    }),
                                    name: "email"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "form-grp",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_common_err_message__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        msg: errors.comment?.message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                        ...register("comment", {
                            required: `Comment is required!`
                        }),
                        name: "message",
                        placeholder: "Comment *"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                type: "submit",
                children: "Post Comment"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlogCommentForm);


/***/ }),

/***/ 23497:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   t: () => (/* binding */ notifySuccess)
/* harmony export */ });
/* unused harmony export notifyError */
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93578);

const notifySuccess = (message)=>react_toastify__WEBPACK_IMPORTED_MODULE_0__/* .toast */ .Am.success(message, {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined
    });
const notifyError = (message)=>toast.error(message, {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined
    });



/***/ }),

/***/ 71304:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ blog_details_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/assets/img/blog/comment01.png
/* harmony default export */ const comment01 = ({"src":"/_next/static/media/comment01.e6bc4b9e.png","height":132,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AYOSkwAB/QMpFREGmOnq6DkQDAYAAQIHx22WpmgrHxPXAW+DgykhGRjFBPXoEQfr4QAIEhQAGi0yAKq0u++ZkZs7AZWjpcEeGA8++NbC+kEkHwb5+vkA3wgU+sPX3watv8jCAaa3u/osGAMF38W4ABD/AwAEAf4A/BohAOb2+wChuM77Aam7wvomDfIF8NnMAB4DBgACAgIA0ubmAAIeJgCwy+P7AZ2xusEoEfg++unY+vHIzQYMBQkA4goC+gsaJQa62fPCAbitvykPBNvF/+fjEera6wDm460AHUNnABMcHO+/zOM7AZieiQAi9rMpMRd1mPz89Dnr7sMA9gIRxwEWDmjY5/vXMAR2OhEgVmkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/blog/comment02.png
/* harmony default export */ const comment02 = ({"src":"/_next/static/media/comment02.a7b80782.png","height":132,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AfGxsQD/AAEp/Pv4mOz09Dn5+/wAFw8PxxcVF2j++fnXAeqtrikE//3FtcK9EYSSmAAYFgAAPkFSAFlCRu8pIiQ7AfS2tcHr6+o+YV9h+oKVgQYGBwcAOGR4+nhUUgZ1WFnCAeSlovqhs7EFCQ7/AEQ/PwAFCAgAipWgAJ++xwDJj437Aeapp/p4g3oFTFdMAD1ARADx6OQA2drcAE97jwDSmJf7AfG1s8Hn5uc++gHy+hohGgbq3uAA2drU+goMJAY5MjTCAeyysCkEAQPF+/35EfL+6QDg1NAABAIWADQyO+/y9fQ7AfCvswD8+Pop/g8AmPUF9znTxLwAEQwixzw4RGgA/f3XsHV99N20v28AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/blog/comment03.png
/* harmony default export */ const comment03 = ({"src":"/_next/static/media/comment03.bc910e75.png","height":132,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+Ae/BTwD/AAIpDAgDmPL1+jn09vsAGRUKx/j6/2gCAf/XAeu9TCkGBQLF6ev2EaSy6gDK1AcAdmUNADkvEO/2+P07Aeq6R8EFAwM+ZYK2+jMZVwY6NyoAP3Ga+tisMAYjHwjCAei2Qfr4+PMFPVzMAH5dXAApIRsAPHiJALmSNABGPiX7Aei0L/rl6x8FcKACADLhsAAkPlwA3RYsAGI+8gAtH9j7AeGqAMHrDaI+Axg8+vDp4gYMERQAGx8i+gz0ygYK8XnCAcCJNina6DDF/gQMEUpQTwAKKzoAAeLQAAfmq+8JIMs7Aa16QQC9hr8pI2ZjmEUtDTkfRF4A8+fkxxvhTmgAGUfX/4hsTUrmhN4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/app/components/blog-details/blog-comments.tsx







function CommentBox({ user, name, date, desc }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "comments-box",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "comments-avatar",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: user,
                    alt: "img",
                    style: {
                        height: "auto"
                    }
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "comments-text",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "avatar-name",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h6", {
                                className: "name",
                                children: [
                                    name,
                                    " ",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "#",
                                        className: "comment-reply-link",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-reply"
                                            }),
                                            " Reply"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "date",
                                children: date
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: desc
                    })
                ]
            })
        ]
    });
}
const BlogComments = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "latest-comments",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "list-wrap",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(CommentBox, {
                            user: comment01,
                            name: "John William",
                            date: "September 6, 2023",
                            desc: "Axcepteur sint occaecat atat non proident, sunt culpa officia deserunt mollit anim id est labor umLor emdolor uni enim ad minim veniam quis nostrud today."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "children",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CommentBox, {
                                    user: comment02,
                                    name: "Hanry Foul",
                                    date: "October 12, 2023",
                                    desc: "Axcepteur sint occaecat atat non proident, sunt culpa officia deserunt mollit anim id est labor umLor emdolor uni enim ad minim veniam quis nostrud today."
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(CommentBox, {
                        user: comment03,
                        name: "Luna Rose",
                        date: "December 12, 2022",
                        desc: "Axcepteur sint occaecat atat non proident, sunt culpa officia deserunt mollit anim id est labor umLor emdolor uni enim ad minim veniam quis nostrud today."
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const blog_comments = (BlogComments);

// EXTERNAL MODULE: ./src/app/components/blog/blog-sidebar.tsx + 7 modules
var blog_sidebar = __webpack_require__(86143);
// EXTERNAL MODULE: ./public/assets/img/blog/avatar.jpg
var avatar = __webpack_require__(7721);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21913);
;// CONCATENATED MODULE: ./src/app/components/forms/blog-comment-form.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\forms\blog-comment-form.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const blog_comment_form = (__default__);
// EXTERNAL MODULE: ./public/assets/img/blog/blog_post02.jpg
var blog_post02 = __webpack_require__(18870);
;// CONCATENATED MODULE: ./src/app/components/blog-details/blog-details-area.tsx









const BlogDetailsArea = ({ blog })=>{
    const imgStyle = {
        width: "100%",
        height: "auto"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "blog-area blog-details-area",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row justify-content-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "blog-post-wrapper",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "blog-post-item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "blog-post-thumb",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: blog.img,
                                            alt: "img",
                                            style: imgStyle
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "blog-post-content blog-details-content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "blog-post-meta",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-wrap",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            children: [
                                                                "By",
                                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "#",
                                                                    children: blog.author
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "far fa-calendar-alt"
                                                                }),
                                                                " ",
                                                                blog.date
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "far fa-comments"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: "#",
                                                                    children: blog.comments === 0 ? "No comments" : `${blog.comments} comments`
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "title text-capitalize",
                                                children: blog.title
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Excepteur sint occaecat atat non proident, sunt in culpa qui officia deserunt mollit anim id est labor umLor em ipsum dolor amet, consteur adiscing Duis elentum solliciin is yaugue euismods Nulla ullaorper. Ipsum is simply dummy text of  printing and typeetting industry. Lorem Ipsum has been the industries standsaard sipiscing Duis elementum solliciin. Duis aute irure dolor in repderit in voluptate velit esse cillum dolorliquip ex ea commodo repderit in voluptate consequat nulla ullaorper."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("blockquote", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Duis elentum solliciin is yaugue euismods Nulla ullaorper. Ipsum is simply dummy text of printing and typeetting industry."
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Axcepteur sint occaecat atat non proident, sunt in culpa qui officia deserunt mollit anim id est labor umLor em ipsum dolor amet, consteur adiscing Duis elentum solliciin is yaugue euismods Nulla ullaorper. Ipsum is simply dummy text of printing and typeetting industry. Lorem Ipsum has been the industries standsaard sipiscing Duis elementum solliciin. Duis aute irure dolor in repderit."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Simply dummy text of printing and typeetting industry. Lorem Ipsum has been the industries standsaard sipiscing Duis elementum solliciin.Duis aute irure dolor in repderit."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "blog-details-inner",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                        className: "inner-title",
                                                        children: "nft games android no investment"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Axcepteur sint occaecat atat non proident, sunt in culpa qui officia deserunt mollit anim id est labor umLor em ipsum dolor amet, consteur adiscing Duis elentum solliciin is yaugue euismods Nulla ullaorper. Ipsum is simply dummy text of  printing and typeetting industry. Lorem Ipsum has been the industries standsaard sipiscing Duis elementum solliciin.Duis aute irure dolor in repderit."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "blog-details-inner-img",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: blog_post02/* default */.Z,
                                                    alt: "img",
                                                    style: imgStyle
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Axcepteur sint occaecat atat non proident, sunt in culpa qui officia deserunt mollit anim id est labor umLor em ipsum dolor amet, consteur adiscing Duis elentum solliciin is yaugue euismods Nulla ullaorper. Ipsum is simply dummy text of  printing and typeetting industry."
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "blog-details-bottom",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "row",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "col-xl-6 col-md-7",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "tg-post-tags",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                        className: "tags-title",
                                                                        children: "tags :"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                        className: "list-wrap d-flex flex-wrap align-items-center m-0",
                                                                        children: [
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "#",
                                                                                        children: "Esports"
                                                                                    }),
                                                                                    ","
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                                children: [
                                                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "#",
                                                                                        children: "Fantasy"
                                                                                    }),
                                                                                    ","
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                    href: "#",
                                                                                    children: "game"
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "col-xl-6 col-md-5",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "blog-post-share justify-content-start justify-content-md-end",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                        className: "share",
                                                                        children: "share :"
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                        className: "list-wrap",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                    href: "#",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                                        className: "fab fa-facebook-f"
                                                                                    })
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                    href: "#",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                                        className: "fab fa-twitter"
                                                                                    })
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                    href: "#",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                                        className: "fab fa-linkedin-in"
                                                                                    })
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "blog__avatar-wrap mb-65",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "blog__avatar-img",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: avatar/* default */.Z,
                                                alt: "img"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "blog__avatar-info",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "designation",
                                                children: "Written by"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "name",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "#",
                                                    children: "Kaceytron G."
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Axcepteur sint occaecat atat non proident, sunt culpa officia deserunt mollit anim id est labor umLor emdolor."
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "comments-wrap",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: "comments-wrap-title",
                                        children: "3 Comments"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(blog_comments, {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "comment-respond",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "comment-reply-title",
                                        children: "Leave a Reply"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(blog_comment_form, {})
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "blog-post-sidebar",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(blog_sidebar/* default */.Z, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const blog_details_area = (BlogDetailsArea);


/***/ }),

/***/ 68459:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/comment01.e6bc4b9e.png","height":132,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AYOSkwAB/QMpFREGmOnq6DkQDAYAAQIHx22WpmgrHxPXAW+DgykhGRjFBPXoEQfr4QAIEhQAGi0yAKq0u++ZkZs7AZWjpcEeGA8++NbC+kEkHwb5+vkA3wgU+sPX3watv8jCAaa3u/osGAMF38W4ABD/AwAEAf4A/BohAOb2+wChuM77Aam7wvomDfIF8NnMAB4DBgACAgIA0ubmAAIeJgCwy+P7AZ2xusEoEfg++unY+vHIzQYMBQkA4goC+gsaJQa62fPCAbitvykPBNvF/+fjEera6wDm460AHUNnABMcHO+/zOM7AZieiQAi9rMpMRd1mPz89Dnr7sMA9gIRxwEWDmjY5/vXMAR2OhEgVmkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 40961:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/comment02.a7b80782.png","height":132,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AfGxsQD/AAEp/Pv4mOz09Dn5+/wAFw8PxxcVF2j++fnXAeqtrikE//3FtcK9EYSSmAAYFgAAPkFSAFlCRu8pIiQ7AfS2tcHr6+o+YV9h+oKVgQYGBwcAOGR4+nhUUgZ1WFnCAeSlovqhs7EFCQ7/AEQ/PwAFCAgAipWgAJ++xwDJj437Aeapp/p4g3oFTFdMAD1ARADx6OQA2drcAE97jwDSmJf7AfG1s8Hn5uc++gHy+hohGgbq3uAA2drU+goMJAY5MjTCAeyysCkEAQPF+/35EfL+6QDg1NAABAIWADQyO+/y9fQ7AfCvswD8+Pop/g8AmPUF9znTxLwAEQwixzw4RGgA/f3XsHV99N20v28AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 77613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/comment03.bc910e75.png","height":132,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+Ae/BTwD/AAIpDAgDmPL1+jn09vsAGRUKx/j6/2gCAf/XAeu9TCkGBQLF6ev2EaSy6gDK1AcAdmUNADkvEO/2+P07Aeq6R8EFAwM+ZYK2+jMZVwY6NyoAP3Ga+tisMAYjHwjCAei2Qfr4+PMFPVzMAH5dXAApIRsAPHiJALmSNABGPiX7Aei0L/rl6x8FcKACADLhsAAkPlwA3RYsAGI+8gAtH9j7AeGqAMHrDaI+Axg8+vDp4gYMERQAGx8i+gz0ygYK8XnCAcCJNina6DDF/gQMEUpQTwAKKzoAAeLQAAfmq+8JIMs7Aa16QQC9hr8pI2ZjmEUtDTkfRF4A8+fkxxvhTmgAGUfX/4hsTUrmhN4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ })

};
;