"use strict";
exports.id = 885;
exports.ids = [885];
exports.modules = {

/***/ 5080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ breadcrumb_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./public/assets/img/bg/breadcrumb_bg01.jpg
var breadcrumb_bg01 = __webpack_require__(47361);
;// CONCATENATED MODULE: ./public/assets/img/others/teambanner.png
/* harmony default export */ const teambanner = ({"src":"/_next/static/media/teambanner.e8fbf98e.png","height":1563,"width":1563,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42h3DMUsCcRgH4F/vfYYKhz6CkXWc6VFDYzkkIZhEUINIR3F6aSCWJS1Bbt5ag0HhUBTXUERTpKKDoyIIiuimCC6i8PfFBx7Avw8+542+gp/79FwMe0Aj8ISZcvBT6uj/4E5z1xQZT0a0tb/10pEFLuHG+KDbVB7cHnddiZg7KRLXeXsi/A5OOHuuU7wiwG3aoTkIHphDoyCWTrI1cMLWV4tQmYAvR8IPY+P0cYLiaG3TaoITAm9dQk2A29Le+0F6566Pqlg4zrXBCdvRF8mV+gZfDamRXkjR+xsXluzRsuAS3HCSAzL4yuW87ze56P+RITtUKFCh0BRDem3+tS16LAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/app/components/breadcrumb/breadcrumb-area.tsx






const BreadcrumbArea = ({ bg = breadcrumb_bg01/* default */.Z, brd_img = teambanner, title, subtitle })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "breadcrumb-area",
        style: {
            backgroundImage: `url(${bg.src})`
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "breadcrumb__wrapper",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-7",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "breadcrumb__content",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "title",
                                        children: title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                        "aria-label": "breadcrumb",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ol", {
                                            className: "breadcrumb",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "breadcrumb-item",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: "Home"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "breadcrumb-item active",
                                                    "aria-current": "page",
                                                    children: subtitle
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-5 position-relative d-none d-lg-block",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "breadcrumb__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: brd_img,
                                    alt: "img",
                                    style: {
                                        height: "auto",
                                        width: "auto"
                                    }
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const breadcrumb_area = (BreadcrumbArea);


/***/ }),

/***/ 12968:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/teambanner.e8fbf98e.png","height":1563,"width":1563,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42h3DMUsCcRgH4F/vfYYKhz6CkXWc6VFDYzkkIZhEUINIR3F6aSCWJS1Bbt5ag0HhUBTXUERTpKKDoyIIiuimCC6i8PfFBx7Avw8+542+gp/79FwMe0Aj8ISZcvBT6uj/4E5z1xQZT0a0tb/10pEFLuHG+KDbVB7cHnddiZg7KRLXeXsi/A5OOHuuU7wiwG3aoTkIHphDoyCWTrI1cMLWV4tQmYAvR8IPY+P0cYLiaG3TaoITAm9dQk2A29Le+0F6566Pqlg4zrXBCdvRF8mV+gZfDamRXkjR+xsXluzRsuAS3HCSAzL4yuW87ze56P+RITtUKFCh0BRDem3+tS16LAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ })

};
;