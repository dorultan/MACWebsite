"use strict";
exports.id = 1220;
exports.ids = [1220];
exports.modules = {

/***/ 13481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_modal_video__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16438);



const VideoPopup = ({ isVideoOpen, setIsVideoOpen, videoId = "B0WuqoXkJkY" })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_modal_video__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        channel: "youtube",
        isOpen: isVideoOpen,
        videoId: videoId,
        onClose: ()=>setIsVideoOpen(false)
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VideoPopup);


/***/ }),

/***/ 86646:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ video_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./public/assets/img/bg/video_bg.jpg
/* harmony default export */ const video_bg = ({"src":"/_next/static/media/video_bg.a2f581cb.jpg","height":1004,"width":1793,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAwEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAgEL/AP/EAB4QAAEDBAMAAAAAAAAAAAAAAAIBAwQAESEiEhSR/9oACAEBAAE/AJrh9mUF9WxDglkxtn2v/8QAFxEBAAMAAAAAAAAAAAAAAAAAAQAxgv/aAAgBAgEBPwArTP/EABoRAQABBQAAAAAAAAAAAAAAAAECABEhQbH/2gAIAQMBAT8AYxsYNcK//9k=","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./src/app/components/common/video-popup.tsx
var video_popup = __webpack_require__(13481);
;// CONCATENATED MODULE: ./src/app/components/video/video-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const VideoArea = ()=>{
    const [isVideoOpen, setIsVideoOpen] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "video__area video-bg tg-jarallax",
                style: {
                    backgroundImage: `url(${video_bg.src})`
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-8 col-md-11",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "video__content text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "popup-video cursor-pointer",
                                        onClick: ()=>setIsVideoOpen(true)
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        className: "title",
                                        children: [
                                            "JOIN OUR ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "PLAYGROUND"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Arcade Alchemy Awaits!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://discord.gg/gNU6xj6tPf",
                                        target: "_blank",
                                        className: "video__btn tg-btn-1",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "discord"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://twitter.com/metaarcadeclub",
                                        target: "_blank",
                                        className: "video__btn tg-btn-1",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Twitter"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(video_popup/* default */.Z, {
                isVideoOpen: isVideoOpen,
                setIsVideoOpen: setIsVideoOpen,
                videoId: "ssrNcwxALS4"
            })
        ]
    });
};
/* harmony default export */ const video_area = (VideoArea);


/***/ }),

/***/ 84244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\video\video-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;