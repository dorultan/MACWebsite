"use strict";
exports.id = 6310;
exports.ids = [6310];
exports.modules = {

/***/ 86143:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ blog_sidebar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/assets/img/blog/avatar.jpg
var avatar = __webpack_require__(7721);
;// CONCATENATED MODULE: ./public/assets/img/instagram/insta01.jpg
/* harmony default export */ const insta01 = ({"src":"/_next/static/media/insta01.e4a39174.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAKojX//EABsQAAICAwEAAAAAAAAAAAAAAAEDAhIABREh/9oACAEBAAE/AEbBUXITIUVTp5EG0T4M/8QAHBEAAQQDAQAAAAAAAAAAAAAAAQIEESEAAzFB/9oACAECAQE/AAz0lu2VclEnnt5//8QAHBEAAQMFAAAAAAAAAAAAAAAAAgADBBEUIWFx/9oACAEDAQE/ABmO3MscUFzfF//Z","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/instagram/insta02.jpg
/* harmony default export */ const insta02 = ({"src":"/_next/static/media/insta02.1452ea95.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAABQb/2gAMAwEAAhADEAAAAKhOL//EABsQAAMAAgMAAAAAAAAAAAAAAAECAwQRACMx/9oACAEBAAE/AJ0wWo07BkVMfqVfKFhvZ5//xAAYEQADAQEAAAAAAAAAAAAAAAABAxEAAv/aAAgBAgEBPwBpgXBLzv/EABkRAAIDAQAAAAAAAAAAAAAAAAERAAIjA//aAAgBAwEBPwDiToy9LT//2Q==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/instagram/insta03.jpg
/* harmony default export */ const insta03 = ({"src":"/_next/static/media/insta03.62d28b3b.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAAAwX/2gAMAwEAAhADEAAAAJg0L//EAB0QAAEEAgMAAAAAAAAAAAAAAAIBAwQRABIiMWL/2gAIAQEAAT8Ajy4QaR3g4EwpDqN2vq+s/8QAGBEBAAMBAAAAAAAAAAAAAAAAAQIDEQD/2gAIAQIBAT8AokybRdyff//EABoRAAICAwAAAAAAAAAAAAAAAAIDBREAAQT/2gAIAQMBAT8Ak0LUiOMBrbOeyz//2Q==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/instagram/insta04.jpg
/* harmony default export */ const insta04 = ({"src":"/_next/static/media/insta04.f7d619ee.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAwEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAoBh//8QAGxAAAwACAwAAAAAAAAAAAAAAAQIDAAQFImL/2gAIAQEAAT8A1OQ1EecrB1mZdQoBDH1n/8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAx/9oACAECAQE/AB2//8QAHBEAAgAHAAAAAAAAAAAAAAAAAQIAAxIhIjFR/9oACAEDAQE/AGzSWxA1TYcj/9k=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/instagram/insta05.jpg
/* harmony default export */ const insta05 = ({"src":"/_next/static/media/insta05.2d522d94.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABAEBAAAAAAAAAAAAAAAAAAAABf/aAAwDAQACEAMQAAAAuAqX/8QAHBAAAgICAwAAAAAAAAAAAAAAAQIDBAAxBRJh/9oACAEBAAE/AK/IxC2IpFZYBX0FBDdte5//xAAZEQACAwEAAAAAAAAAAAAAAAABAgADBCH/2gAIAQIBAT8A0qoTOQo7UJ//xAAaEQACAgMAAAAAAAAAAAAAAAABAgAEAxES/9oACAEDAQE/AKruz2QWJ5ynU//Z","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/instagram/insta06.jpg
/* harmony default export */ const insta06 = ({"src":"/_next/static/media/insta06.1533a787.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAABAb/2gAMAwEAAhADEAAAAJwRN//EAB0QAAEEAgMAAAAAAAAAAAAAAAECAwQSACERE0L/2gAIAQEAAT8AiuQSt4r7qpjcV8Eka1n/xAAZEQACAwEAAAAAAAAAAAAAAAABAgADIWH/2gAIAQIBAT8ArwN1jP/EABoRAQACAwEAAAAAAAAAAAAAAAECAwAEEjH/2gAIAQMBAT8A3TpoPCNMQz//2Q==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/app/components/blog/sidebar-instagram.tsx










// instagram images
const instagram_images = [
    {
        link: "https://www.instagram.com/",
        img: insta01
    },
    {
        link: "https://www.instagram.com/",
        img: insta02
    },
    {
        link: "https://www.instagram.com/",
        img: insta03
    },
    {
        link: "https://www.instagram.com/",
        img: insta04
    },
    {
        link: "https://www.instagram.com/",
        img: insta05
    },
    {
        link: "https://www.instagram.com/",
        img: insta06
    }
];
const SidebarInstagram = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "sidebar__insta",
        children: instagram_images.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sidebar__insta-item",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: item.link,
                    target: "_blank",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: item.img,
                        alt: "img",
                        style: {
                            width: "100%",
                            height: "auto"
                        }
                    })
                })
            }, i))
    });
};
/* harmony default export */ const sidebar_instagram = (SidebarInstagram);

// EXTERNAL MODULE: ./src/data/blog-data.ts + 2 modules
var blog_data = __webpack_require__(88160);
;// CONCATENATED MODULE: ./src/app/components/blog/blog-sidebar.tsx







const BlogSidebar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
        className: "blog-sidebar",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "blog-widget",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "sidebar__author",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "sidebar__author-thumb",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: avatar/* default */.Z,
                                alt: "img",
                                style: {
                                    width: "100%",
                                    height: "auto"
                                }
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "sidebar__author-content",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "name",
                                    children: "Kaceytron G."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Lorem ipsum sitamet conteur adipiscing Duis elementum solliciin"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "sidebar__author-social",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fab fa-twitter"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fab fa-facebook-f"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fab fa-linkedin-in"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "blog-widget",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    className: "sidebar-search-form position-relative",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "text",
                            placeholder: "Search here.."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "flaticon-loupe"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "blog-widget widget_categories",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "fw-title",
                        children: "CATEGORIES"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-wrap",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: "gaming"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "float-right",
                                        children: "(11)"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: "ELECTRONIC"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "float-right",
                                        children: "(4)"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: "online"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "float-right",
                                        children: "(21)"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: "TOURNAMENT"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "float-right",
                                        children: "(15)"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: "controller"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "float-right",
                                        children: "(2)"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: "live"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "float-right",
                                        children: "(7)"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "blog-widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "fw-title",
                        children: "Recent Posts"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "rc__post-wrapper",
                        children: blog_data/* default */.Z.slice(0, 3).map((b)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "rc__post-item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "rc__post-thumb",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `/blog-details/${b.id}`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: b.img,
                                                alt: "img",
                                                width: 112,
                                                height: 88
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "rc__post-content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                className: "title",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: `/blog-details/${b.id}`,
                                                    children: b.title
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "date",
                                                children: b.date
                                            })
                                        ]
                                    })
                                ]
                            }, b.id))
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "blog-widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "fw-title",
                        children: "Newsletter"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "sidebar__newsletter",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum sitamet conteur adipiscin"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                action: "#",
                                className: "sidebar__newsletter-form",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "email",
                                        name: "email",
                                        placeholder: "Enter Your Email"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "submit",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-arrow-right"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "blog-widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "fw-title",
                        children: "INSTAGRAM"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(sidebar_instagram, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "blog-widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "fw-title",
                        children: "Tag Cloud"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "tagcloud",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "E-sports"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "Fantasy"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "game"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "Tournaments"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "Matches"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: "Streamers"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const blog_sidebar = (BlogSidebar);


/***/ }),

/***/ 88160:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ data_blog_data)
});

;// CONCATENATED MODULE: ./public/assets/img/blog/blog_post01.jpg
/* harmony default export */ const blog_post01 = ({"src":"/_next/static/media/blog_post01.67ab7c13.jpg","height":505,"width":866,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABAEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAsBWf/8QAHRAAAQIHAAAAAAAAAAAAAAAAAgATAQUGERJDcf/aAAgBAQABPwCqHClwk5pztDi//8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECMf/aAAgBAgEBPwCFp//EABgRAAIDAAAAAAAAAAAAAAAAAAABAyJx/9oACAEDAQE/AJ26Yf/Z","blurWidth":8,"blurHeight":5});
// EXTERNAL MODULE: ./public/assets/img/blog/blog_post02.jpg
var blog_post02 = __webpack_require__(18870);
;// CONCATENATED MODULE: ./public/assets/img/blog/blog_post03.jpg
/* harmony default export */ const blog_post03 = ({"src":"/_next/static/media/blog_post03.3888c87f.jpg","height":505,"width":866,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAmAT/AP/EAB4QAAAGAgMAAAAAAAAAAAAAAAECAwQREgAFISJi/9oACAEBAAE/AN++WBykXi5Ey9/M1AIz/8QAFhEBAQEAAAAAAAAAAAAAAAAAASEA/9oACAECAQE/ABUFsN//xAAXEQEBAQEAAAAAAAAAAAAAAAABAiEA/9oACAEDAQE/ALy6DApM7//Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/data/blog-data.ts



const blog_data = [
    {
        id: 1,
        img: blog_post01,
        author: "Admin",
        date: "AUG 19, 2023",
        comments: 0,
        title: "ZOMBIE LAND TOURNAMENT MAX",
        desc: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum solliciin is yaugue euismods Nulla ullaorper. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard."
    },
    {
        id: 2,
        img: blog_post02/* default */.Z,
        author: "ADMIN",
        date: "AUG 16, 2023",
        comments: 0,
        title: "PLAY TO EARN CRYPTO GAMES PLACE",
        desc: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum solliciin is yaugue euismods Nulla ullaorper. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard."
    },
    {
        id: 3,
        img: blog_post03,
        author: "ADMIN",
        date: "MAY 10, 2023",
        comments: 0,
        title: "NFT GAMES ANDROID NO INVESTMENT",
        desc: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum solliciin is yaugue euismods Nulla ullaorper. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard."
    }
];
/* harmony default export */ const data_blog_data = (blog_data);


/***/ }),

/***/ 6061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar.029bbba3.jpg","height":214,"width":355,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABQb/2gAMAwEAAhADEAAAAKoTCv8A/8QAHBAAAQQDAQAAAAAAAAAAAAAAAwECBBIAERMx/9oACAEBAAE/AIcdDHNMcUlmO5U2lfM//8QAGhEBAAEFAAAAAAAAAAAAAAAAAQIAAwQRQ//aAAgBAgEBPwDLCLZ0cYV//8QAGBEAAgMAAAAAAAAAAAAAAAAAAAECQnL/2gAIAQMBAT8AhbTP/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 7721:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/avatar.029bbba3.jpg","height":214,"width":355,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABQb/2gAMAwEAAhADEAAAAKoTCv8A/8QAHBAAAQQDAQAAAAAAAAAAAAAAAwECBBIAERMx/9oACAEBAAE/AIcdDHNMcUlmO5U2lfM//8QAGhEBAAEFAAAAAAAAAAAAAAAAAQIAAwQRQ//aAAgBAgEBPwDLCLZ0cYV//8QAGBEAAgMAAAAAAAAAAAAAAAAAAAECQnL/2gAIAQMBAT8AhbTP/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 96174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blog_post01.67ab7c13.jpg","height":505,"width":866,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABAEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAsBWf/8QAHRAAAQIHAAAAAAAAAAAAAAAAAgATAQUGERJDcf/aAAgBAQABPwCqHClwk5pztDi//8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECMf/aAAgBAgEBPwCFp//EABgRAAIDAAAAAAAAAAAAAAAAAAABAyJx/9oACAEDAQE/AJ26Yf/Z","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 95181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blog_post02.730c470d.jpg","height":505,"width":866,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAALRLd//EABwQAAICAgMAAAAAAAAAAAAAAAEDAhIABBNxkf/aAAgBAQABPwDU3GpjxqNQUwb4a16z/8QAGBEAAgMAAAAAAAAAAAAAAAAAAAIBETH/2gAIAQIBAT8AZmvZP//EABcRAAMBAAAAAAAAAAAAAAAAAAABAkL/2gAIAQMBAT8AUy8o/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 18870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blog_post02.730c470d.jpg","height":505,"width":866,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAALRLd//EABwQAAICAgMAAAAAAAAAAAAAAAEDAhIABBNxkf/aAAgBAQABPwDU3GpjxqNQUwb4a16z/8QAGBEAAgMAAAAAAAAAAAAAAAAAAAIBETH/2gAIAQIBAT8AZmvZP//EABcRAAMBAAAAAAAAAAAAAAAAAAABAkL/2gAIAQMBAT8AUy8o/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 23723:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/blog_post03.3888c87f.jpg","height":505,"width":866,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAmAT/AP/EAB4QAAAGAgMAAAAAAAAAAAAAAAECAwQREgAFISJi/9oACAEBAAE/AN++WBykXi5Ey9/M1AIz/8QAFhEBAQEAAAAAAAAAAAAAAAAAASEA/9oACAECAQE/ABUFsN//xAAXEQEBAQEAAAAAAAAAAAAAAAABAiEA/9oACAEDAQE/ALy6DApM7//Z","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 8957:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/insta01.e4a39174.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAKojX//EABsQAAICAwEAAAAAAAAAAAAAAAEDAhIABREh/9oACAEBAAE/AEbBUXITIUVTp5EG0T4M/8QAHBEAAQQDAQAAAAAAAAAAAAAAAQIEESEAAzFB/9oACAECAQE/AAz0lu2VclEnnt5//8QAHBEAAQMFAAAAAAAAAAAAAAAAAgADBBEUIWFx/9oACAEDAQE/ABmO3MscUFzfF//Z","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 49927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/insta02.1452ea95.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAABQb/2gAMAwEAAhADEAAAAKhOL//EABsQAAMAAgMAAAAAAAAAAAAAAAECAwQRACMx/9oACAEBAAE/AJ0wWo07BkVMfqVfKFhvZ5//xAAYEQADAQEAAAAAAAAAAAAAAAABAxEAAv/aAAgBAgEBPwBpgXBLzv/EABkRAAIDAQAAAAAAAAAAAAAAAAERAAIjA//aAAgBAwEBPwDiToy9LT//2Q==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 34316:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/insta03.62d28b3b.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAAAwX/2gAMAwEAAhADEAAAAJg0L//EAB0QAAEEAgMAAAAAAAAAAAAAAAIBAwQRABIiMWL/2gAIAQEAAT8Ajy4QaR3g4EwpDqN2vq+s/8QAGBEBAAMBAAAAAAAAAAAAAAAAAQIDEQD/2gAIAQIBAT8AokybRdyff//EABoRAAICAwAAAAAAAAAAAAAAAAIDBREAAQT/2gAIAQMBAT8Ak0LUiOMBrbOeyz//2Q==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 68487:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/insta04.f7d619ee.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAwEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAoBh//8QAGxAAAwACAwAAAAAAAAAAAAAAAQIDAAQFImL/2gAIAQEAAT8A1OQ1EecrB1mZdQoBDH1n/8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAx/9oACAECAQE/AB2//8QAHBEAAgAHAAAAAAAAAAAAAAAAAQIAAxIhIjFR/9oACAEDAQE/AGzSWxA1TYcj/9k=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 28166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/insta05.2d522d94.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABAEBAAAAAAAAAAAAAAAAAAAABf/aAAwDAQACEAMQAAAAuAqX/8QAHBAAAgICAwAAAAAAAAAAAAAAAQIDBAAxBRJh/9oACAEBAAE/AK/IxC2IpFZYBX0FBDdte5//xAAZEQACAwEAAAAAAAAAAAAAAAABAgADBCH/2gAIAQIBAT8A0qoTOQo7UJ//xAAaEQACAgMAAAAAAAAAAAAAAAABAgAEAxES/9oACAEDAQE/AKruz2QWJ5ynU//Z","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 52233:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/insta06.1533a787.jpg","height":100,"width":110,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAABAb/2gAMAwEAAhADEAAAAJwRN//EAB0QAAEEAgMAAAAAAAAAAAAAAAECAwQSACERE0L/2gAIAQEAAT8AiuQSt4r7qpjcV8Eka1n/xAAZEQACAwEAAAAAAAAAAAAAAAABAgADIWH/2gAIAQIBAT8ArwN1jP/EABoRAQACAwEAAAAAAAAAAAAAAAECAwAEEjH/2gAIAQMBAT8A3TpoPCNMQz//2Q==","blurWidth":8,"blurHeight":7});

/***/ })

};
;