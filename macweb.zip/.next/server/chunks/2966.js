"use strict";
exports.id = 2966;
exports.ids = [2966];
exports.modules = {

/***/ 62870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\common\text-animation.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 62487:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ team_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/team/team01.png
/* harmony default export */ const team01 = ({"src":"/_next/static/media/team01.6791c3f0.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+0lEQVR42i2MP0vDQADF7yM42XiluWuaJtxZkzSlNKhIhaaijWiHRgOCFnHyTx0UdHLWxVlwcPCLHPh5sueW51l88ODx+8Ejf6G1muCcqVVa15Zp02xKqTAlpEHXjOTlCnfQCyR6YQecMTQNY7YtiMOYcqSEOaoW+QiXR8PldlsO2q6riPR9bXk+NrsSL/MMrzcFbmdjuNyGlFKTKAy01eCYneX4fJrj5+sNH4/nqLdcxFGkSRgGKhkMkIx2q+vpEN/PFzg52KnCfoJ+3FUk2d4S8UanzIoCp/kx3h+ucL+4Q9vzynGaCvIfsR5F6nAv1dPJvp5kmTJsKX8ByGVaDO3TPp4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/team02.png
/* harmony default export */ const team02 = ({"src":"/_next/static/media/team02.7d5a5a8d.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42i2LMUvDQBzF//g5xE3oQZ3UumStSIcoYlEc6iKKk1B0CHR2iTWggoIFRTSiVnGJQ0JILrlLzupnyZ5bnk3pgwc/3o9HVdIkYVme87ePT/3kvuhUSj76UWwiA99nuVLF/eAO3bVlXPZO8Pr4gGpL4phRHMc8y3L0usdlf3MJ3zc2vq7tUggJKQUnzrkeF7vtLewszuNsfxuD0wOM3xBSaoqiSCul4JzbaM0Sbo/acK/6GP3+QaSppiAIeBiGeB8Oy7kZwuFGC8+uW3qeB9/3OVmWxQzDKFYaDSzU67hwHOx1OiCiwjRNRtNUwNdNU682m7riWo1N5D+wIZFPKKN05wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/team03.png
/* harmony default export */ const team03 = ({"src":"/_next/static/media/team03.7810cf80.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AY+PkAD19vUpHh0cmNnW1Dn/AQMAPT4+xwsMDWgSERHXAXp6eikqKivF497YEayZgwDN5QAAXVxbAGprbO8NDQ07AZaWlsH8+/o+pp2Z+sjS1wYhISAA39/g+pCQjwYqKivCAZybm/oZGx0F4t/VAMOwjwDq7wYA0PYHAJ2JigAXFRX7AaCgoPoiGA8F+OvYAO3hzwDa2+UA/BgwAEtUYQD8+fn7AZydncEWExA+x8TC+quMkQZXZ1wA+/38+i9HUwYQCQrCAZWTkikMEBLF1e3sEbSwqwAf8u8A9OnqACFOVu9fUlA7AYyRkQD8/Psp2fDxmN7a2jnByMkAAPr7xwDn5Wh3c3LXGY59SD1seYgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/team04.png
/* harmony default export */ const team04 = ({"src":"/_next/static/media/team04.58b1ed6f.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+ARkVGAABCgYp/uHqmAtBLDkEAQIA8b7Kx/8WGWgA9fvXAR0rJSn83+7FE1Q4EQwyJQDx+fkAAN3nAPKvyO8ADwk7ARscHMEFCwk+8zsi+hZGPAY5LCkA3Le/+uGkvwb85e7CASIfH/ruAwIFNy0eADwoIQAtIh0AytTcAIavwgAnBQb7ASclJPrd9/4FYjUjAGtHNAAWEQ8AqMbVAHGRugAtKQ/7ASYmJsENDAs+8wEF+nE7HwYkHBYAirfS+ubt8wb9+vfCATQuKin3AQfFJBcQEV86IgAgGBQAm73UALDU4+8nDAE7AQAfJgAYCQcpIgj/mFM7KjkLCQgAtMfUx7Tb9GgA+vvX7X5g34fA5s0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/data/team-data.ts




const team_data = [
    {
        id: 1,
        img: team01,
        title: "killer master",
        subtitle: "1"
    },
    {
        id: 2,
        img: team02,
        title: "tanu mark",
        subtitle: "2"
    },
    {
        id: 3,
        img: team03,
        title: "Thompson Scot",
        subtitle: "3"
    },
    {
        id: 4,
        img: team04,
        title: "Shakh Danial",
        subtitle: "4"
    }
];
/* harmony default export */ const data_team_data = (team_data);

;// CONCATENATED MODULE: ./public/assets/img/bg/team_bg.jpg
/* harmony default export */ const team_bg = ({"src":"/_next/static/media/team_bg.eac2c3ae.jpg","height":2000,"width":3000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwb/2gAMAwEAAhADEAAAAIIVzf/EABsQAAEEAwAAAAAAAAAAAAAAAAEAAgMxBAUT/9oACAEBAAE/AHSSa7IPB9Giv//EABkRAAEFAAAAAAAAAAAAAAAAAAIAAREhUf/aAAgBAgEBPwA6J41f/8QAGxEAAQQDAAAAAAAAAAAAAAAAAgABAwQRElH/2gAIAQMBAT8AvV4CsFtED46y/9k=","blurWidth":8,"blurHeight":5});
// EXTERNAL MODULE: ./src/app/components/common/text-animation.tsx
var text_animation = __webpack_require__(62870);
;// CONCATENATED MODULE: ./src/app/components/team/team-area.tsx







const TeamArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "team__area team-bg section-pt-130 section-pb-100",
        style: {
            backgroundImage: `url(${team_bg.src})`
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-6 col-lg-7 col-md-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "section__title text-center mb-60",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(text_animation/* default */.ZP, {
                                    title: "Elite Rankings"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "title",
                                    children: "Leaderboard"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: data_team_data.map((t, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-3 col-lg-4 col-sm-6 wow fadeInUp",
                            "data-wow-delay": `.${i + 1}s`,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "team__item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "team__thumb",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: t.img,
                                            alt: "img",
                                            style: {
                                                width: "100%",
                                                height: "auto"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "team__content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "name",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "#",
                                                    children: t.title
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(text_animation/* default */.ZP, {
                                                title: "Rank"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "designation",
                                                children: t.subtitle
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, t.id))
                })
            ]
        })
    });
};
/* harmony default export */ const team_area = (TeamArea);


/***/ }),

/***/ 78403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_bg.eac2c3ae.jpg","height":2000,"width":3000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwb/2gAMAwEAAhADEAAAAIIVzf/EABsQAAEEAwAAAAAAAAAAAAAAAAEAAgMxBAUT/9oACAEBAAE/AHSSa7IPB9Giv//EABkRAAEFAAAAAAAAAAAAAAAAAAIAAREhUf/aAAgBAgEBPwA6J41f/8QAGxEAAQQDAAAAAAAAAAAAAAAAAgABAwQRElH/2gAIAQMBAT8AvV4CsFtED46y/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 40565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team01.6791c3f0.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+0lEQVR42i2MP0vDQADF7yM42XiluWuaJtxZkzSlNKhIhaaijWiHRgOCFnHyTx0UdHLWxVlwcPCLHPh5sueW51l88ODx+8Ejf6G1muCcqVVa15Zp02xKqTAlpEHXjOTlCnfQCyR6YQecMTQNY7YtiMOYcqSEOaoW+QiXR8PldlsO2q6riPR9bXk+NrsSL/MMrzcFbmdjuNyGlFKTKAy01eCYneX4fJrj5+sNH4/nqLdcxFGkSRgGKhkMkIx2q+vpEN/PFzg52KnCfoJ+3FUk2d4S8UanzIoCp/kx3h+ucL+4Q9vzynGaCvIfsR5F6nAv1dPJvp5kmTJsKX8ByGVaDO3TPp4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 84588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team02.7d5a5a8d.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42i2LMUvDQBzF//g5xE3oQZ3UumStSIcoYlEc6iKKk1B0CHR2iTWggoIFRTSiVnGJQ0JILrlLzupnyZ5bnk3pgwc/3o9HVdIkYVme87ePT/3kvuhUSj76UWwiA99nuVLF/eAO3bVlXPZO8Pr4gGpL4phRHMc8y3L0usdlf3MJ3zc2vq7tUggJKQUnzrkeF7vtLewszuNsfxuD0wOM3xBSaoqiSCul4JzbaM0Sbo/acK/6GP3+QaSppiAIeBiGeB8Oy7kZwuFGC8+uW3qeB9/3OVmWxQzDKFYaDSzU67hwHOx1OiCiwjRNRtNUwNdNU682m7riWo1N5D+wIZFPKKN05wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 9747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team03.7810cf80.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AY+PkAD19vUpHh0cmNnW1Dn/AQMAPT4+xwsMDWgSERHXAXp6eikqKivF497YEayZgwDN5QAAXVxbAGprbO8NDQ07AZaWlsH8+/o+pp2Z+sjS1wYhISAA39/g+pCQjwYqKivCAZybm/oZGx0F4t/VAMOwjwDq7wYA0PYHAJ2JigAXFRX7AaCgoPoiGA8F+OvYAO3hzwDa2+UA/BgwAEtUYQD8+fn7AZydncEWExA+x8TC+quMkQZXZ1wA+/38+i9HUwYQCQrCAZWTkikMEBLF1e3sEbSwqwAf8u8A9OnqACFOVu9fUlA7AYyRkQD8/Psp2fDxmN7a2jnByMkAAPr7xwDn5Wh3c3LXGY59SD1seYgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 48855:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team04.58b1ed6f.png","height":224,"width":224,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+ARkVGAABCgYp/uHqmAtBLDkEAQIA8b7Kx/8WGWgA9fvXAR0rJSn83+7FE1Q4EQwyJQDx+fkAAN3nAPKvyO8ADwk7ARscHMEFCwk+8zsi+hZGPAY5LCkA3Le/+uGkvwb85e7CASIfH/ruAwIFNy0eADwoIQAtIh0AytTcAIavwgAnBQb7ASclJPrd9/4FYjUjAGtHNAAWEQ8AqMbVAHGRugAtKQ/7ASYmJsENDAs+8wEF+nE7HwYkHBYAirfS+ubt8wb9+vfCATQuKin3AQfFJBcQEV86IgAgGBQAm73UALDU4+8nDAE7AQAfJgAYCQcpIgj/mFM7KjkLCQgAtMfUx7Tb9GgA+vvX7X5g34fA5s0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ })

};
;