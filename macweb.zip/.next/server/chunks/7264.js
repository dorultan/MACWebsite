exports.id = 7264;
exports.ids = [7264];
exports.modules = {

/***/ 10725:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86646));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12968));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52053));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4485));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13760));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97207))

/***/ }),

/***/ 4485:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ road_map_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-intersection-observer/index.mjs
var react_intersection_observer = __webpack_require__(81257);
;// CONCATENATED MODULE: ./public/assets/img/bg/roadmap_bg.jpg
/* harmony default export */ const roadmap_bg = ({"src":"/_next/static/media/roadmap_bg.ea36ba54.jpg","height":1232,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAlIY//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/others/roadmap1.png
/* harmony default export */ const roadmap1 = ({"src":"/_next/static/media/roadmap1.f542db36.png","height":625,"width":625,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAjklEQVR42mNABqsZFjOuZpjAyEAyONc8Hazr7aWUkDeX4kJB7IudfQiTwhlamUH0gu7K9uV1ad0gdgJDBBNcQSUDA5hjEdY/v5Atvx/ENrRnYGYAAfnOA2BJhqlnLG0jux61C3Xd6VdfZQISmqG0DGGNllEcP0PQPPFChm7lXJk0EZBYlVwFbh/1KlWBJQEZGSVmZ6UnJwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./src/hooks/use-text-animation.ts
var use_text_animation = __webpack_require__(75343);
;// CONCATENATED MODULE: ./src/app/components/road-map/road-map-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const road_map_lists = [
    {
        id: 1,
        active: true,
        title: "Phase I",
        lists: [
            {
                active: true,
                text: "Finalize 3D Pong with optimal visuals and gameplay"
            },
            {
                active: true,
                text: "Host a celebratory game launch tournament with exciting prizes"
            },
            {
                active: true,
                text: "Revamp the Meta Arcade Club website for better user experience"
            },
            {
                active: true,
                text: "Initiate targeted social media campaigns"
            },
            {
                active: true,
                text: "Implement feedback mechanisms for improvement"
            }
        ]
    },
    {
        id: 2,
        active: false,
        title: "Phase II",
        lists: [
            {
                active: false,
                text: "Official launch of 3D Pong with promotional campaigns."
            },
            {
                active: false,
                text: "Launch Meta Arcade Club's first NFT collection with unique assets"
            },
            {
                active: false,
                text: "Kickstart development of new NFT-based arcade games"
            },
            {
                active: false,
                text: "Release special skins for 3D Pong and organize tournaments."
            }
        ]
    },
    {
        id: 3,
        active: false,
        title: "Phase III",
        lists: [
            {
                active: false,
                text: "Roll out NFT renting and introduce the Pawn Arcade feature"
            },
            {
                active: false,
                text: "Aim for a broader audience, moving beyond just the web3 enthusiasts"
            },
            {
                active: false,
                text: "Start producing and distributing branded merchandise"
            },
            {
                active: false,
                text: "Promote the exclusive Arcadians collection and metaverse"
            },
            {
                active: false,
                text: "Offer exclusive ticket collection for special perks"
            }
        ]
    },
    {
        id: 4,
        active: false,
        title: "Phase IV",
        lists: [
            {
                active: false,
                text: "Begin the exciting journey of developing the Meta Arcade Club metaverse"
            },
            {
                active: false,
                text: "Regularly introduce new games to the platform to retain user interest"
            },
            {
                active: false,
                text: "Launch limited edition merchandise"
            },
            {
                active: false,
                text: "Review and refine the Level Up Zone, adapting to user needs"
            }
        ]
    }
];
const RoadMapArea = ()=>{
    const [isView, setIsView] = (0,react_.useState)(false);
    (0,use_text_animation/* default */.Z)(isView);
    const handleInViewChange = (inView)=>{
        if (inView) {
            setIsView(true);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "roadMap__area roadMap-bg section-pt-150 section-pb-150",
        style: {
            backgroundImage: `url(${roadmap_bg.src})`
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row justify-content-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-xl-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "roadMap__inner",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-xl-5 col-lg-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "roadMap__content",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "title",
                                                    children: "Pixelated Pathways"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Level up with us! Track our quests, power-ups, and next-level achievements as we navigate the game of progress."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "roadMap__img",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: roadmap1,
                                                className: "tg-parallax",
                                                "data-scale": "1.5",
                                                "data-orientation": "down",
                                                alt: "roadMap__img"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-xl-7 col-lg-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "roadMap__steps-wrap",
                                        children: road_map_lists.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: `roadMap__steps-item ${item.active ? "active" : ""}`,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        className: "title",
                                                        children: item.title
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_intersection_observer/* InView */.df, {
                                                        as: "ul",
                                                        onChange: handleInViewChange,
                                                        className: "roadMap__list list-wrap",
                                                        children: item.lists.map((l, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                className: `${l.active ? "active" : ""} tg__animate-text style2`,
                                                                children: l.text
                                                            }, i))
                                                    })
                                                ]
                                            }, item.id))
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const road_map_area = (RoadMapArea);


/***/ }),

/***/ 13760:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ services_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/others/services_img01.jpg
/* harmony default export */ const services_img01 = ({"src":"/_next/static/media/services_img01.214866f1.jpg","height":593,"width":593,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAAAf/aAAwDAQACEAMQAAAAnAP/xAAcEAACAgIDAAAAAAAAAAAAAAADEgETAAIEBTL/2gAIAQEAAT8AF2oeNXA9AwCqbtVZm9Nn/8QAGBEAAgMAAAAAAAAAAAAAAAAAAjEAARH/2gAIAQIBAT8ALBtOf//EABgRAQADAQAAAAAAAAAAAAAAAAIAASES/9oACAEDAQE/AAezqvJ//9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/services_img02.jpg
/* harmony default export */ const services_img02 = ({"src":"/_next/static/media/services_img02.dd7f22a4.jpg","height":593,"width":593,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAIgNf//EABwQAAICAgMAAAAAAAAAAAAAAAECAwQAEyEjUf/aAAgBAQABPwCxfgk1My10AVR1DhgPc//EABcRAQADAAAAAAAAAAAAAAAAAAEAITH/2gAIAQIBAT8ALNZ//8QAFxEBAQEBAAAAAAAAAAAAAAAAAQIRAP/aAAgBAwEBPwCrRzDv/9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/services_img03.jpg
/* harmony default export */ const services_img03 = ({"src":"/_next/static/media/services_img03.ff862bd4.jpg","height":593,"width":593,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAAAgT/2gAMAwEAAhADEAAAAKhC/wD/xAAeEAACAQMFAAAAAAAAAAAAAAABAgMABRETIjFBcf/aAAgBAQABPwDVt7Q75lY4wEHR85Nf/8QAGBEAAgMAAAAAAAAAAAAAAAAAATEAAiH/2gAIAQIBAT8AFHpc/8QAGhEBAQACAwAAAAAAAAAAAAAAAQIAAwQSIf/aAAgBAwEBPwC+RejoSSjI+mf/2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/services_img04.jpg
/* harmony default export */ const services_img04 = ({"src":"/_next/static/media/services_img04.73480a43.jpg","height":593,"width":593,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAJ4WP//EABwQAQACAQUAAAAAAAAAAAAAAAIBAwAEBRIVcf/aAAgBAQABPwDX37X2FIqrAomSGBHGUfYz/8QAGREAAgMBAAAAAAAAAAAAAAAAAQIAEiIx/9oACAECAQE/AEBFtN2f/8QAGREAAQUAAAAAAAAAAAAAAAAAAAEDERJy/9oACAEDAQE/AHFmmT//2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/app/components/services/services-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






// service images
const service_images = [
    services_img01,
    services_img02,
    services_img03,
    services_img04
];
const service_items = [
    {
        id: 1,
        icon: "flaticon-diamond",
        title: "Skillful Stakes",
        desc: "A realm where luck takes a backseat. Our platform celebrates skill-based games, where strategy reigns supreme and adrenaline runs high."
    },
    {
        id: 2,
        icon: "flaticon-user-profile",
        title: "Pixel Pioneers",
        desc: "Every pixel, every challenge, every victory is crafted by our team; a perfect fusion of gaming passion and technological expertise."
    },
    {
        id: 3,
        icon: "flaticon-ethereum",
        title: "ACTIVE EARNINGS",
        desc: "A world where your movements are currency and physical activity fuels your digital gains. Fitness meets fun, and rewards await!"
    },
    {
        id: 4,
        icon: "flaticon-settings-1",
        title: "Arcade Pawn",
        desc: "Unlock a world where your digital assets come alive. Whether you trade, rent, or pawn, each decision amplifies your gaming narrative."
    }
];
const ServicesArea = ()=>{
    const [activeIndex, setActiveIndex] = (0,react_.useState)(0);
    const handleMouseOver = (index)=>{
        setActiveIndex(index);
    };
    const handleMouseOut = (index)=>{
        setActiveIndex(index);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "services-area services__bg-color section-pt-120 section-pb-120",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row align-items-end align-items-xl-start",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-6",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section__title text-start mb-65",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "sub-title tg__animate-text",
                                        children: "DIGITAL DESTINATIONS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "title",
                                        children: "LEVEL UP WITH OUR ROADMAP"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "services__wrapper",
                                children: service_items.map((item, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "services__item",
                                        onMouseOver: ()=>handleMouseOver(i),
                                        onMouseOut: ()=>handleMouseOut(i),
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "services__icon",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: item.icon
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "services__content",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                        className: "title",
                                                        children: item.title
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: item.desc
                                                    })
                                                ]
                                            })
                                        ]
                                    }, item.id))
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-6",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "services__images",
                            children: service_images.map((s, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `services__images-item ${activeIndex === i ? "active" : ""}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: s,
                                        alt: "img",
                                        style: {
                                            width: "100%",
                                            height: "100%"
                                        }
                                    })
                                }, i))
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const services_area = (ServicesArea);


/***/ }),

/***/ 84790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\road-map\road-map-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 54771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\services\services-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;