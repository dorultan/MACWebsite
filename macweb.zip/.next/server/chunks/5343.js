"use strict";
exports.id = 5343;
exports.ids = [5343];
exports.modules = {

/***/ 75343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* __next_internal_client_entry_do_not_use__ default auto */ 
const useTextAnimation = (isShow)=>{
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (isShow) {
            const animateText = (element)=>{
                const text = element.innerText;
                const wait = parseInt(element.getAttribute("data-wait")) || 0;
                const speed = parseInt(element.getAttribute("data-speed")) || 4;
                const animationDelay = speed / 100;
                element.innerHTML = "<em>321...</em>";
                element.classList.add("ready");
                const characters = text.split("");
                element.innerHTML = ""; // Clear existing content
                setTimeout(()=>{
                    characters.forEach((char, index)=>{
                        const charElement = document.createElement("span");
                        charElement.textContent = char;
                        charElement.style.animationDelay = index * animationDelay + "s";
                        element.appendChild(charElement);
                    });
                }, wait);
            };
            const textElements = document.querySelectorAll(".tg__animate-text");
            textElements.forEach(animateText);
            const handleWindowResize = ()=>{
                const isMobile = window.innerWidth < 768;
                const listItems = document.querySelectorAll(".roadMap__list li");
                listItems.forEach((item)=>{
                    if (isMobile) {
                        item.classList.add("mobileView");
                        item.classList.remove("tg__animate-text");
                    } else {
                        item.classList.remove("mobileView");
                        item.classList.add("tg__animate-text");
                    }
                });
            };
            handleWindowResize(); // Call the function initially
            window.addEventListener("resize", handleWindowResize);
            return ()=>{
                window.removeEventListener("resize", handleWindowResize);
            };
        }
    }, [
        isShow
    ]);
    return null;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useTextAnimation);


/***/ })

};
;