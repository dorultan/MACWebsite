(() => {
var exports = {};
exports.id = 7301;
exports.ids = [7301];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 78153:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        'about',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52547)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\about\\page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16660)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\about\\page.tsx"];
    
    const originalPathname = "/about/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 6009:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86646));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12968));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 94797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97207))

/***/ }),

/***/ 94797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ about_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab01.png
/* harmony default export */ const about_tab01 = ({"src":"/_next/static/media/about_tab01.625857a7.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/ANq+wYGHpThylBRrkABdhRBVdw9NbRJIaACQka1XgaQod5mFhIeIgoIgY4MAWXsAT3MAQoCjD3+lkpOUlmpBelY1KldxL2+PUW+EACSDpkiWtObCnMF/RodxZYJbR6KalK+ilQAAh6yasrzjuI6OYECHcmOSYz6vnImxpJYAnp6czb2u5r6bsJF6hHhvjoB4tKSTuaqbALinl8a0orafjm9vcWNpcWVpcIJ6dYuAdwCll4qvno+vno6djoGDeG90aWNHSE0uND5Q/F52n6YORgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab02.png
/* harmony default export */ const about_tab02 = ({"src":"/_next/static/media/about_tab02.c5040453.png","height":77,"width":76,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/AISnyZW93qXR8KXT8KTR75e+4YWpy32fvwCTu92r1/Or0+Nqj490naabyeWUu9+Dp8gAncjotOD3cI5/Q3dmQYmRjrXHoMrtia7RAJ7I6bbj+pi9y1+dvWmx06PQ6p/K7Y2y1QCZwuap1vW55/9xpbh4tNir1/mZw+aNsdQAj7fZn8rug73MQIVuXZSOl8fjlbvhh6zOAIepzI622FaGdjmBfSl7a2aWmo+y1oOmxgCAocJ8ocBBeH44bHBLjYJIgIKBpsZ9n7+qNn4RZvgZFAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab03.png
/* harmony default export */ const about_tab03 = ({"src":"/_next/static/media/about_tab03.bb5ac895.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA0UlEQVR42mOQlZC10FJ1tnXY0pu1fVKWp5uroZqStIQcg6a6eriFsYWb36LqrNUdBZ4hwT7Guqqamgx6erpVbnpWDAxrFi3at3GTm6RojaeurqEBA4OAxoJcs9pY146SsoklZW2JrjPTjRmkdRiUFJS1lFV8rKxbSkr7KqsS3T0MlJVVVNQYlCSk2SVlGRgYwn394kPDGDgEGERlpCWAIqzCtsKCyszs0hzcauKSshwC3rKCkpyiDDOtBPp0uNUFxSUlpDXUNdUE5OZasS0OkgEApTMuR1iljfUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab04.png
/* harmony default export */ const about_tab04 = ({"src":"/_next/static/media/about_tab04.4c2a18d1.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAvklEQVR42i2OTQ/BMACG+0+d/Q5xcyBOTg5ugsSN+IiISIhvMWxdjG1Mo7RYQtu1bNmTvKcnb/IAJZWUQcC5R281OJw5mhBCKQX+I9gfNU+5eiM5KKS7eR7wWDyufrtsQPu80rVEJnV7kVj8v9O+buysbKZar0xUiATsy64H6pgIbu3l3Ox1Frvt0bEReBPf3WDOxHpgrobWZq2Xiq3JeA+kCJCLOGdH7eJCxNjnjgnUrajK8KhHnphSTMLWiB+1a6nsrc3zFwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab05.png
/* harmony default export */ const about_tab05 = ({"src":"/_next/static/media/about_tab05.b00e25f8.png","height":77,"width":73,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/AENPWEZQWT5JUzNGUz1LVUJNVUNQWENQWABAREYqNTw7OUO0mYxtZWAbLTsyGiIpAQ0Arqmch4V6b2dgnn98hWRcAAAAPoCDRIuNALe6uLm1qmRqaGJLUZCTnW6QnEersT68wwB1gImNjYdnfpCrxOOiyd+Yx92Iucs8j5gAAAAAHD1Liq3HyOT/ocfedaS4kb7RX3R+ACw7Q1Jqc4Sox7jW/JG41XiltX2sv2ySpQCBbnuAlaF1mLS01P2LtNWArLp0n7B1f41PcFzktHvYFwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab06.png
/* harmony default export */ const about_tab06 = ({"src":"/_next/static/media/about_tab06.ac3ee04d.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/AK2ppqunpKelo6efnKqnpaqlo6WgnaKdmgCxrauuq6m0lonCjHGyj3+sqKWqpaKln50Aq6mnoZeSoXFexpN9onFcmY+Kn5+dmZeWAKWjp6OWlIZfW5tyZ4NXUZSQjcHQzbC+vQDLydKinqOfbE+rcV+dZUuJhYPC0My2wb8AycbPW2FpWDUgkWRTZ0g7ABEcrLm0xNDNAE9TWQciKj8yLXZWRlBBOgAADEZPUIeQjgAAEhwRHSAAHSIQISYAGSAZIyYAChYAAAALiVv2SQwhxQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab07.png
/* harmony default export */ const about_tab07 = ({"src":"/_next/static/media/about_tab07.9bd4fcbd.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/AFR3gQAAL7akpod/dwAAABERNhMNLm45iABtmaUAAEW2o6eQgIJ/WHohHzMRCDl3Mp8AZW+LIgBsuaGsmYOMv4uiLCw/DgA/fCmtAAAANlINg5BspFJTSrGjniksRw4AQXobtAAABUMvE1lWQ25QT05cYGgxLkIkGUN1GqkACQJRGB1UgWxzUkleKiQzKSRFIiE4aQOlAAAAVnZcdnFZdjkzYkZGUSAAcU48XXpMogBwaX/FqqmFeYcJIWsrO2YAAHOhl5uuo519Tj9cP4fWAQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab08.png
/* harmony default export */ const about_tab08 = ({"src":"/_next/static/media/about_tab08.00b0c47b.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAbFBMVEXX19fU09LL0NHFxMSlp6eenp56enrJUytzcXHJUihsbGxmZmanRypTYmSMOR56NSJXHgtKHhMlIyJpAAAYGRkXFxcAHSQVFRUVFBQSEhIWDAoYBAEQAgEQAgAPAgAOAgADAwMIAQABAQEAAAARILIvAAAAPElEQVR42gWAhRHAIAADU3d3A8rvvyMn7MvpNvTBDXjRLl1SZ4i+2qNc6KEY4rJBhnFKZy5hAQ4E5l8dBN0YBj+K48/+AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab09.png
/* harmony default export */ const about_tab09 = ({"src":"/_next/static/media/about_tab09.4edeab4c.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAu0lEQVR42mOAAAVBPgiDiZGZiQEGAiwN8kO9U91tI20MVHgZWJlYoHJextrV4U4tKSHt2WmRjj5cDAzc7JwMDAwMFkpq7SVNLYnBE0piy0K9pRgYBLk5GAT5eHVYGHrqOqZM6OisLEhx9xFnYBDg4WWAgHULZxzau3lWcVVJYJCEtBgLAwODvpbGukWz9s2feevs4e6sqlUTehgYGNhYWBgCbKze3bv04OLxR5dPzOiftn7JfEM9LQYGBgBGHzMn1nxJCAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_tab10.png
/* harmony default export */ const about_tab10 = ({"src":"/_next/static/media/about_tab10.c9874020.png","height":77,"width":77,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAy0lEQVR42mMQZWaIDvGMCvG3NjBwtbaKCgkM8fHSE1VhCAzJsrDy0ZTj05CVZWBgq4gLygny4mAQZIiIr3H3z1YQZ1CWlGJgYDg7v2N9Sz4DEAiLCioKMMjzC4hwsTMwMCQ7mye7WiZERTAkRIYAZRkYGNiAFDcHAwODv7d3YWoKw6xg3/1TasPszJrSI10szayMjJLCQvU1NBj89KXXt2Rm+lu52pgEuDp4OtiZ6esxAIGtb66gZbazc565WZiBkaeCsiYDAwMjIzMAja4qYaIh/FkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img01.jpg
/* harmony default export */ const about_img01 = ({"src":"/_next/static/media/about_img01.025dbfef.jpg","height":400,"width":400,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAQEBAAAAAAAAAAAAAAAAAAAAAf/aAAwDAQACEAMQAAAAgT//xAAdEAAABQUAAAAAAAAAAAAAAAAAAgMEEhEUMmJx/9oACAEBAAE/AHzRtNG6VyLNU+3aD//EABkRAAIDAQAAAAAAAAAAAAAAAAECAAMhE//aAAgBAgEBPwBbLDvRtM//xAAZEQEAAgMAAAAAAAAAAAAAAAABAxEAAlP/2gAIAQMBAT8AYYuerQFuf//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img02.jpg
/* harmony default export */ const about_img02 = ({"src":"/_next/static/media/about_img02.1fad73a0.jpg","height":621,"width":611,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABf/aAAwDAQACEAMQAAAAoAgb/8QAHBAAAQQDAQAAAAAAAAAAAAAAAgEEEyIAAxES/9oACAEBAAE/ADctycHrlLzClOVQs//EABgRAAIDAAAAAAAAAAAAAAAAAAABAjJy/9oACAECAQE/AIu2j//EABcRAAMBAAAAAAAAAAAAAAAAAAACQXH/2gAIAQMBAT8AW6f/2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img03.jpg
/* harmony default export */ const about_img03 = ({"src":"/_next/static/media/about_img03.c0abb094.jpg","height":1024,"width":1024,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAiwdn/8QAHhAAAAUFAQAAAAAAAAAAAAAAAQMEERMAAgUSFGL/2gAIAQEAAT8AtWlDjhRc5ssr6N4r/8QAGREBAAIDAAAAAAAAAAAAAAAAAQARAgMh/9oACAECAQE/AHa4VQdBn//EABkRAAMAAwAAAAAAAAAAAAAAAAECEQATIf/aAAgBAwEBPwDQr2k8YjP/2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img04.jpg
/* harmony default export */ const about_img04 = ({"src":"/_next/static/media/about_img04.2ddf69e3.jpg","height":375,"width":376,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAKiK/8QAGxAAAgEFAAAAAAAAAAAAAAAAAQIDABEUgsH/2gAIAQEAAT8AZJ86OdA7hGJKA627X//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABYRAAMAAAAAAAAAAAAAAAAAAAABEf/aAAgBAwEBPwCI/9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img05.jpg
/* harmony default export */ const about_img05 = ({"src":"/_next/static/media/about_img05.bb4e5b77.jpg","height":1127,"width":1055,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABwMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAwEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAmFB//8QAHBAAAgICAwAAAAAAAAAAAAAAAgMBBAASERVS/9oACAEBAAE/AOopvqKsyLVCUlIp21KOfZZ//8QAGREAAQUAAAAAAAAAAAAAAAAAAQACEiFB/9oACAECAQE/AItAFYv/xAAYEQEBAQEBAAAAAAAAAAAAAAABAhIAcf/aAAgBAwEBPwCtVS7s8pO//9k=","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img06.jpg
/* harmony default export */ const about_img06 = ({"src":"/_next/static/media/about_img06.6d1e0d70.jpg","height":1600,"width":1600,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAgH//xAAdEAEAAgAHAAAAAAAAAAAAAAACAQQABQYSJGGx/9oACAEBAAE/ABqHLVdgO1x00N/inrH/xAAXEQEAAwAAAAAAAAAAAAAAAAABABGR/9oACAECAQE/AKDZ/8QAGBEAAgMAAAAAAAAAAAAAAAAAAQIAEXH/2gAIAQMBAT8ALFqwT//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img07.jpg
/* harmony default export */ const about_img07 = ({"src":"/_next/static/media/about_img07.8dd076ed.jpg","height":1200,"width":1200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAJcU0//EABwQAAEFAAMAAAAAAAAAAAAAAAMBAgQREwAFIv/aAAgBAQABPwAuxwdeAkWpWmzaT0iEc4jkrn//xAAbEQACAQUAAAAAAAAAAAAAAAABAwIAEiEiMf/aAAgBAgEBPwBbSnkYm7bIr//EABcRAQEBAQAAAAAAAAAAAAAAAAECAAP/2gAIAQMBAT8A42wIBv/Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img08.jpg
/* harmony default export */ const about_img08 = ({"src":"/_next/static/media/about_img08.db976610.jpg","height":897,"width":1515,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAf/aAAwDAQACEAMQAAAAgQP/xAAeEAABAwQDAAAAAAAAAAAAAAACAwQFAAERExJicv/aAAgBAQABPwBrLa4V6lZqkRFqR5F2Exz6xX//xAAWEQEBAQAAAAAAAAAAAAAAAAABABH/2gAIAQIBAT8ADL//xAAXEQEBAQEAAAAAAAAAAAAAAAABAgAR/9oACAEDAQE/AKWnrv/Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img09.jpg
/* harmony default export */ const about_img09 = ({"src":"/_next/static/media/about_img09.002d36fb.jpg","height":447,"width":442,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAkwX/AP/EABwQAAEEAwEAAAAAAAAAAAAAAAQBAgMSAAUGYv/aAAgBAQABPwA3ROH5ocuYRGS0R3qts//EABURAQEAAAAAAAAAAAAAAAAAAAAC/9oACAECAQE/AJf/xAAXEQADAQAAAAAAAAAAAAAAAAAAAkFx/9oACAEDAQE/AHmH/9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/about_img10.jpg
/* harmony default export */ const about_img10 = ({"src":"/_next/static/media/about_img10.70497255.jpg","height":1200,"width":1200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAAL/2gAMAwEAAhADEAAAAIgK/8QAGRABAQEBAQEAAAAAAAAAAAAAAQIDBABS/9oACAEBAAE/ANR59tq20xee8WAhoYEEZPr3/8QAFREBAQAAAAAAAAAAAAAAAAAAEQD/2gAIAQIBAT8AC//EABYRAAMAAAAAAAAAAAAAAAAAAAABAv/aAAgBAwEBPwB0f//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/icons/features_icon01.png
/* harmony default export */ const features_icon01 = ({"src":"/_next/static/media/features_icon01.ee8daf92.png","height":45,"width":45,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AZudnT4dFBF58OXeCPoECgECAwT8DAL57/8FCgHe6u+aAamgmK36FR5S0v0FACL/7QAGAgEA2/0PACP+9QAD6ODKAZWQjb/3EgNAQiPz/BP+7AL+++4A8AYg/sDfGgQB6fHbAYyMidQUGgcrPAiy/vX5DQIAAPsACgfs/8f2WAHq6wDZAZKPicMDGBM8QgKe/gUKGwIAAfcA/fPk/sL7aQL38fXSAZmEdrbZLENJOxf1+yrooQP9+OwA2hdl/r74HgQx1cHGAZyNgoLyFB995BkgAC7t0wAC+/cA1hs3AA3n5AAO4tbOAXBzcCwYBv1oCv/8BfYQHhr9//8O/ObcEvj7+/Tq/ASRhlx+UbYK0J4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/icons/features_icon02.png
/* harmony default export */ const features_icon02 = ({"src":"/_next/static/media/features_icon02.9067c1a7.png","height":45,"width":44,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AZKQjmAnKSh35OjlEQH//wT4AwP6DgcH4hYOEOPp6OjAAZygmMIO9fs9E7q4APX37wAiCxMA5wYCAOQ1MAD+EBcAAZ+clcHPvKk+MzE3/SEZJAIaXmcABgAA/71vWP/0JDECAZ+blLP+99hM4u8M/nt5fwLw7dwAo6HLALTD+ABVROgAAZuanY4jE9dxs7/f/Tg2PgMICBAAxNLhAPr9CgAhEvoAAYqQm4M7Ht585uPX+3KW5wMmJDIAyfIYAUokBv5BMQECAYqJh4gYEQJ38ufdAO70AQD5+PYA8PwKABAUGwAaFAbyAV9YTTMOEx1qCQsLKQ4LBv4BAQIJ+Pj1Cv369tXm6fGiv/NxwoVpaCMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/icons/features_icon03.png
/* harmony default export */ const features_icon03 = ({"src":"/_next/static/media/features_icon03.4a579413.png","height":43,"width":45,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+Aayrp1EiIiVn3NzbA/z59wIDAQAEBAoM/hcUEu/v7u+SAZ2cl8oG/PU1IA7xABwqOwD/AwsA07yUAOD6KAAVGx+0AZSWlakS9dJWSkhA+/IIKQP17uUA+92d/rG/5AQUM1/EAZebm58R7sBgJy0y/ezr3QP39OkAERs8/+Pl7QHj8gbZAZOXmZ4h/sxhCgoP/dXTzAMlJiEAEBAS/tzh6wLpAyvWAYmNj5M8Iv1sAxEr/JGhtwMKDhAAcEgN/u3hswPJ91fGAYWBepwsLCpj9vj+AMfGyQAHDBIARTISAPXx4wDj+iKzAXZya0oODQxl//38Jw8QDgj//v0H7vP78AAECdr/9eujaVp66pBl9I8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./src/app/components/common/text-animation.tsx
var text_animation = __webpack_require__(24876);
;// CONCATENATED MODULE: ./public/assets/img/others/banner.jpg
/* harmony default export */ const banner = ({"src":"/_next/static/media/banner.ff2a5b7f.jpg","height":500,"width":1500,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAMACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAAL/2gAMAwEAAhADEAAAAJgp/8QAHRAAAQMFAQAAAAAAAAAAAAAAIQECEQADBAUSIv/aAAgBAQABPwB411pOWw7G9BCIr//EABYRAQEBAAAAAAAAAAAAAAAAAAEAMf/aAAgBAgEBPwAwv//EABkRAAMAAwAAAAAAAAAAAAAAAAECEgAhMf/aAAgBAwEBPwBWaQaO+5//2Q==","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./src/app/components/about-area/about-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



























function NavBtn({ id, img, isActive }) {
    // handle open search
    const handleClickSound = (audioPath)=>{
        const audio = new Audio(audioPath);
        audio.play();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        className: "nav-item",
        role: "presentation",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            className: `nav-link ${isActive ? "active" : ""}`,
            id: `about${id}-tab`,
            "data-bs-toggle": "tab",
            "data-bs-target": `#about${id}`,
            type: "button",
            role: "tab",
            "aria-controls": `about${id}`,
            "aria-selected": isActive ? "true" : "false",
            tabIndex: -1,
            onClick: ()=>handleClickSound("/assets/audio/tab.mp3"),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "img-shape"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: img,
                    alt: "img"
                })
            ]
        })
    });
}
function TabItem({ id, img, title, isActive, description, subtitle, gameImages, gameDescriptions }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `tab-pane ${isActive ? "show active" : ""}`,
        id: `about${id}`,
        role: "tabpanel",
        "aria-labelledby": `about${id}-tab`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "row justify-content-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-xl-5 col-lg-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "about__img",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: img,
                            alt: title
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-xl-7 col-lg-10",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "about__flex-wrap",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "about__content-wrap",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "about__content",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "title",
                                            children: title
                                        }),
                                        subtitle && /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                            className: "subtitle",
                                            children: subtitle
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: description || "Default description if none is provided."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "about__content-list",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        className: "list-wrap",
                                        children: gameImages && gameDescriptions && gameImages.map((gameImg, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: gameImg,
                                                        alt: gameDescriptions[index]
                                                    }),
                                                    gameDescriptions[index]
                                                ]
                                            }, index))
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
}
const AboutArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "about__area section-pt-130 section-pb-130",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-6 col-lg-7 col-md-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "section__title text-center mb-60",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(text_animation["default"], {
                                    title: "Inside the Game Engine"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "title",
                                    children: "From Pixels to Purpose"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "about__tab-wrap",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-boxes-container",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(text_animation["default"], {
                                            title: "Mission"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(text_animation["default"], {
                                            title: "Vision"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-boxes-container",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-box",
                                            children: "Fusing pixelated quests with real-world strides, we craft realms where gaming pulses sync with heartbeats, amplifying well-being through Move2Earn dynamics."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-box",
                                            children: "In the luminous expanse of Solana, imagine a nexus where every game level ascends you in life, molding every gamer into an avatar of vitality."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: banner,
                                    alt: "Banner Image",
                                    className: "mission-vision-banner"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "title",
                                    children: "Team"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "nav nav-tabs",
                                    id: "myTab",
                                    role: "tablist",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "01",
                                            img: about_tab01,
                                            isActive: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "02",
                                            img: about_tab02
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "03",
                                            img: about_tab03
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "04",
                                            img: about_tab04
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "05",
                                            img: about_tab05
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "06",
                                            img: about_tab06
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "07",
                                            img: about_tab07
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "08",
                                            img: about_tab08
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "09",
                                            img: about_tab09
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavBtn, {
                                            id: "10",
                                            img: about_tab10
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "tab-content",
                    id: "myTabContent",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "01",
                            img: about_img01,
                            isActive: true,
                            title: "jeChilly",
                            subtitle: "Founder",
                            description: "The maestro who dreamed of pixels long before inception. With more game time than your grandmas knitting marathon, Jechilly spearheaded Meta Arcade Club with one joystick in hand and a dream in another.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Master of Pixel Prophecy",
                                "Level 999 Leadership",
                                "Daydreamer Extraordinaire"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "02",
                            img: about_img02,
                            title: "AsterX",
                            subtitle: "Co-Founder",
                            description: "Steering the ship and occasionally falling off it (into the virtual sea, of course). With an uncanny ability to turn bugs into features, Asterx ensures every game is an unforgettable rollercoaster.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Bug Whisperer",
                                "Defender of the Arcade Realm",
                                "Joystick Juggler"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "03",
                            img: about_img03,
                            title: "Munu",
                            subtitle: "Co-Founder",
                            description: "Our secret weapon when the chips are down... or when they're glitching. Munu's the tactical genius who turns every meltdown into a breakthrough.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Crisis Crushinator",
                                "Strategy Sorcerer",
                                "Late-Night Coffee Conjurer"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "04",
                            img: about_img04,
                            title: "RaDesign",
                            subtitle: "Graphic Designer",
                            description: "When he is not painting the Sistine Chapel in pixel art, Radesign ensures our games look like a visual buffet. Every design screams, Eat me! Or...play me?",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Pixel Picasso",
                                "RGB Wrangler",
                                "Master of Visual Spells"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "05",
                            img: about_img05,
                            title: "Hussayn",
                            subtitle: "Full-Stack Game Dev",
                            description: "The digital architect with more layers than an onion. From back-end battles to front-end fiestas, Hussayn's code dances better than most people.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Byte-sized Ballet",
                                "Code Charmer",
                                "Stack Stackler"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "06",
                            img: about_img06,
                            title: "Razvan",
                            subtitle: "Frontend Developer",
                            description: "The guy who ensures our first impressions always pop. Razvan's front-ends are so slick, they slide right off the screen.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Pixel Perfectionist",
                                "Clickbait Creator",
                                "Cascade Commander"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "07",
                            img: about_img07,
                            title: "Vlad",
                            subtitle: "Event Manager",
                            description: "The maestro of mayhem. Vlad ensures our events are smoother than a joystick's glide. If chaos had a rival, it would be him.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Chaos Coordinator",
                                "Pixel Party Planner",
                                "RSVP Ringleader"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "08",
                            img: about_img08,
                            title: "Virtual Partener",
                            subtitle: "Marketing",
                            description: "The shadowy figure turning the gears of hype. Spreading our lore across the metaverse, one viral campaign at a time.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Buzzword Bard",
                                "Meme Magician",
                                "Digital Drumbeater"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "09",
                            img: about_img09,
                            title: "Carlous.eth",
                            subtitle: "Advisor",
                            description: "The sage of the server, the Gandalf of our gaming journey. Guiding us through digital mazes with an ether torch.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Blockchain Brainiac",
                                "Ethereal Explorer",
                                "Wise Wallet Wizard"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(TabItem, {
                            id: "10",
                            img: about_img10,
                            title: "Ciprian",
                            subtitle: "3D Graphic Designer",
                            description: "Sculpting dreams in 3D, Ciprian crafts universes one vertex at a time. If it's got depth, he's dived deep into it.",
                            gameImages: [
                                features_icon01,
                                features_icon02,
                                features_icon03
                            ],
                            gameDescriptions: [
                                "Polygon Poet",
                                "Depth Diver",
                                "Triangular Trailblazer"
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const about_area = (AboutArea);


/***/ }),

/***/ 52547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AboutPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/layout/wrapper.tsx
var wrapper = __webpack_require__(9286);
// EXTERNAL MODULE: ./src/layout/header/header.tsx
var header = __webpack_require__(20685);
// EXTERNAL MODULE: ./src/layout/footer/footer-2.tsx
var footer_2 = __webpack_require__(5894);
// EXTERNAL MODULE: ./src/app/components/breadcrumb/breadcrumb-area.tsx + 1 modules
var breadcrumb_area = __webpack_require__(5080);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21913);
;// CONCATENATED MODULE: ./src/app/components/about-area/about-area.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\about-area\about-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const about_area = (__default__);
// EXTERNAL MODULE: ./src/app/components/video/video-area.tsx
var video_area = __webpack_require__(84244);
;// CONCATENATED MODULE: ./src/app/about/page.tsx





//import AboutAreaThree from "../components/about-area/about-area-3";
//import ServicesArea from "../components/services/services-area";
//import TeamArea from "../components/team/team-area";


function AboutPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(wrapper/* default */.ZP, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main--area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb_area/* default */.Z, {
                        title: "Behind the Pixels",
                        subtitle: "ABOUT US"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(about_area, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(video_area/* default */.ZP, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_2/* default */.ZP, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1697,7546,3773,9232,6438,1257,4250,7531,5343,6410,1220,885,4876], () => (__webpack_exec__(78153)));
module.exports = __webpack_exports__;

})();