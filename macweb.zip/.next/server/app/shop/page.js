(() => {
var exports = {};
exports.id = 3021;
exports.ids = [3021];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 97957:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        'shop',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 90396)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\shop\\page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16660)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\shop\\page.tsx"];
    
    const originalPathname = "/shop/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 78199:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 703));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24369));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99277));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22803));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1841));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55297));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 437));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 58481));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 11265));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45630));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19604));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67089));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45843));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21345));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48796));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62294))

/***/ }),

/***/ 45630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ shop_sidebar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/data/product-data.ts
var product_data = __webpack_require__(38990);
// EXTERNAL MODULE: ./node_modules/react-range/lib/index.js
var lib = __webpack_require__(60707);
;// CONCATENATED MODULE: ./src/app/components/ui/input-range.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const InputRange = ({ STEP, MIN, MAX, values, handleChanges })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(lib.Range, {
            step: STEP,
            min: MIN,
            max: MAX,
            values: values,
            onChange: (vals)=>handleChanges(vals),
            renderTrack: ({ props, children })=>/*#__PURE__*/ (0,react_.createElement)("div", {
                    ...props,
                    key: "track",
                    style: {
                        ...props.style,
                        height: "6px",
                        width: "100%",
                        background: (0,lib.getTrackBackground)({
                            values: values,
                            colors: [
                                "#0d1216",
                                "#00BF58",
                                "#0d1216"
                            ],
                            min: MIN,
                            max: MAX
                        })
                    }
                }, children),
            renderThumb: ({ props, index })=>/*#__PURE__*/ (0,react_.createElement)("div", {
                    ...props,
                    key: `thumb-${index}`,
                    style: {
                        ...props.style,
                        height: "17px",
                        width: "5px",
                        backgroundColor: "#00BF58"
                    }
                })
        })
    });
};
/* harmony default export */ const input_range = (InputRange);

;// CONCATENATED MODULE: ./src/app/components/shop/shop-sidebar.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const ShopSidebar = ()=>{
    const related__products = product_data/* default */.Z.slice(0, 3);
    const [priceValue, setPriceValue] = (0,react_.useState)([
        0,
        380
    ]);
    // handleChanges
    const handleChanges = (val)=>{
        setPriceValue(val);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
        className: "shop-sidebar",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "shop__widget-title",
                        children: "search"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "shop__widget-inner",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "shop__search",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    placeholder: "Search here"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "p-0 border-0",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "flaticon-search"
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "shop__widget-title",
                        children: "filter by price"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "shop__widget-inner",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "shop__price-filter",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    id: "slider-range",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(input_range, {
                                        MAX: 380,
                                        MIN: 0,
                                        STEP: 1,
                                        values: priceValue,
                                        handleChanges: handleChanges
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "shop__price-slider-amount",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "submit",
                                            className: "p-0 border-0",
                                            value: "Filter"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "",
                                            children: [
                                                "$",
                                                priceValue[0],
                                                " - $",
                                                priceValue[1]
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "shop__widget-title",
                        children: "Related products"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "shop__widget-inner",
                        children: related__products.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "related__products-item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "related__products-thumb",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `/shop-details/${item.id}`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: item.img,
                                                alt: "img",
                                                width: 78,
                                                height: 80
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "related__products-content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "product-name",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: `/shop-details/${item.id}`,
                                                    children: item.title
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "amount",
                                                children: [
                                                    "$",
                                                    item.price
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }, item.id))
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__widget",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "shop__widget-title",
                        children: "Categories"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "shop__widget-inner",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "product-categories list-wrap",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/shop",
                                            children: "controller"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "float-right",
                                            children: "12"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/shop",
                                            children: "Headphone"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "float-right",
                                            children: "03"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/shop",
                                            children: "TOURNAMENTS"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "float-right",
                                            children: "18"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/shop",
                                            children: "E-SPORTS"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "float-right",
                                            children: "05"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const shop_sidebar = (ShopSidebar);


/***/ }),

/***/ 90396:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ShopPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/layout/wrapper.tsx
var wrapper = __webpack_require__(9286);
// EXTERNAL MODULE: ./src/layout/header/header.tsx
var header = __webpack_require__(20685);
// EXTERNAL MODULE: ./src/layout/footer/footer.tsx + 6 modules
var footer = __webpack_require__(77954);
// EXTERNAL MODULE: ./src/app/components/breadcrumb/breadcrumb-area-3.tsx
var breadcrumb_area_3 = __webpack_require__(82841);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21913);
;// CONCATENATED MODULE: ./src/app/components/shop/shop-sidebar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\shop\shop-sidebar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const shop_sidebar = (__default__);
// EXTERNAL MODULE: ./src/data/product-data.ts + 9 modules
var product_data = __webpack_require__(18731);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/app/components/shop/shop-item.tsx




const ShopItem = ({ item })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "shop__item",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__item-thumb",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/shop-details/${item.id}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: item.img,
                            alt: "img",
                            style: {
                                width: "auto",
                                height: "auto"
                            }
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "#",
                        className: "wishlist-button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "far fa-heart"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "shop__item-line"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "shop__item-content",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "shop__item-content-top",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "title",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: `/shop-details/${item.id}`,
                                    children: item.title
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "shop__item-price",
                                children: [
                                    "$",
                                    item.price
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "shop__item-cat",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/shop",
                            children: item.category
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const shop_item = (ShopItem);

;// CONCATENATED MODULE: ./src/app/components/shop/shop-area.tsx






const ShopArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "shop-area",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row justify-content-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-3 col-lg-4 col-md-11 order-2 order-lg-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(shop_sidebar, {})
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-xl-9 col-lg-8 col-md-11",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "shop__top-wrap",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "row align-items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-lg-8 col-sm-6",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "shop__showing-result",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Showing 1 - 9 of 15 results"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "col-lg-4 col-sm-6",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "shop__ordering",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                                    name: "orderby",
                                                    className: "orderby",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            defaultValue: "Default sorting",
                                                            children: "Default sorting"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            defaultValue: "Sort by popularity",
                                                            children: "Sort by popularity"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            defaultValue: "Sort by average rating",
                                                            children: "Sort by average rating"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            defaultValue: "Sort by latest",
                                                            children: "Sort by latest"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                            defaultValue: "Sort by latest",
                                                            children: "Sort by latest"
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row justify-content-center row-cols-xl-3 row-cols-lg-2 row-cols-md-2 row-cols-sm-2 row-cols-1",
                                children: product_data/* default */.Z.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(shop_item, {
                                            item: item
                                        })
                                    }, item.id))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "pagination__wrap",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-wrap d-flex flex-wrap justify-content-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "page-numbers",
                                                children: "01"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "page-numbers current",
                                                children: "02"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "page-numbers",
                                                children: "03"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "page-numbers",
                                                children: "...."
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "#",
                                                className: "next page-numbers",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fas fa-angle-double-right"
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const shop_area = (ShopArea);

;// CONCATENATED MODULE: ./src/app/shop/page.tsx






const metadata = {
    title: "Shop Page"
};
function ShopPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(wrapper/* default */.ZP, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main--area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb_area_3/* default */.Z, {
                        title: "NFT COLLECTIONS",
                        subtitle: "OUR SHOP"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(shop_area, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1697,7546,3773,707,4250,7531,8255,2841,1586], () => (__webpack_exec__(97957)));
module.exports = __webpack_exports__;

})();