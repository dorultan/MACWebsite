(() => {
var exports = {};
exports.id = 9404;
exports.ids = [9404];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 33736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        'blog',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2715)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\blog\\page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16660)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\blog\\page.tsx"];
    
    const originalPathname = "/blog/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 70647:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95181));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 96174));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23723));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6061));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8957));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49927));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68487));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34316));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28166));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52233));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19604));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67089));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45843));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21345));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48796));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62294))

/***/ }),

/***/ 2715:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ BlogPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/layout/wrapper.tsx
var wrapper = __webpack_require__(9286);
// EXTERNAL MODULE: ./src/layout/header/header.tsx
var header = __webpack_require__(20685);
// EXTERNAL MODULE: ./src/layout/footer/footer.tsx + 6 modules
var footer = __webpack_require__(77954);
// EXTERNAL MODULE: ./src/app/components/breadcrumb/breadcrumb-area-3.tsx
var breadcrumb_area_3 = __webpack_require__(82841);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./src/app/components/blog/blog-sidebar.tsx + 7 modules
var blog_sidebar = __webpack_require__(86143);
// EXTERNAL MODULE: ./src/data/blog-data.ts + 2 modules
var blog_data = __webpack_require__(88160);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/app/components/blog/blog-item.tsx




const BlogItem = ({ blog })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "blog-post-item",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "blog-post-thumb",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: `/blog-details/${blog.id}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: blog.img,
                        alt: "img",
                        style: {
                            width: "100%",
                            height: "auto"
                        }
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "blog-post-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "blog-post-meta",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-wrap",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        "By",
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `/blog-details/${blog.id}`,
                                            children: blog.author
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "far fa-calendar-alt"
                                        }),
                                        " ",
                                        blog.author
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "far fa-comments"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `/blog-details/${blog.id}`,
                                            children: blog.comments === 0 ? "No comments" : `${blog.comments} comments`
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "title",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: `/blog-details/${blog.id}`,
                            children: blog.title
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: blog.desc
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "blog-post-bottom",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "blog-post-read",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: `/blog-details/${blog.id}`,
                                    children: [
                                        "READ MORE ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-arrow-right"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "blog-post-share",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "share",
                                        children: "share :"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "list-wrap",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: `https://www.facebook.com/`,
                                                    target: "_blank",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fab fa-facebook-f"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: `https://twitter.com/`,
                                                    target: "_blank",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fab fa-twitter"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: `https://www.linkedin.com/`,
                                                    target: "_blank",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fab fa-linkedin-in"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const blog_item = (BlogItem);

;// CONCATENATED MODULE: ./src/app/components/blog/blog-pagination.tsx



const BlogPagination = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
        className: "list-wrap d-flex flex-wrap justify-content-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#",
                    className: "page-numbers",
                    children: "01"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "page-numbers current",
                    children: "02"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#",
                    className: "page-numbers",
                    children: "03"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#",
                    className: "page-numbers",
                    children: "04"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#",
                    className: "page-numbers",
                    children: "...."
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "#",
                    className: "next page-numbers",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fas fa-angle-double-right"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const blog_pagination = (BlogPagination);

;// CONCATENATED MODULE: ./src/app/components/blog/blog-area.tsx






const BlogArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "blog-area",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row justify-content-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "blog-post-wrapper",
                        children: [
                            blog_data/* default */.Z.map((blog)=>/*#__PURE__*/ jsx_runtime_.jsx(blog_item, {
                                    blog: blog
                                }, blog.id)),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "pagination__wrap",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(blog_pagination, {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "blog-post-sidebar",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(blog_sidebar/* default */.Z, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const blog_area = (BlogArea);

;// CONCATENATED MODULE: ./src/app/blog/page.tsx






const metadata = {
    title: "Blog Page"
};
function BlogPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(wrapper/* default */.ZP, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main--area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb_area_3/* default */.Z, {
                        title: "BLOG STANDARD",
                        subtitle: "BLOG LIST"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(blog_area, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1697,7546,3773,4250,7531,8255,2841,6310], () => (__webpack_exec__(33736)));
module.exports = __webpack_exports__;

})();