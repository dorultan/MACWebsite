(() => {
var exports = {};
exports.id = 644;
exports.ids = [644];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 28667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        'tournament',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23703)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\tournament\\page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16660)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\tournament\\page.tsx"];
    
    const originalPathname = "/tournament/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 47478:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12968));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38984));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 11705));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78403));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40565));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84588));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48855));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9747));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24876));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 29595));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23802));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83126));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19234));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13234));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3486));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 79835));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97207))

/***/ }),

/***/ 29595:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99121);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_timer_hook__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48154);
/* harmony import */ var react_timer_hook__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_timer_hook__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const CountdownTimer = ({ expiryTimestamp })=>{
    const { seconds, minutes, hours, days } = (0,react_timer_hook__WEBPACK_IMPORTED_MODULE_3__.useTimer)({
        expiryTimestamp
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "time-count day",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: days
                    }),
                    "Day"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "time-count hour",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: hours
                    }),
                    "hour"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "time-count min",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: minutes
                    }),
                    "min"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "time-count sec",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        suppressHydrationWarning: true,
                        children: seconds
                    }),
                    "sec"
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>Promise.resolve(CountdownTimer), {
    ssr: false
}));


/***/ }),

/***/ 79835:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ tournament_list_item)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/app/components/svg/t-list-bg.tsx


const TournamentBgPath = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "1116.562",
        height: "163.37",
        viewBox: "0 0 1116.562 163.37",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            className: "background-path",
            d: "M708,1784l28-27s4.11-5.76,18-6,702-1,702-1a37.989,37.989,0,0,1,16,9c7.47,7.08,37,33,37,33s9.02,9.47,9,18,0,42,0,42-0.19,9.43-11,19-32,30-32,30-5.53,11.76-21,12-985,0-985,0a42.511,42.511,0,0,1-26-13c-11.433-12.14-34-32-34-32s-6.29-5.01-7-17,0-43,0-43-1-5.42,12-18,34-32,34-32,10.4-8.28,19-8,76,0,76,0a44.661,44.661,0,0,1,21,11c9.268,8.95,22,22,22,22Z",
            transform: "translate(-401.563 -1749.875)"
        })
    });
};
/* harmony default export */ const t_list_bg = (TournamentBgPath);

// EXTERNAL MODULE: ./node_modules/react-timer-hook/dist/index.js
var dist = __webpack_require__(48154);
;// CONCATENATED MODULE: ./src/app/components/tournaments/tournament-list-item.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const TournamentListItem = ({ item, index })=>{
    const expiryTimestamp = new Date(item.coming_time);
    const { seconds, minutes, hours, days } = (0,dist.useTimer)({
        expiryTimestamp
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "tournament__list-item wow fadeInUp",
        "data-wow-delay": `.${index + 2}s`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(t_list_bg, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tournament__list-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tournament__list-thumb",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/tournament-details",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: item.thumb,
                                alt: "thumb",
                                style: {
                                    width: "auto",
                                    height: "auto"
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "tournament__list-name",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                className: "team-name",
                                children: item.team_name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "status",
                                children: item.status
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "tournament__list-prize",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                className: "title",
                                children: "Prize"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fas fa-trophy"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                children: [
                                    "$",
                                    item.box_price
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "tournament__list-time",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                className: "title",
                                children: "Time"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fas fa-clock"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                suppressHydrationWarning: true,
                                children: [
                                    hours,
                                    "h : ",
                                    minutes,
                                    "m : ",
                                    seconds,
                                    "s"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "tournament__list-live",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                            href: item.live_link,
                            target: "_blank",
                            children: [
                                "Live now ",
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "far fa-play-circle"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const tournament_list_item = (TournamentListItem);


/***/ }),

/***/ 23703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ TournamentPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/layout/wrapper.tsx
var wrapper = __webpack_require__(9286);
// EXTERNAL MODULE: ./src/layout/header/header.tsx
var header = __webpack_require__(20685);
// EXTERNAL MODULE: ./src/layout/footer/footer-2.tsx
var footer_2 = __webpack_require__(5894);
// EXTERNAL MODULE: ./src/app/components/breadcrumb/breadcrumb-area.tsx + 1 modules
var breadcrumb_area = __webpack_require__(5080);
// EXTERNAL MODULE: ./src/app/components/team/team-area.tsx + 6 modules
var team_area = __webpack_require__(62487);
;// CONCATENATED MODULE: ./public/assets/img/bg/breadcrumb_bg03.jpg
/* harmony default export */ const breadcrumb_bg03 = ({"src":"/_next/static/media/breadcrumb_bg03.650b3394.jpg","height":565,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAIACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAlAZ//8QAFRABAQAAAAAAAAAAAAAAAAAAAEL/2gAIAQEAAT8Ap//EABURAQEAAAAAAAAAAAAAAAAAAAAB/9oACAECAQE/AK//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/img/others/breadcrumb_img03.png
/* harmony default export */ const breadcrumb_img03 = ({"src":"/_next/static/media/breadcrumb_img03.5b21d25a.png","height":344,"width":407,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA2ElEQVR42mNABpP/r+FVuJWSw7DbLxrEL90YzsTwbL+Hw9vD7oYNLp3sDAcizjBs9/5vsdDoh81U30SwrgdbHCNfbvSxZvj/n61pgfXz8hjB/7YZYv/NanVv////nxGs6PFcWbupp1NtorZ4P4opVvivn2Pzvzrb8ALc7pcHV1r///+fqb43pat+au7/9s7U/5OytLfeWz/fBKzg9o615z+cObh9TymD9+x2v//9KSL/96dzznt+bGc4xPVpcXJ7Fs40+JzPIHGuiOHZhRyhw09zBWQZGBgYAGp7XPiJSa0pAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
;// CONCATENATED MODULE: ./public/assets/img/others/tournament_thumb01.png
/* harmony default export */ const tournament_thumb01 = ({"src":"/_next/static/media/tournament_thumb01.46ff3813.png","height":8335,"width":8334,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAw0lEQVR42mNABseW3+Y6tew2B4qg0///jCD6kfYh9ccKB7XvOx3We8awRxVF0Yz3X2QmffhSWvv/j1/l//9yi55+DFh147U8XEHt/98ydf9/Rzb+/z1x6ecvVZtfv7sU/f+/OFxBxf8/2iX//1o2/f+dtfj9R6fFHz5OKv3/Vw+uYOWlF8oLH7wNKf3/z6rg/3+bnvdf4/o+fpVFcccD9yPaDxyO6F6vOGN2K+eUNkhs0rePjKjeXHGb61LXFTYwB+o7AJl3YnMsc7RYAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/tournament01.jpg
/* harmony default export */ const tournament01 = ({"src":"/_next/static/media/tournament01.be4a0d36.jpg","height":40,"width":40,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAALAqj//EABwQAAIBBQEAAAAAAAAAAAAAAAEDAgAFERQiQf/aAAgBAQABPwDWdG6TcHsKgkcA8Z9BFf/EABoRAAICAwAAAAAAAAAAAAAAAAECAAMEEVP/2gAIAQIBAT8AwmNgv31af//EABoRAQABBQAAAAAAAAAAAAAAAAEAAgMRElL/2gAIAQMBAT8Ardi3ngJ//9k=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/tournament02.jpg
/* harmony default export */ const tournament02 = ({"src":"/_next/static/media/tournament02.3ebc323e.jpg","height":40,"width":40,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAABv/aAAwDAQACEAMQAAAAkA4k/8QAIBAAAAQGAwAAAAAAAAAAAAAAAQIREgAEBRQhIzNDcv/aAAgBAQABPwAhKYE0t9oA7V63M4vS5j//xAAbEQABBAMAAAAAAAAAAAAAAAABAAIDIwQiMf/aAAgBAgEBPwDIgFVjxoOFf//EABoRAAEFAQAAAAAAAAAAAAAAAAQAAQIjMTL/2gAIAQMBAT8AGInbnbr/2Q==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/tournament03.jpg
/* harmony default export */ const tournament03 = ({"src":"/_next/static/media/tournament03.445b19fb.jpg","height":40,"width":40,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAJRH/8QAHRABAAEDBQAAAAAAAAAAAAAAAgEDERIABAUGUf/aAAgBAQABPwBl0eybdHksKZkQqaMk4I2t4tf/xAAXEQADAQAAAAAAAAAAAAAAAAAAAUFx/9oACAECAQE/AFdP/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAFBcf/aAAgBAwEBPwBzD//Z","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/data/tournament-data.ts






const tournament_data = [
    {
        id: 1,
        thumb: tournament_thumb01,
        box_price: 25000,
        coming_time: "2025-10-25",
        subtitle: "TOURNAMENT",
        title: "weekly",
        places: 200,
        live_link: "https://twitter.com/metaarcadeclub",
        team_name: "FoxTie Max",
        status: "Online",
        list_items: [
            {
                id: 1,
                img: tournament01,
                name: "black ninja",
                price: 75000
            },
            {
                id: 2,
                img: tournament02,
                name: "Foxtie Max",
                price: 50000
            },
            {
                id: 3,
                img: tournament03,
                name: "Holam Doxe",
                price: 25000
            }
        ]
    },
    {
        id: 2,
        thumb: tournament_thumb01,
        active: true,
        box_price: 500000,
        coming_time: "2025-11-15",
        subtitle: "TOURNAMENT",
        title: "Lucky card",
        places: 10,
        live_link: "https://twitter.com/metaarcadeclub",
        team_name: "Hatlax TM.",
        status: "Online",
        list_items: [
            {
                id: 1,
                img: tournament01,
                name: "black ninja",
                price: 75000
            },
            {
                id: 2,
                img: tournament02,
                name: "Foxtie Max",
                price: 50000
            },
            {
                id: 3,
                img: tournament03,
                name: "Holam Doxe",
                price: 25000
            }
        ]
    },
    {
        id: 3,
        thumb: tournament_thumb01,
        box_price: 100000,
        coming_time: "2025-9-28",
        subtitle: "TOURNAMENT",
        title: "monthly",
        places: 50,
        live_link: "https://twitter.com/metaarcadeclub",
        team_name: "Spartan iv",
        status: "Online",
        list_items: [
            {
                id: 1,
                img: tournament01,
                name: "black ninja",
                price: 75000
            },
            {
                id: 2,
                img: tournament02,
                name: "Foxtie Max",
                price: 50000
            },
            {
                id: 3,
                img: tournament03,
                name: "Holam Doxe",
                price: 25000
            }
        ]
    }
];
/* harmony default export */ const data_tournament_data = (tournament_data);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21913);
;// CONCATENATED MODULE: ./src/app/components/timer/countdown-timer.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\timer\countdown-timer.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const countdown_timer = (__default__);
;// CONCATENATED MODULE: ./src/app/components/svg/t-box-bg.tsx


const TournamentBoxBgPatch = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                className: "main-bg",
                x: "0px",
                y: "0px",
                viewBox: "0 0 357 533",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M2.00021 63H103C103 63 114.994 62.778 128 50C141.006 37.222 168.042 13.916 176 10C183.958 6.084 193 1.9 213 2C233 2.1 345 1 345 1C347.917 1.66957 350.51 3.33285 352.334 5.70471C354.159 8.07658 355.101 11.0093 355 14C355.093 25.1 356 515 356 515C356 515 357.368 529.61 343 530C328.632 530.39 15.0002 532 15.0002 532C15.0002 532 0.937211 535.85 1.00021 522C1.06321 508.15 2.00021 63 2.00021 63Z",
                    fill: "#19222B",
                    stroke: "#4C4C4C",
                    strokeWidth: "0.25"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                className: "price-bg",
                viewBox: "0 0 166 56",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M0.00792892 55V11C0.00792892 11 -0.729072 0.988 12.0079 1C24.7449 1.012 160.008 0 160.008 0C160.008 0 172.491 1.863 161.008 10C148.995 18.512 115.008 48 115.008 48C115.008 48 110.021 55.238 90.0079 55C69.9949 54.762 0.00792892 55 0.00792892 55Z",
                    fill: "currentcolor"
                })
            })
        ]
    });
};
/* harmony default export */ const t_box_bg = (TournamentBoxBgPatch);

;// CONCATENATED MODULE: ./src/app/components/tournaments/tournament-box.tsx





const TournamentBox = ({ item })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `tournament__box-wrap ${item.active ? "active" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(t_box_bg, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tournament__box-price",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fas fa-trophy"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: item.box_price
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tournament__box-countdown",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "coming-time",
                    "data-countdown": "2023/5/16",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(countdown_timer, {
                        expiryTimestamp: new Date(item.coming_time)
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tournament__box-caption",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "sub",
                        children: item.subtitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "title",
                        children: item.title
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tournament__box-prize",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fas fa-trophy"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        children: [
                            item.places,
                            " prize Places"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "tournament__box-list list-wrap",
                children: item.list_items.map((l)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "tournament__box-list-item",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "tournament__player-thumb",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: l.img,
                                        alt: "img"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    className: "tournament__player-name",
                                    children: l.name
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "tournament__player-price",
                                    children: [
                                        "$ ",
                                        l.price,
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fas fa-bolt"
                                        })
                                    ]
                                })
                            ]
                        })
                    }, l.id))
            })
        ]
    });
};
/* harmony default export */ const tournament_box = (TournamentBox);

// EXTERNAL MODULE: ./src/app/components/common/text-animation.tsx
var text_animation = __webpack_require__(62870);
;// CONCATENATED MODULE: ./src/app/components/tournaments/tournament-area.tsx





const TournamentArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "tournament-area section-pt-120 section-pb-90",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tournament__wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-7 col-md-10",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section__title text-center mb-60",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(text_animation/* default */.ZP, {
                                        title: "Victory Awaits"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "title",
                                        children: "Champions Arena"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center gutter-25",
                        children: data_tournament_data.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-4 col-lg-5 col-md-6 col-sm-9",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(tournament_box, {
                                    item: item
                                })
                            }, item.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const tournament_area = (TournamentArea);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/assets/img/bg/tournament_bg.jpg
/* harmony default export */ const tournament_bg = ({"src":"/_next/static/media/tournament_bg.269afef2.jpg","height":944,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAJOKD//EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./src/app/components/tournaments/tournament-list-item.tsx

const tournament_list_item_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\tournaments\tournament-list-item.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: tournament_list_item_esModule, $$typeof: tournament_list_item_$$typeof } = tournament_list_item_proxy;
const tournament_list_item_default_ = tournament_list_item_proxy.default;


/* harmony default export */ const tournament_list_item = (tournament_list_item_default_);
;// CONCATENATED MODULE: ./src/app/components/tournaments/tournament-list-area.tsx






const TournamentListArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "tournament__list-area section-pb-120 section-pt-120",
        style: {
            backgroundImage: `url(${tournament_bg.src})`
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tournament__wrapper",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row align-items-end mb-60",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-8",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "section__title text-center text-lg-start title-shape-none",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "sub-title tg__animate-text",
                                            children: "tournament List"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "title",
                                            children: "Active tournament"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "section__title-link",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/tournament",
                                        children: "EXPLORE MORE"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "tournament__list-item-wrapper",
                                children: data_tournament_data.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx(tournament_list_item, {
                                        item: item,
                                        index: i
                                    }, item.id))
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const tournament_list_area = (TournamentListArea);

;// CONCATENATED MODULE: ./src/app/tournament/page.tsx










const metadata = {
    title: "Tournament Page"
};
function TournamentPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(wrapper/* default */.ZP, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main--area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb_area/* default */.Z, {
                        title: "Pixel Playoffs",
                        subtitle: "TOURNAMENT & LEADERBOARD",
                        bg: breadcrumb_bg03,
                        brd_img: breadcrumb_img03
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(team_area/* default */.Z, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(tournament_area, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(tournament_list_area, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_2/* default */.ZP, {})
        ]
    });
}


/***/ }),

/***/ 38984:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/breadcrumb_bg03.650b3394.jpg","height":565,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAIACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAlAZ//8QAFRABAQAAAAAAAAAAAAAAAAAAAEL/2gAIAQEAAT8Ap//EABURAQEAAAAAAAAAAAAAAAAAAAAB/9oACAECAQE/AK//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 3486:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tournament_bg.269afef2.jpg","height":944,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAJOKD//EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 11705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/breadcrumb_img03.5b21d25a.png","height":344,"width":407,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA2ElEQVR42mNABpP/r+FVuJWSw7DbLxrEL90YzsTwbL+Hw9vD7oYNLp3sDAcizjBs9/5vsdDoh81U30SwrgdbHCNfbvSxZvj/n61pgfXz8hjB/7YZYv/NanVv////nxGs6PFcWbupp1NtorZ4P4opVvivn2Pzvzrb8ALc7pcHV1r///+fqb43pat+au7/9s7U/5OytLfeWz/fBKzg9o615z+cObh9TymD9+x2v//9KSL/96dzznt+bGc4xPVpcXJ7Fs40+JzPIHGuiOHZhRyhw09zBWQZGBgYAGp7XPiJSa0pAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 83126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tournament01.be4a0d36.jpg","height":40,"width":40,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAALAqj//EABwQAAIBBQEAAAAAAAAAAAAAAAEDAgAFERQiQf/aAAgBAQABPwDWdG6TcHsKgkcA8Z9BFf/EABoRAAICAwAAAAAAAAAAAAAAAAECAAMEEVP/2gAIAQIBAT8AwmNgv31af//EABoRAQABBQAAAAAAAAAAAAAAAAEAAgMRElL/2gAIAQMBAT8Ardi3ngJ//9k=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 19234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tournament02.3ebc323e.jpg","height":40,"width":40,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAABv/aAAwDAQACEAMQAAAAkA4k/8QAIBAAAAQGAwAAAAAAAAAAAAAAAQIREgAEBRQhIzNDcv/aAAgBAQABPwAhKYE0t9oA7V63M4vS5j//xAAbEQABBAMAAAAAAAAAAAAAAAABAAIDIwQiMf/aAAgBAgEBPwDIgFVjxoOFf//EABoRAAEFAQAAAAAAAAAAAAAAAAQAAQIjMTL/2gAIAQMBAT8AGInbnbr/2Q==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 23802:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tournament03.445b19fb.jpg","height":40,"width":40,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABAEBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAJRH/8QAHRABAAEDBQAAAAAAAAAAAAAAAgEDERIABAUGUf/aAAgBAQABPwBl0eybdHksKZkQqaMk4I2t4tf/xAAXEQADAQAAAAAAAAAAAAAAAAAAAUFx/9oACAECAQE/AFdP/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAFBcf/aAAgBAwEBPwBzD//Z","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 13234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tournament_thumb01.46ff3813.png","height":8335,"width":8334,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAw0lEQVR42mNABseW3+Y6tew2B4qg0///jCD6kfYh9ccKB7XvOx3We8awRxVF0Yz3X2QmffhSWvv/j1/l//9yi55+DFh147U8XEHt/98ydf9/Rzb+/z1x6ecvVZtfv7sU/f+/OFxBxf8/2iX//1o2/f+dtfj9R6fFHz5OKv3/Vw+uYOWlF8oLH7wNKf3/z6rg/3+bnvdf4/o+fpVFcccD9yPaDxyO6F6vOGN2K+eUNkhs0rePjKjeXHGb61LXFTYwB+o7AJl3YnMsc7RYAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1697,7546,3773,1257,2000,4250,7531,5343,6410,885,4876,2966], () => (__webpack_exec__(28667)));
module.exports = __webpack_exports__;

})();