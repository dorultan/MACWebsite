(() => {
var exports = {};
exports.id = 3039;
exports.ids = [3039];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 76467:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        'home-2',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 88170)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\home-2\\page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16660)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\home-2\\page.tsx"];
    
    const originalPathname = "/home-2/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 32766:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82389));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 18309));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 74887));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13691));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 53146));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31423));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21763));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25238));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24876));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68328));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23485));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97207));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2881));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9055));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9672));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25891));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83479));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 64125));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 26295));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 17057));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70505));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 30716));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 15318))

/***/ }),

/***/ 74887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ about_area_2)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/assets/img/icons/shape.svg
var shape = __webpack_require__(25238);
// EXTERNAL MODULE: ./src/app/components/common/svg-icon-anim.tsx
var svg_icon_anim = __webpack_require__(68328);
;// CONCATENATED MODULE: ./public/assets/img/icons/circle.svg
/* harmony default export */ const circle = ({"src":"/_next/static/media/circle.903352af.svg","height":138,"width":138,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/img/others/fun_fact_shape.png
/* harmony default export */ const fun_fact_shape = ({"src":"/_next/static/media/fun_fact_shape.66ef3105.png","height":443,"width":511,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAV1BMVEUwKzMwKzIvKzMvKjMuKjMtKjMsKjMrKjMqKjMpKjMoKjQoKjMnKjQmKjQnKTQlKjQmKTQlKTQkKTQjKTQiKTUiKTQhKTQgKTUgKTQfKTUhKDQgKDUfKDSN9holAAAAPUlEQVR42gVAARZAIAz9xSYUa1MT7n9OD9/bJFfruHVn4lXRhRFABV45ToE2uKY5RC4YjyReDsPwy87c/AdbnQLoNVpIXAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/others/fun_fact.png
/* harmony default export */ const fun_fact = ({"src":"/_next/static/media/fun_fact.6eb14288.png","height":557,"width":382,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAYAAAAx8TU7AAAAs0lEQVR4nAGoAFf/AT1U0wAGAguB3wAL0HpR8a9kWeACAQBQAAstvKPqXD/9tnC0QnjcAB3hAQAAPiywkBHNCQY2/fMZGwLo/A6zAXhdTUM2NeG82uki+tfpTZXu5QwuAYeLftLHwvX6BfLDMxQiduKZn1FBAXl8kfnOzQ3ESgObKhVPVhgJGRxsAYh4ezJ4iIXUomtktOkAAgTaExp/AXdsdgCJlIoBrq6luDE+QVS+s7TzHOVIPaxeWowAAAAASUVORK5CYII=","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/icons/trophy.png
/* harmony default export */ const trophy = ({"src":"/_next/static/media/trophy.c50552d4.png","height":94,"width":90,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42mMAgZ9b5XI+tTN8/zKT4e+P7by/fh1VePn/jGEKAwg8Xcu29912jVs/L0X9/7LP++/3nep/f+4z+P98qsjtIxUMsxnuzGY49XKH7dz/fyf8//+97u+vW2Z/32/R+X86kmHZ4QrmWwyXJjKmXu5iOPzrRfn//18r/vy8pPH3+RyZ/4djGTYdLGbKZwCBbQ4Mjh8Oml3899j5/9edLP9vt3Ce2ujNEMAAAnc6GVgYoODbXoZz71bxLmKAgnMFDEwM//+vZARxPuz37P931+3X/cUMTzbmyPmBxA438TMzwMCBNrtjFxc6/l9byP+/K1CmEyQ2PVacBQDMfHk9ef0wLwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./src/app/components/common/video-popup.tsx
var video_popup = __webpack_require__(13481);
// EXTERNAL MODULE: ./node_modules/react-countup/build/index.js
var build = __webpack_require__(70056);
// EXTERNAL MODULE: ./node_modules/react-intersection-observer/index.mjs
var react_intersection_observer = __webpack_require__(81257);
;// CONCATENATED MODULE: ./src/app/components/common/counter-up.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const CounterUp = ({ number, text, add_style })=>{
    const [focus, setFocus] = (0,react_.useState)(false);
    const visibleChangeHandler = (isVisible)=>{
        if (isVisible) {
            if (!focus) {
                setFocus(true);
            }
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(build/* default */.ZP, {
            start: focus ? 0 : undefined,
            end: number,
            duration: 5,
            children: ({ countUpRef })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `d-flex ${add_style ? "align-items-center justify-content-center" : ""} `,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            ref: countUpRef
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_intersection_observer/* InView */.df, {
                            as: "span",
                            onChange: (inView)=>visibleChangeHandler(inView),
                            className: "odometer"
                        }),
                        text && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "formatting-mark",
                            children: text
                        })
                    ]
                })
        })
    });
};
/* harmony default export */ const counter_up = (CounterUp);

;// CONCATENATED MODULE: ./src/app/components/about-area/about-area-2.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 











const AboutAreaTwo = ()=>{
    const [isVideoOpen, setIsVideoOpen] = (0,react_.useState)(false);
    const imgStyle = {
        height: "auto",
        width: "auto"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "about__area-two section-pt-160 section-pb-190",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row justify-content-center align-items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-xl-6 col-lg-6 order-0 order-lg-2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "about__funFact-images",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: fun_fact_shape,
                                                alt: "background",
                                                className: "bg-shape"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: fun_fact,
                                                className: "main-img",
                                                alt: "image",
                                                style: {
                                                    height: "auto"
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "about__funFact-trophy",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "icon",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: trophy,
                                                    alt: "trophy",
                                                    style: imgStyle
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "content",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                        children: "Tournament"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "Development"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-xl-6 col-lg-6 col-md-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "section__title text-start mb-30",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                            className: "title",
                                            children: [
                                                "The Journey of The ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                " NFT Sites"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "about__content-two",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Gorem npsum dolor sit amet consectetur adipiscing elit. Duis elementum sollici tudin augue euismod. Nulla ullamcorper nunc. Morbi pharetra mi tellus mollis tincidunt massa venenatis. Etiam lacinia ipsumultrices."
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "about__content-bottom",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "about__content-circle",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: circle,
                                                        alt: "img",
                                                        style: imgStyle
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        viewBox: "0 0 150 150",
                                                        version: "1.1",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                id: "textPath",
                                                                d: "M 0,75 a 75,75 0 1,1 0,1 z"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("textPath", {
                                                                    href: "#textPath",
                                                                    children: "super nft Gaming sits"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "about__funFact-wrap",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "about__funFact-lists",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "about__funFact-item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                                        className: "count",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(counter_up, {
                                                                            number: 40,
                                                                            text: "K"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                        children: "Member"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "about__funFact-item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                                        className: "count",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(counter_up, {
                                                                            number: 12,
                                                                            text: "K"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                        children: "NFT"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                className: "about__funFact-item",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                                        className: "count",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(counter_up, {
                                                                            number: 30,
                                                                            text: "K"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                        children: "Artist"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "about__content-btns",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                                href: "/contact",
                                                                className: "tg-btn-3 tg-svg",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx(svg_icon_anim["default"], {
                                                                        icon: shape["default"],
                                                                        id: "svg-6"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        children: "read more"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                                className: "popup-video cursor-pointer",
                                                                onClick: ()=>setIsVideoOpen(true),
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "fas fa-play"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                        className: "text",
                                                                        children: "How It Work"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(video_popup/* default */.Z, {
                isVideoOpen: isVideoOpen,
                setIsVideoOpen: setIsVideoOpen,
                videoId: "ssrNcwxALS4"
            })
        ]
    });
};
/* harmony default export */ const about_area_2 = (AboutAreaTwo);


/***/ }),

/***/ 15318:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ brand_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var lib = __webpack_require__(17738);
;// CONCATENATED MODULE: ./public/assets/img/brand/brand01.png
/* harmony default export */ const brand01 = ({"src":"/_next/static/media/brand01.10548ce1.png","height":56,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAQAAABUDBdwAAAAYElEQVR42g3KIQ6CABQA0H8Rz2M3u5ksBowy1DE3IZikOKebxeRmgEqlMrjRG9S3F3qlvVordTCGStjaWVpYu83gpHOV+Pl6hJdMrlQ4O/qEp8xGopBamcfdW+XvopEbJm6jSLePXlfzAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/assets/img/brand/brand02.png
/* harmony default export */ const brand02 = ({"src":"/_next/static/media/brand02.f1db7900.png","height":57,"width":94,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAQAAADSmGXeAAAAUElEQVR42g3Euw2CABgGwM/GxNIVHEUH8BEncBArB5CKjUgILQklPS39/XDFRTyVi7/FySFiUG4YReKu/HyVl493zMpV6eyrmDTOVg9HvXYD6oM9JGc8sVMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/brand/brand03.png
/* harmony default export */ const brand03 = ({"src":"/_next/static/media/brand03.f9dd488d.png","height":38,"width":175,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAQAAADPnVVmAAAAKUlEQVR42gXAQQoAERQAUHeaGhH6UjZy/9u8lCzTFart6MmQhd+nCeUBWSITzZXyu5MAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/img/brand/brand04.png
/* harmony default export */ const brand04 = ({"src":"/_next/static/media/brand04.b4c9ca08.png","height":27,"width":144,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAQAAADPnVVmAAAALElEQVR42mP40vol8Ivdl6Av2V99v7h/CWD40vCl92vNl7Iv6V/Kv3Z8LQcAb5wV1lq2WNQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/assets/img/brand/brand05.png
/* harmony default export */ const brand05 = ({"src":"/_next/static/media/brand05.4546775a.png","height":56,"width":79,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAQAAABUDBdwAAAAU0lEQVR42g3G0QlAAABF0ffDOFawBCOYwJd//iyhTGACZQqxgIyg7vM6dbui58QM4VwvbkbMF2biEmZlTp0uWJgN8YTYSV6qtA5x0IkWUaAoadAPNJFK6uDAWQQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/assets/img/brand/brand06.png
/* harmony default export */ const brand06 = ({"src":"/_next/static/media/brand06.44a0c5d3.png","height":12,"width":135,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAIElEQVR4nGP89+9fKgMDAzsQcwHxVyAWAuLXQAxifwUAiKoHTokpe4QAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./public/assets/img/brand/brand07.png
/* harmony default export */ const brand07 = ({"src":"/_next/static/media/brand07.fafebb45.png","height":56,"width":103,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAQAAAAZxLZ7AAAARUlEQVR42gXAoRVAQBgA4D+4pNvBInawjAk072mSwA52EIxwmqYK33khCaNObxBSCI1LtihaEWrZ7nE43aqwKV6zYvJZf/AiME5wVUTFAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./src/app/components/brand/brand-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 











// slider setting
const slider_setting = {
    dots: false,
    infinite: true,
    speed: 500,
    autoplay: true,
    arrows: false,
    slidesToShow: 6,
    slidesToScroll: 2,
    responsive: [
        {
            breakpoint: 1200,
            settings: {
                slidesToShow: 5,
                slidesToScroll: 1,
                infinite: true
            }
        },
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows: false
            }
        },
        {
            breakpoint: 575,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                arrows: false
            }
        }
    ]
};
// brands
const brands = [
    brand01,
    brand02,
    brand03,
    brand04,
    brand05,
    brand06,
    brand07,
    brand02,
    brand05
];
const BrandArea = ()=>{
    const [hoveredIndex, setHoveredIndex] = (0,react_.useState)(null);
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "brand-area",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "brand__title text-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "title",
                                children: "they trust us"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(lib/* default */.Z, {
                    ...slider_setting,
                    className: "row brand-active",
                    children: brands.map((b, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "brand__item",
                                onMouseEnter: ()=>setHoveredIndex(i),
                                onMouseLeave: ()=>setHoveredIndex(null),
                                style: {
                                    opacity: hoveredIndex === null || hoveredIndex === i ? 1 : 0.3,
                                    transition: "opacity 0.3s"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "#",
                                    className: "brand__link",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: b,
                                        alt: "brand",
                                        style: {
                                            width: "auto",
                                            height: "auto"
                                        }
                                    })
                                })
                            })
                        }, i))
                })
            ]
        })
    });
};
/* harmony default export */ const brand_area = (BrandArea);


/***/ }),

/***/ 2316:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_18_image_lightbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11230);



const ImageLightBox = ({ images, open, setOpen, photoIndex, setPhotoIndex })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_18_image_lightbox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            mainSrc: images[photoIndex],
            nextSrc: images[(photoIndex + 1) % images.length],
            prevSrc: images[(photoIndex + images.length - 1) % images.length],
            onCloseRequest: ()=>setOpen(false),
            onMovePrevRequest: ()=>setPhotoIndex((photoIndex + images.length - 1) % images.length),
            onMoveNextRequest: ()=>setPhotoIndex((photoIndex + 1) % images.length)
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageLightBox);


/***/ }),

/***/ 13481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_modal_video__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16438);



const VideoPopup = ({ isVideoOpen, setIsVideoOpen, videoId = "B0WuqoXkJkY" })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_modal_video__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        channel: "youtube",
        isOpen: isVideoOpen,
        videoId: videoId,
        onClose: ()=>setIsVideoOpen(false)
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VideoPopup);


/***/ }),

/***/ 18309:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ hero_banner_2)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/assets/img/slider/banner_bg.jpg
/* harmony default export */ const banner_bg = ({"src":"/_next/static/media/banner_bg.91e9ee50.jpg","height":880,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQX/2gAMAwEAAhADEAAAAI0UT//EABoQAQACAwEAAAAAAAAAAAAAAAIBEQAEMUH/2gAIAQEAAT8Ah0NcwDVJc9jP/8QAFhEAAwAAAAAAAAAAAAAAAAAAAAIx/9oACAECAQE/AHp//8QAFxEAAwEAAAAAAAAAAAAAAAAAAAMygf/aAAgBAwEBPwBU6f/Z","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./public/assets/img/icons/shape.svg
var shape = __webpack_require__(25238);
// EXTERNAL MODULE: ./src/app/components/common/svg-icon-anim.tsx
var svg_icon_anim = __webpack_require__(68328);
;// CONCATENATED MODULE: ./src/app/components/hero-banner/hero-banner-2.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const HeroBannerTwo = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "banner__area banner__padding",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "banner__bg tg-jarallax",
                style: {
                    backgroundImage: `url(${banner_bg.src})`
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container custom-container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-8 col-lg-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "banner__content slider__content text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "title wow bounceInLeft",
                                    "data-wow-delay": ".2s",
                                    children: "steaming"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "wow bounceInLeft",
                                    "data-wow-delay": ".4s",
                                    children: "video games online"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "banner__btn wow bounceInLeft",
                                    "data-wow-delay": ".6s",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/contact",
                                        className: "tg-btn-3 tg-svg mx-auto",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(svg_icon_anim["default"], {
                                                icon: shape["default"],
                                                id: "svg-1"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "contact us"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const hero_banner_2 = (HeroBannerTwo);


/***/ }),

/***/ 70505:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ project_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/swiper/swiper-react.mjs + 3 modules
var swiper_react = __webpack_require__(25373);
// EXTERNAL MODULE: ./node_modules/swiper/modules/index.mjs + 26 modules
var modules = __webpack_require__(38664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_01.jpg
/* harmony default export */ const project_01 = ({"src":"/_next/static/media/project_01.d87dc2e5.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAgT/2gAMAwEAAhADEAAAAJomf//EABwQAAICAgMAAAAAAAAAAAAAAAECAxESQQAEcf/aAAgBAQABPwAQdfFVZIDhSg1egde8/8QAFhEBAQEAAAAAAAAAAAAAAAAAAgEA/9oACAECAQE/AG0VZLv/xAAXEQEBAQEAAAAAAAAAAAAAAAACAQAD/9oACAEDAQE/AOYKBtm//9k=","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_02.jpg
/* harmony default export */ const project_02 = ({"src":"/_next/static/media/project_02.a1331d91.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAgEBAAAAAAAAAAAAAAAAAAAABP/aAAwDAQACEAMQAAAAgML/AP/EABsQAAIDAAMAAAAAAAAAAAAAAAECAxESAAVC/9oACAEBAAE/AH7NIREqYoRKKDazXnn/xAAYEQACAwAAAAAAAAAAAAAAAAABAgADIf/aAAgBAgEBPwBakKjJ/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECA//aAAgBAwEBPwCtbbP/2Q==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_03.jpg
/* harmony default export */ const project_03 = ({"src":"/_next/static/media/project_03.398489b8.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAABAX/2gAMAwEAAhADEAAAAJQkJ//EABwQAAICAgMAAAAAAAAAAAAAAAECAxEABAUUcf/aAAgBAQABPwBuQi7EoGm8oUKq1S0o9z//xAAZEQACAwEAAAAAAAAAAAAAAAABAgASQTL/2gAIAQIBAT8AdEtzg0z/xAAYEQACAwAAAAAAAAAAAAAAAAABAgAxQf/aAAgBAwEBPwBWYi9M/9k=","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_04.jpg
/* harmony default export */ const project_04 = ({"src":"/_next/static/media/project_04.4e673284.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAhgD/AP/EABwQAQABBAMAAAAAAAAAAAAAAAMBAAITIQQFEf/aAAgBAQABPwDtBBlMuEtqYDx33rHk6nVf/8QAFhEBAQEAAAAAAAAAAAAAAAAAAQAC/9oACAECAQE/ADSBf//EABgRAQADAQAAAAAAAAAAAAAAAAEAAgMR/9oACAEDAQE/ANc6V0sBwGf/2Q==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_05.jpg
/* harmony default export */ const project_05 = ({"src":"/_next/static/media/project_05.6e623e98.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAAL/2gAMAwEAAhADEAAAAIUW/8QAHxAAAQMDBQAAAAAAAAAAAAAAAwECEgAEBRETIjFB/9oACAEBAAE/AEDj7obGmiPb1RI8e/K//8QAFREBAQAAAAAAAAAAAAAAAAAAABH/2gAIAQIBAT8Ar//EABoRAAAHAAAAAAAAAAAAAAAAAAACAxESIUH/2gAIAQMBAT8AUeZr0f/Z","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_06.jpg
/* harmony default export */ const project_06 = ({"src":"/_next/static/media/project_06.06fd0d02.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAI0G3//EABsQAAMAAgMAAAAAAAAAAAAAAAECAwARBRTR/9oACAEBAAE/AOzw7yjMrVTNNEqVXfuf/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAERIf/aAAgBAgEBPwBYpT//xAAXEQEBAQEAAAAAAAAAAAAAAAABEQAC/9oACAEDAQE/AHqtQ3//2Q==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_07.jpg
/* harmony default export */ const project_07 = ({"src":"/_next/static/media/project_07.fa5bf68b.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABQEBAQAAAAAAAAAAAAAAAAAAAAP/2gAMAwEAAhADEAAAAIYg/8QAHRAAAQIHAAAAAAAAAAAAAAAAAgEDAAQFERIhMf/aAAgBAQABPwAZuno0Oba7IrLyP//EABYRAAMAAAAAAAAAAAAAAAAAAAABEv/aAAgBAgEBPwCEf//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/gallery/project_08.jpg
/* harmony default export */ const project_08 = ({"src":"/_next/static/media/project_08.02904acd.jpg","height":436,"width":277,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABQMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQT/2gAMAwEAAhADEAAAAI0NX//EABwQAAICAgMAAAAAAAAAAAAAAAEDAhEAEwRRYf/aAAgBAQABPwBnHWswXoO2K4hghV33L05//8QAFhEAAwAAAAAAAAAAAAAAAAAAAAEx/9oACAECAQE/AHT/xAAZEQEAAgMAAAAAAAAAAAAAAAABAAIDERL/2gAIAQMBAT8AxhxXYT//2Q==","blurWidth":5,"blurHeight":8});
// EXTERNAL MODULE: ./src/app/components/common/text-animation.tsx
var text_animation = __webpack_require__(24876);
// EXTERNAL MODULE: ./src/app/components/common/image-lightbox.tsx
var image_lightbox = __webpack_require__(2316);
;// CONCATENATED MODULE: ./src/app/components/projects/project-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 














// slider setting
const slider_setting = {
    slidesPerView: 4,
    spaceBetween: 15,
    breakpoints: {
        "1500": {
            slidesPerView: 4
        },
        "1200": {
            slidesPerView: 4
        },
        "992": {
            slidesPerView: 3
        },
        "768": {
            slidesPerView: 3
        },
        "576": {
            slidesPerView: 2
        },
        "0": {
            slidesPerView: 1.5,
            centeredSlides: true,
            centeredSlidesBounds: true
        }
    },
    navigation: {
        nextEl: ".slider-button-next",
        prevEl: ".slider-button-prev"
    },
    scrollbar: {
        el: ".swiper-scrollbar",
        draggable: true,
        dragSize: 24
    }
};
// project data
const project_data = [
    project_01,
    project_02,
    project_03,
    project_04,
    project_05,
    project_06,
    project_07,
    project_08
];
const ProjectArea = ()=>{
    // photoIndex
    const [photoIndex, setPhotoIndex] = (0,react_.useState)(0);
    // image open state
    const [open, setOpen] = (0,react_.useState)(false);
    // images
    const images = project_data.map((img)=>img.src);
    // handleImagePopup
    const handleImagePopup = (index)=>{
        setPhotoIndex(index);
        setOpen(true);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "project-area project-bg section-pt-120 section-pb-140",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container custom-container",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "project__wrapper",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "section__title text-start",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "title",
                                            children: "PROJECTS MYKD"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(text_animation["default"], {
                                            title: "our LATEST gallery"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* Swiper */.tq, {
                                    ...slider_setting,
                                    modules: [
                                        modules/* Navigation */.W_,
                                        modules/* Scrollbar */.LW
                                    ],
                                    className: "swiper-container project-active",
                                    children: project_data.map((p, i)=>/*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "project__item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    onClick: ()=>handleImagePopup(i),
                                                    className: "popup-image cursor-pointer",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: p,
                                                        alt: "img"
                                                    })
                                                })
                                            })
                                        }, i))
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "slider-button-prev",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "flaticon-right-arrow"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "flaticon-right-arrow"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "swiper-scrollbar"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(image_lightbox/* default */.Z, {
                images: images,
                open: open,
                setOpen: setOpen,
                photoIndex: photoIndex,
                setPhotoIndex: setPhotoIndex
            })
        ]
    });
};
/* harmony default export */ const project_area = (ProjectArea);


/***/ }),

/***/ 23485:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ streamers_area)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/swiper/swiper-react.mjs + 3 modules
var swiper_react = __webpack_require__(25373);
// EXTERNAL MODULE: ./node_modules/swiper/modules/index.mjs + 26 modules
var modules = __webpack_require__(38664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/team/streamers01.png
/* harmony default export */ const streamers01 = ({"src":"/_next/static/media/streamers01.d811f65a.png","height":355,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAiElEQVR42mNQVXa21PNMCkgy0w/R0fBh0NEMD7OOnJyV5WuZaa6VxOBvWGYtFxbp4FSZUBdkWcKQaleX4BpaFpnYHpfVkFrBEOue0RSfObugMtbM21TXkSE+ONPfJsLDwE1J3JSBQZohMiJNS85RTkBHU8ZcQ9aGwdY6QE3U1EDKzEDdVU/NCwALMCGu0YtFYwAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/streamers02.png
/* harmony default export */ const streamers02 = ({"src":"/_next/static/media/streamers02.7be28661.png","height":355,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAiElEQVR42mNISkqKCA8L8PMPCw23srJhmDRpQlNddX1RXkVZeUZGJkN9dVZ8dKSPg11Gekp1ZQmDsoKEl5dHaGiItJySv5cHg66uXnCQn5e3t6mZhYWZIYOujo65ubGCqlZogF+ggx2DqLg4F5+ksISckbZusKs7g7q6ur6ujoG+rqiEtKOjIwC5USDybyIcEAAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/streamers03.png
/* harmony default export */ const streamers03 = ({"src":"/_next/static/media/streamers03.563967cc.png","height":355,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAiElEQVR42mOIjE3PLanVNXbS1rVRUjNhcA9IXLpyS19XHwODrLmlCwMDg1x8amldaZWajk1oZBKDkbFDfHZZc32zk0dwQGAEg7WRua6xbUBwjKNHkJaGEYOsgraOvrWqlpmQhIqErCaDkrqhhJyGuIyGpJyGsIQSA6+wLLegDL+oAp+IPJ+IHACJDBwo6EoywQAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/streamers04.png
/* harmony default export */ const streamers04 = ({"src":"/_next/static/media/streamers04.ecca60e2.png","height":355,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAgElEQVR42mPQ1LV2d/VzMrXXN7LT1DJl0NKz8LAyjzVRk5LT0NQ0ZXCwd7ayckyIy/AOSTKx9mRI8HZLiEoMS8j3dXF3d3BlCHZ1t9A3YmNg0FFWsza2YBCU0VDXMpSSVOAXV9RSUmIQkVASk1YRFlcQFpcXk1Jm4BOR4xOFI3kAoU4WoQpYmJAAAAAASUVORK5CYII=","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/streamers05.png
/* harmony default export */ const streamers05 = ({"src":"/_next/static/media/streamers05.c2b49720.png","height":355,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAgUlEQVR42mOQUTZ2sXez1bGrrwupqQlmYJAwyA8Pqg3zbE53LPaxZlBTN03LzKtICk+3d0mzdmDQ0rOMCQv1sjL1dXI20LFgkFDUjQ8J9bazV5bXklc1ZFBQ0VXSNtLW0FSWVxOX0WAQlVIWk1ERlFAQkVEWElNk4BORAyFROQgDANPTGaZgm+4gAAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/streamers06.png
/* harmony default export */ const streamers06 = ({"src":"/_next/static/media/streamers06.2038a951.png","height":355,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAiElEQVR42mMw03RmUHcQUDUVUTTIUjRlYGAQLqqoa84udBCTaRJRZ2AQUKpLT4wNjcxycPGSUWUQk1Uy9E5yTShOcAvXYGBg0DK09g6MTcisstU29wtPZKhp6qyobbd08fdmEF2ydguDb2Q8p6gkAwO/hqpBUHImA4OoPJuEMqOiMa+KOQODFABuQhzrl+f8LwAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/team/streamers07.png
/* harmony default export */ const streamers07 = ({"src":"/_next/static/media/streamers07.ec3377d4.png","height":355,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAgUlEQVR42mMAAV6L9JR0QWVlELtKXSVcO7o0uyI3PgzEn27s3uDsH6NjmZOZYq/hyOAs5WSube1uZRKQkuKVXs5gKubpbWmTGR2ub2rgXF7HUCzrZqBhbaerpq6uGh8VwRAhKKvJZWRpaqNnZRvo6cWQrKOnxSMnyierqabOqKABACcgG8il7yFTAAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});
// EXTERNAL MODULE: ./src/app/components/common/text-animation.tsx
var text_animation = __webpack_require__(24876);
;// CONCATENATED MODULE: ./src/app/components/streamers/streamers-area.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 













// slider data
const streamers_data = [
    {
        id: 1,
        img: streamers01,
        title: "sky hunter"
    },
    {
        id: 2,
        img: streamers02,
        title: "Phoenix"
    },
    {
        id: 3,
        img: streamers03,
        title: "Max Jett"
    },
    {
        id: 4,
        img: streamers04,
        title: "Brimstone"
    },
    {
        id: 5,
        img: streamers05,
        title: "Mad Raze"
    },
    {
        id: 6,
        img: streamers06,
        title: "Jackie Welles"
    },
    {
        id: 7,
        img: streamers07,
        title: "Yorinobu Ara"
    }
];
// slider setting
const slider_setting = {
    observer: true,
    observeParents: true,
    loop: false,
    slidesPerView: 5,
    spaceBetween: 20,
    breakpoints: {
        "1500": {
            slidesPerView: 5
        },
        "1200": {
            slidesPerView: 4
        },
        "992": {
            slidesPerView: 4
        },
        "768": {
            slidesPerView: 3
        },
        "576": {
            slidesPerView: 2
        },
        "0": {
            slidesPerView: 1.5,
            centeredSlides: true,
            centeredSlidesBounds: true
        }
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true
    },
    navigation: {
        nextEl: ".slider-button-next",
        prevEl: ".slider-button-prev"
    }
};
const StreamersArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "streamers__area section-pt-95 section-pb-120",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-6 col-lg-7 col-md-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "section__title text-center mb-60",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(text_animation["default"], {
                                    title: "Our top streamers"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "title",
                                    children: "top rated streamers"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* Swiper */.tq, {
                    ...slider_setting,
                    modules: [
                        modules/* Navigation */.W_,
                        modules/* Pagination */.tl
                    ],
                    className: "swiper-container streamers-active",
                    children: streamers_data.map((item, i)=>/*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "streamers__item",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "streamers__thumb",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/team-details",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: item.img,
                                                alt: "img",
                                                style: {
                                                    height: "auto",
                                                    width: "100%"
                                                }
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "streamers__content",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            className: "name",
                                            children: item.title
                                        })
                                    })
                                ]
                            })
                        }, item.id))
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "streamers__pagination",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "slider-button-prev streamers__pagination-arrow",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fas fa-angle-left"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "swiper-pagination streamers__pagination-dots"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "slider-button-next streamers__pagination-arrow",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fas fa-angle-right"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const streamers_area = (StreamersArea);


/***/ }),

/***/ 62870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21913);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\common\text-animation.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 88170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HomeTwo),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/layout/wrapper.tsx
var wrapper = __webpack_require__(9286);
// EXTERNAL MODULE: ./src/layout/header/header.tsx
var header = __webpack_require__(20685);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21913);
;// CONCATENATED MODULE: ./src/app/components/hero-banner/hero-banner-2.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\hero-banner\hero-banner-2.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const hero_banner_2 = (__default__);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/bg/result_bg.png
/* harmony default export */ const result_bg = ({"src":"/_next/static/media/result_bg.a453ab2e.png","height":769,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAZElEQVR4nA3JSQqEMBRF0fdsUiRFDQps4kjd/0KcuAkXIDhQbPO/4U4uHJa+HRHo0sJ8P83PJv/cCoM7hnmTRyZWdacgkamBOR2wCE6sEC/QGCvfB8RJk5wms1AqL9kh162I8AJGGSO5oSnd+gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/assets/img/icons/win_shape.svg
/* harmony default export */ const win_shape = ({"src":"/_next/static/media/win_shape.95770d4e.svg","height":75,"width":135,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/img/icons/shape.svg
/* harmony default export */ const shape = ({"src":"/_next/static/media/shape.5be839ef.svg","height":61,"width":188,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/img/others/win01.png
/* harmony default export */ const win01 = ({"src":"/_next/static/media/win01.d048f858.png","height":249,"width":207,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA80lEQVR4nAHoABf/AQAA/wKPp5j+w+iZfuvaQYEPH76DOxRefsJkVQMBANkABb8LqkW1q8Ga4KHzGyhiIu05UgVOC8d6xgGZtKTU8+b+K+3q8QAgExr9+QMJAwcM+wD2C92iAXOUkO3NrNcSDRgX/ggSFAIG/v78EhcZBAoe4KQBXItQwgfWIj3t3M/+/AETArTC7/5xajAC8SfengF9qXyW+eAyaQMAAfze39wCLywwAQH17QHN9JzcAXyreGD24x2c/fUHA/z2BAADDPr/AQr9/QsjsU8BlP8AAqu6ABI362JaAPUtdOsHcWMHGADTMyxY6yTbaLkx89mQAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/win02.png
/* harmony default export */ const win02 = ({"src":"/_next/static/media/win02.333558cb.png","height":249,"width":225,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA80lEQVR4nAHoABf/AZG36gXe+f/7ou36Nxvz/WrUcB1xAHIC8ADz/hYBecT0AIfkAS+5IvbAEAT6EOTw/9jj2dkB/wANDAFg4v8sVermykcvFQnh4vD8EhEIBO7u7wC2vOHXAXy6+eJUFPAd6+/u/PXz9QQ7PCX76en0BbjE8ooBWcT+Ww3C06D+3tAEh4dR/wICAP/c3OUC7PD9YAH7/f86u8bzoBQJ9SUNDAT95OPn//379QQeHhBkAdfa8gADAAFvBAb7kOfl7ADw8PMA9Pb9+UFCMyQBw8bsAB0cCWfk5fFJ2O3+JeDoAhLy8Qm3kr4QadiugGWE8Rp/AAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./src/app/components/common/svg-icon-anim.tsx

const svg_icon_anim_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\common\svg-icon-anim.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: svg_icon_anim_esModule, $$typeof: svg_icon_anim_$$typeof } = svg_icon_anim_proxy;
const svg_icon_anim_default_ = svg_icon_anim_proxy.default;


/* harmony default export */ const svg_icon_anim = (svg_icon_anim_default_);
// EXTERNAL MODULE: ./src/app/components/common/text-animation.tsx
var text_animation = __webpack_require__(62870);
;// CONCATENATED MODULE: ./src/app/components/match-result/match-result-area.tsx











// img style 
const imgStyle = {
    height: "auto"
};
function MatchWinnerItem({ name, amount, img, id, place }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "match__winner-wrap",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "match__winner-info",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "name",
                        children: name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "price-amount",
                        children: [
                            "$",
                            amount
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "match__winner-img tg-svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "team-logo-img",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/team-details",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: img,
                                alt: "img",
                                style: imgStyle
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(svg_icon_anim, {
                        icon: win_shape,
                        id: `svg-${id}`
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "match__winner-place",
                        children: place
                    })
                ]
            })
        ]
    });
}
const MatchResultArea = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "match__result-area",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "match__result-bg",
                style: {
                    backgroundImage: `url(${result_bg.src})`
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row justify-content-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-7 col-md-10",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "section__title text-center mb-55",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(text_animation/* default */.ZP, {
                                        title: "LATEST RESULTS FOR"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "title",
                                        children: "EXPERIENCE JUST FOR"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "match__winner-title",
                                children: "Premier league"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row match__result-wrapper justify-content-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-5 col-sm-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(MatchWinnerItem, {
                                    name: "black hunt",
                                    amount: "500 000",
                                    img: win01,
                                    id: "3",
                                    place: "win"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xl-5 col-sm-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(MatchWinnerItem, {
                                    name: "sky Hunter",
                                    amount: "300 000",
                                    img: win02,
                                    id: "4",
                                    place: "2nd"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grand__final",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                        className: "grand__final-date",
                                        children: "December 19, 2021 | 9:50 am"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "grand__final-place",
                                        children: "grand dubai"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "grand__final-button",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "/contact",
                                            className: "tg-btn-3 tg-svg mx-auto",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(svg_icon_anim, {
                                                    icon: shape,
                                                    id: "svg-5"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "read more"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const match_result_area = (MatchResultArea);

;// CONCATENATED MODULE: ./public/assets/img/bg/area_bg02.jpg
/* harmony default export */ const area_bg02 = ({"src":"/_next/static/media/area_bg02.556a5d7f.jpg","height":1749,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAJMLP//EABUQAQEAAAAAAAAAAAAAAAAAAAAS/9oACAEBAAE/AKf/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/app/components/about-area/about-area-2.tsx

const about_area_2_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\about-area\about-area-2.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: about_area_2_esModule, $$typeof: about_area_2_$$typeof } = about_area_2_proxy;
const about_area_2_default_ = about_area_2_proxy.default;


/* harmony default export */ const about_area_2 = (about_area_2_default_);
;// CONCATENATED MODULE: ./src/app/components/streamers/streamers-area.tsx

const streamers_area_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\streamers\streamers-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: streamers_area_esModule, $$typeof: streamers_area_$$typeof } = streamers_area_proxy;
const streamers_area_default_ = streamers_area_proxy.default;


/* harmony default export */ const streamers_area = (streamers_area_default_);
;// CONCATENATED MODULE: ./public/assets/img/bg/match_bg.jpg
/* harmony default export */ const match_bg = ({"src":"/_next/static/media/match_bg.626c1651.jpg","height":1073,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAkgY//8QAFRABAQAAAAAAAAAAAAAAAAAAABH/2gAIAQEAAT8Ar//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/assets/img/icons/match.svg
/* harmony default export */ const match = ({"src":"/_next/static/media/match.8a7d168a.svg","height":150,"width":1112,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./public/assets/img/others/team_vs01.png
/* harmony default export */ const team_vs01 = ({"src":"/_next/static/media/team_vs01.e136d3e7.png","height":181,"width":171,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABC0lEQVR42mNguDSdiQEKovauaGM40tzI8J+Bkfv/fE6GN2UyjDDJrjPHpzqwymb9Yv3C8PTnq4svrr0QYJT8zw6WnHvxzMrbD1/+//f3/+8L5x7///719/9rF+//n7hl5SUW0R2nWqQ+KYV9//Pt15YLV9gE+ZkZ/v0T//2d4T/rD7G/a5leq1ycsvf109N6hbvZnv9++k/RRJTh1peHzFe/3mQ4zHjnEkuY8lqetV+Fzi5stjRVEWT79/LxD8aHt97+F+ThZpBgZ2eFOLKJgft83LMnPN9ZBB68ePX/3Yf3jJf+vnzdGjxNlQWsoDpBavOla4f+f/n19wbDH6cnL2U+fHhnsJWBcd9HABAIgpGjLHwHAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./public/assets/img/others/team_vs02.png
var team_vs02 = __webpack_require__(91065);
;// CONCATENATED MODULE: ./public/assets/img/others/team_vs03.png
/* harmony default export */ const team_vs03 = ({"src":"/_next/static/media/team_vs03.d690ad80.png","height":183,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA2UlEQVR42mM4bP+YmQEIDtnf1z3n9aoNxD4d/4GJAQY2xV4AKzji/2Lf6fBP/3fp3oz8H/ifFyT2xfM/IwMIrDM+l7vIYu+eM74/7uxzefWdgYGBHSTeL76WkWGu0i6tboUFjSCBPZYvr592//t/k8VdMP+Sx38WhnaZ+VapDAwc+03f716iffrOYfsvj08H/Py/Uue4KwMMrFG/YLBT993/pfLnZ5y0/3bqmOOf/0fNvj+8bvxKkGGL2mtmsGPV7q/ZqP7s/2qdG//myB/9sUX7+f+teleXAwBjzWGZPvZFUAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/others/team_vs04.png
/* harmony default export */ const team_vs04 = ({"src":"/_next/static/media/team_vs04.6db53d6c.png","height":182,"width":168,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA4klEQVR42mMQbzvKZHXwDRsDELhe+ZKgfeCVPwMQmB5/x8IAB4uuc6udev9S/fSHq+X//7MyMGxmYhDuOaEukH9Bjm/TOyXZE+9+ap79+A6uQX/pnVW+Zz/8t93ytNv28pc8tUNvksKO/DQ3XXM3lYEhdI+C4/EXb8LPvv7P4LnAxmrbOw230+//W2y5P4UBBCzWP5xje+Hjf4NV96fq7X3bo3jo1X8GhmoOBu0Ztw209r/7ybP96R/b1W+0ROfdkVFYe/u/+LRT8xi4mvdu45py7D9T855uuENCp5gxFK7yBwADMmStCrnAsgAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});
;// CONCATENATED MODULE: ./public/assets/img/others/team_vs05.png
/* harmony default export */ const team_vs05 = ({"src":"/_next/static/media/team_vs05.edfa3945.png","height":185,"width":226,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA0ElEQVR42mO4GxzI/DYyiI0BCL5HB0R8CPeJZACCd5GBbHdDApkZkMF1D9t7t7zsHzAgg1uBfgEf4qKc/zMwMJ5yMD16ydXqGAOQ/TYmwul2kH8gw9PQoKb3kaENPzPS976MCXE65WLt+joxed+bqLDmJyEBbQy9DAwKj3zcs/8kp/5/GRx07ktkxPk/qRn/7/r55ALlFBlA4Kmr47nP3u4Pn/t5dD72du38GR724FNszAUGEJisKqF3zkjn/0Uz/SVwd3m4Lrjj4/V/qhSLAQDif1NWdlmdawAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./public/assets/img/others/team_vs06.png
/* harmony default export */ const team_vs06 = ({"src":"/_next/static/media/team_vs06.cfdcf080.png","height":181,"width":208,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA1ElEQVR42mMAgxNRujLfV38ReTP/P8OHOf8Zfi37wbAjzJwBBni/LL0h/XXjf6aNWc4Mq9LtGD6s/M/wbuFDBjCYbe/Be3f6b9abPTsZYOBa72aG+zP+Miz19GVg2BDnxbDF0ZPheJixwP+dLLz/DzAznAg3AottjvdhYJhi7MHwZf5Phg8ztjIwMICB3Ns5myW/Lf7BMMfSmwEMXiy8w/Bx9X+GF02OHE9bbEQ/rf3P82bRXQY42JdlzHBz6neGmxP+8z2Y9Z/7/rxfDPuSLBkYGBgAGmtW+XfdyXUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/app/components/upcoming-match/upcoming-matches.tsx














// match item
function UpcomingMatchItem({ team_1, team_2, game_name_1, game_name_2, time, match_name, date, match_name_2, delay }) {
    const imgStyle = {
        height: "auto",
        width: "100%"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "upcoming-match__item tg-svg wow fadeInUp",
        "data-wow-delay": `${delay}s`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(svg_icon_anim, {
                icon: match,
                id: "svg-7"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "upcoming-match__position",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "upcoming-match__team team-left",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/team-details",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: team_1,
                                alt: "img",
                                style: imgStyle
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "upcoming-match__content",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "team--info info-left",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "game-name",
                                        children: game_name_1
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "name",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/team-details",
                                            children: match_name
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "upcoming-match__time",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "time",
                                    children: time
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "team--info info-right",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "game-name",
                                        children: game_name_2
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "name",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/team-details",
                                            children: match_name_2
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "upcoming-match__team team-right",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/team-details",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: team_2,
                                alt: "img",
                                style: imgStyle
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "upcoming-match__date",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "287",
                        height: "24",
                        viewBox: "0 0 287 24",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            id: "bottom-svg1",
                            d: "M1104,3760l-20,24H837l-20-24",
                            transform: "translate(-817 -3760)"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: date
                    })
                ]
            })
        ]
    });
}
const UpcomingMatches = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "upcoming-match__area section-pt-120 section-pb-85",
        style: {
            backgroundImage: `url(${match_bg.src})`
        },
        "data-background": "assets/img/bg/match_bg.jpg",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-6 col-lg-7 col-md-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "section__title text-center mb-60",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(text_animation/* default */.ZP, {
                                    title: "MATCHES list"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "title",
                                    children: "upcoming MATCHES"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "upcoming-match__lists",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(UpcomingMatchItem, {
                                    date: "OCTOBER 7, 2023, 8:30 PM",
                                    team_1: team_vs01,
                                    team_2: team_vs02/* default */.Z,
                                    time: "08:30",
                                    game_name_1: "dota2",
                                    match_name: "sky hunter",
                                    match_name_2: "The Tadium",
                                    game_name_2: "dota2",
                                    delay: ".2"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(UpcomingMatchItem, {
                                    date: "October 9, 2023, 5:30 pm",
                                    team_1: team_vs03,
                                    team_2: team_vs04,
                                    time: "05:30",
                                    game_name_1: "valorant",
                                    match_name: "killer 7",
                                    match_name_2: "Black mx",
                                    game_name_2: "valorant",
                                    delay: ".4"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(UpcomingMatchItem, {
                                    date: "October 10, 2023, 9:30 pm",
                                    team_1: team_vs05,
                                    team_2: team_vs06,
                                    time: "09:30",
                                    game_name_1: "PUBG PC",
                                    match_name: "killer 7",
                                    match_name_2: "Black mx",
                                    game_name_2: "PUBG PC",
                                    delay: ".6"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const upcoming_matches = (UpcomingMatches);

;// CONCATENATED MODULE: ./src/app/components/projects/project-area.tsx

const project_area_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\projects\project-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: project_area_esModule, $$typeof: project_area_$$typeof } = project_area_proxy;
const project_area_default_ = project_area_proxy.default;


/* harmony default export */ const project_area = (project_area_default_);
;// CONCATENATED MODULE: ./public/assets/img/bg/social_bg.png
/* harmony default export */ const social_bg = ({"src":"/_next/static/media/social_bg.273adb32.png","height":615,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAS0lEQVR4nCWKMQ6AMBRC+dpOdjNRo/e/nYObgynITwmEhEe0/XpqCYQNobpBSvw6uoBo26kyA5PBkH8kaMo8LOvBhBk7Fd5vCS89/0HKG4VFS0iiAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./src/app/components/social/social-area.tsx





// social item 
const social_data = [
    {
        id: 1,
        link: "https://twitter.com/metaarcadeclub",
        icon: "flaticon-twitter",
        title: "twitter"
    },
    {
        id: 2,
        link: "https://www.instagram.com/metaarcadeclub/",
        icon: "flaticon-instagram",
        title: "instagram"
    },
    {
        id: 3,
        link: "https://www.youtube.com/",
        icon: "flaticon-youtube",
        title: "youtube"
    },
    {
        id: 4,
        link: "https://discord.gg/gNU6xj6tPf",
        icon: "flaticon-discord",
        title: "discord"
    },
    {
        id: 5,
        link: "https://www.twitch.tv/",
        icon: "flaticon-twitch",
        title: "twitch"
    }
];
const SocialArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "social__area social-bg",
        style: {
            backgroundImage: `url(${social_bg.src})`
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-xl-6 col-lg-7 col-md-10",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "section__title text-center mb-60",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(text_animation/* default */.ZP, {
                                    title: "connect with us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "title",
                                    children: "stay connected"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center gutter-20 row-cols-2 row-cols-lg-6 row-cols-md-4 row-cols-sm-3",
                    children: social_data.map((s, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "social__item",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: s.link,
                                    target: "_blank",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: s.icon
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: s.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "65",
                                            height: "5",
                                            viewBox: "0 0 65 5",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "M968,5630h65l-4,5H972Z",
                                                transform: "translate(-968 -5630)"
                                            })
                                        })
                                    ]
                                })
                            })
                        }, i))
                })
            ]
        })
    });
};
/* harmony default export */ const social_area = (SocialArea);

;// CONCATENATED MODULE: ./src/app/components/brand/brand-area.tsx

const brand_area_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\brand\brand-area.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: brand_area_esModule, $$typeof: brand_area_$$typeof } = brand_area_proxy;
const brand_area_default_ = brand_area_proxy.default;


/* harmony default export */ const brand_area = (brand_area_default_);
// EXTERNAL MODULE: ./src/layout/footer/footer-2.tsx
var footer_2 = __webpack_require__(5894);
;// CONCATENATED MODULE: ./src/app/home-2/page.tsx













const metadata = {
    title: "Home Page Two"
};
function HomeTwo() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(wrapper/* default */.ZP, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.ZP, {
                style_2: true
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main--area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(hero_banner_2, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(match_result_area, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "area-background",
                        style: {
                            backgroundImage: `url(${area_bg02.src})`
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(about_area_2, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(streamers_area, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(upcoming_matches, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(project_area, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(social_area, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(brand_area, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_2/* default */.ZP, {})
        ]
    });
}


/***/ }),

/***/ 82389:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/area_bg02.556a5d7f.jpg","height":1749,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAJMLP//EABUQAQEAAAAAAAAAAAAAAAAAAAAS/9oACAEBAAE/AKf/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 2881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/match_bg.626c1651.jpg","height":1073,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAkgY//8QAFRABAQAAAAAAAAAAAAAAAAAAABH/2gAIAQEAAT8Ar//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 13691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/result_bg.a453ab2e.png","height":769,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAZElEQVR4nA3JSQqEMBRF0fdsUiRFDQps4kjd/0KcuAkXIDhQbPO/4U4uHJa+HRHo0sJ8P83PJv/cCoM7hnmTRyZWdacgkamBOR2wCE6sEC/QGCvfB8RJk5wms1AqL9kh162I8AJGGSO5oSnd+gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 30716:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/social_bg.273adb32.png","height":615,"width":1920,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAS0lEQVR4nCWKMQ6AMBRC+dpOdjNRo/e/nYObgynITwmEhEe0/XpqCYQNobpBSvw6uoBo26kyA5PBkH8kaMo8LOvBhBk7Fd5vCS89/0HKG4VFS0iiAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 83479:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/match.8a7d168a.svg","height":150,"width":1112,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 25238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/shape.5be839ef.svg","height":61,"width":188,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 21763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/win_shape.95770d4e.svg","height":75,"width":135,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 25891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_vs01.e136d3e7.png","height":181,"width":171,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABC0lEQVR42mNguDSdiQEKovauaGM40tzI8J+Bkfv/fE6GN2UyjDDJrjPHpzqwymb9Yv3C8PTnq4svrr0QYJT8zw6WnHvxzMrbD1/+//f3/+8L5x7///719/9rF+//n7hl5SUW0R2nWqQ+KYV9//Pt15YLV9gE+ZkZ/v0T//2d4T/rD7G/a5leq1ycsvf109N6hbvZnv9++k/RRJTh1peHzFe/3mQ4zHjnEkuY8lqetV+Fzi5stjRVEWT79/LxD8aHt97+F+ThZpBgZ2eFOLKJgft83LMnPN9ZBB68ePX/3Yf3jJf+vnzdGjxNlQWsoDpBavOla4f+f/n19wbDH6cnL2U+fHhnsJWBcd9HABAIgpGjLHwHAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 9055:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_vs03.d690ad80.png","height":183,"width":200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA2UlEQVR42mM4bP+YmQEIDtnf1z3n9aoNxD4d/4GJAQY2xV4AKzji/2Lf6fBP/3fp3oz8H/ifFyT2xfM/IwMIrDM+l7vIYu+eM74/7uxzefWdgYGBHSTeL76WkWGu0i6tboUFjSCBPZYvr592//t/k8VdMP+Sx38WhnaZ+VapDAwc+03f716iffrOYfsvj08H/Py/Uue4KwMMrFG/YLBT993/pfLnZ5y0/3bqmOOf/0fNvj+8bvxKkGGL2mtmsGPV7q/ZqP7s/2qdG//myB/9sUX7+f+teleXAwBjzWGZPvZFUAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 17057:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_vs04.6db53d6c.png","height":182,"width":168,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA4klEQVR42mMQbzvKZHXwDRsDELhe+ZKgfeCVPwMQmB5/x8IAB4uuc6udev9S/fSHq+X//7MyMGxmYhDuOaEukH9Bjm/TOyXZE+9+ap79+A6uQX/pnVW+Zz/8t93ytNv28pc8tUNvksKO/DQ3XXM3lYEhdI+C4/EXb8LPvv7P4LnAxmrbOw230+//W2y5P4UBBCzWP5xje+Hjf4NV96fq7X3bo3jo1X8GhmoOBu0Ztw209r/7ybP96R/b1W+0ROfdkVFYe/u/+LRT8xi4mvdu45py7D9T855uuENCp5gxFK7yBwADMmStCrnAsgAAAABJRU5ErkJggg==","blurWidth":7,"blurHeight":8});

/***/ }),

/***/ 64125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_vs05.edfa3945.png","height":185,"width":226,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA0ElEQVR42mO4GxzI/DYyiI0BCL5HB0R8CPeJZACCd5GBbHdDApkZkMF1D9t7t7zsHzAgg1uBfgEf4qKc/zMwMJ5yMD16ydXqGAOQ/TYmwul2kH8gw9PQoKb3kaENPzPS976MCXE65WLt+joxed+bqLDmJyEBbQy9DAwKj3zcs/8kp/5/GRx07ktkxPk/qRn/7/r55ALlFBlA4Kmr47nP3u4Pn/t5dD72du38GR724FNszAUGEJisKqF3zkjn/0Uz/SVwd3m4Lrjj4/V/qhSLAQDif1NWdlmdawAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 26295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_vs06.cfdcf080.png","height":181,"width":208,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA1ElEQVR42mMAgxNRujLfV38ReTP/P8OHOf8Zfi37wbAjzJwBBni/LL0h/XXjf6aNWc4Mq9LtGD6s/M/wbuFDBjCYbe/Be3f6b9abPTsZYOBa72aG+zP+Miz19GVg2BDnxbDF0ZPheJixwP+dLLz/DzAznAg3AottjvdhYJhi7MHwZf5Phg8ztjIwMICB3Ns5myW/Lf7BMMfSmwEMXiy8w/Bx9X+GF02OHE9bbEQ/rf3P82bRXQY42JdlzHBz6neGmxP+8z2Y9Z/7/rxfDPuSLBkYGBgAGmtW+XfdyXUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 53146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/win01.d048f858.png","height":249,"width":207,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA80lEQVR4nAHoABf/AQAA/wKPp5j+w+iZfuvaQYEPH76DOxRefsJkVQMBANkABb8LqkW1q8Ga4KHzGyhiIu05UgVOC8d6xgGZtKTU8+b+K+3q8QAgExr9+QMJAwcM+wD2C92iAXOUkO3NrNcSDRgX/ggSFAIG/v78EhcZBAoe4KQBXItQwgfWIj3t3M/+/AETArTC7/5xajAC8SfengF9qXyW+eAyaQMAAfze39wCLywwAQH17QHN9JzcAXyreGD24x2c/fUHA/z2BAADDPr/AQr9/QsjsU8BlP8AAqu6ABI362JaAPUtdOsHcWMHGADTMyxY6yTbaLkx89mQAAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});

/***/ }),

/***/ 31423:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/win02.333558cb.png","height":249,"width":225,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA80lEQVR4nAHoABf/AZG36gXe+f/7ou36Nxvz/WrUcB1xAHIC8ADz/hYBecT0AIfkAS+5IvbAEAT6EOTw/9jj2dkB/wANDAFg4v8sVermykcvFQnh4vD8EhEIBO7u7wC2vOHXAXy6+eJUFPAd6+/u/PXz9QQ7PCX76en0BbjE8ooBWcT+Ww3C06D+3tAEh4dR/wICAP/c3OUC7PD9YAH7/f86u8bzoBQJ9SUNDAT95OPn//379QQeHhBkAdfa8gADAAFvBAb7kOfl7ADw8PMA9Pb9+UFCMyQBw8bsAB0cCWfk5fFJ2O3+JeDoAhLy8Qm3kr4QadiugGWE8Rp/AAAAAElFTkSuQmCC","blurWidth":7,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1697,7546,3773,9232,6438,1257,8474,6107,4250,5343,6410,4876,1047], () => (__webpack_exec__(76467)));
module.exports = __webpack_exports__;

})();