(() => {
var exports = {};
exports.id = 9658;
exports.ids = [9658];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 17396:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        'team-details',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38402)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\team-details\\page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16660)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\team-details\\page.tsx"];
    
    const originalPathname = "/team-details/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 58811:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86646));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51286));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95457, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 99556, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12968));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78403));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 40565));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84588));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48855));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9747));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24876));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19604));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67089));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 45843));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 21345));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48796));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62294));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5447));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67651));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7553));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89091));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9672));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 19564));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7077))

/***/ }),

/***/ 38402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ TeamDetailsPage),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/layout/wrapper.tsx
var wrapper = __webpack_require__(9286);
// EXTERNAL MODULE: ./src/layout/header/header.tsx
var header = __webpack_require__(20685);
// EXTERNAL MODULE: ./src/layout/footer/footer.tsx + 6 modules
var footer = __webpack_require__(77954);
// EXTERNAL MODULE: ./src/app/components/breadcrumb/breadcrumb-area.tsx + 1 modules
var breadcrumb_area = __webpack_require__(5080);
// EXTERNAL MODULE: ./public/assets/img/bg/breadcrumb_bg01.jpg
var breadcrumb_bg01 = __webpack_require__(47361);
;// CONCATENATED MODULE: ./public/assets/img/team/breadcrumb_team.png
/* harmony default export */ const breadcrumb_team = ({"src":"/_next/static/media/breadcrumb_team.e00904af.png","height":300,"width":335,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA50lEQVR42mMAAff/HXyatd7r1MJsf2uGWP/SqvVe5f1/Ag9Y0u//FBWNYo/NKlY2/w2aMv4pNaT/U7Kz+69Z4rEu4P8MeQaHZ5UXVB2t/0tbm/21nF3xP3vnlP+G/q5/FRws/zu+qD7LYH+39IKqtfV/Y2vbv5tbsv6fnl7139XJ6a+UrdV/xwfllxlcfzTZGFf4/pdnMP+/rCrh966u3N+yDGb/Dav9/rr9bbFmAAH7k3m5mtW+/+dWxP1f05L+X6PW97/d6bwMsKQmgzYziLZ6W2nvdzpvq+fp3E02H6psQGJ6cY7MABhpX+wfs7N3AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(80000);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(11518);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(57495);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/assets/img/icons/circle02.svg
/* harmony default export */ const circle02 = ({"src":"/_next/static/media/circle02.8fcaf716.svg","height":138,"width":138,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./public/assets/img/others/team_vs02.png
var team_vs02 = __webpack_require__(91065);
;// CONCATENATED MODULE: ./src/app/components/team/team-info-area.tsx






const TeamInfoArea = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "team__info-area",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "team__info-wrap",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "team__info-discord",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "about__content-circle",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: circle02,
                                                alt: "img",
                                                width: 104,
                                                height: 104
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                viewBox: "0 0 150 150",
                                                version: "1.1",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        id: "textPath",
                                                        d: "M 0,75 a 75,75 0 1,1 0,1 z"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("text", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("textPath", {
                                                            href: "#textPath",
                                                            children: "super nft Gaming sits"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "flaticon-discord"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "team__info-discord-info",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "sub",
                                                children: "Join Us"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                className: "title",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "https://discord.com/",
                                                    target: "_blank",
                                                    children: "DISCORD"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "team__info-list",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list-wrap",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "team__info-item",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "team__info-icon",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: team_vs02/* default */.Z,
                                                            alt: "img",
                                                            width: 67,
                                                            height: 75,
                                                            style: {
                                                                height: "auto",
                                                                width: "auto"
                                                            }
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "team__info-content",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "sub",
                                                                children: "Member"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                className: "title",
                                                                children: "Black ninja"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "team__info-item",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "team__info-icon",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "flaticon-swords-1"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "team__info-content",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "sub",
                                                                children: "Game play"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                className: "title",
                                                                children: "Pubg Mobile"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "team__info-item",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "team__info-icon",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "flaticon-diamond"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "team__info-content",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "sub",
                                                                children: "Win Time"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                                className: "title",
                                                                children: "04"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const team_info_area = (TeamInfoArea);

// EXTERNAL MODULE: ./src/app/components/svg/dots.tsx
var dots = __webpack_require__(97701);
// EXTERNAL MODULE: ./public/assets/img/bg/team_details_bg.jpg
var team_details_bg = __webpack_require__(53889);
;// CONCATENATED MODULE: ./public/assets/img/team/team_details.jpg
/* harmony default export */ const team_details = ({"src":"/_next/static/media/team_details.399ebf32.jpg","height":662,"width":1270,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAJMF/wD/xAAbEAACAgMBAAAAAAAAAAAAAAABAgMRAAQSMv/aAAgBAQABPwDWmNLK6I8iv6cXfR5IOf/EABkRAQEAAwEAAAAAAAAAAAAAAAECAAQRQf/aAAgBAgEBPwDbqosJUOeZ/8QAGhEBAQACAwAAAAAAAAAAAAAAAQIABBEhQf/aAAgBAwEBPwDWC4Wwp597z//Z","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/assets/img/team/team_details01.jpg
/* harmony default export */ const team_details01 = ({"src":"/_next/static/media/team_details01.b3897d44.jpg","height":440,"width":620,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQT/2gAMAwEAAhADEAAAAI0FP//EAB0QAAMAAAcAAAAAAAAAAAAAAAECAwAEBRETIoH/2gAIAQEAAT8Anq+dvcyag4mBQpt18x//xAAXEQEBAQEAAAAAAAAAAAAAAAACAQAR/9oACAECAQE/AGCrOzf/xAAYEQACAwAAAAAAAAAAAAAAAAABAgADEf/aAAgBAwEBPwBLHUYDP//Z","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/assets/img/team/team_details02.jpg
/* harmony default export */ const team_details02 = ({"src":"/_next/static/media/team_details02.3915dd36.jpg","height":440,"width":620,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAgBh//8QAHxAAAgECBwAAAAAAAAAAAAAAAQIDBAUAERMhI0FR/9oACAEBAAE/ALfbopaeqWU8miGjdNsi3Z9x/8QAGBEBAAMBAAAAAAAAAAAAAAAAAgEDIQD/2gAIAQIBAT8AJKrrUxu9/8QAGREAAgMBAAAAAAAAAAAAAAAAAQIAAxES/9oACAEDAQE/AL0XVPI0z//Z","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/app/components/team/team-details-area.tsx








const TeamDetailsArea = ()=>{
    const imgStyle = {
        width: "100%",
        height: "auto"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "team__details-area section-pt-120 section-pb-120",
        style: {
            backgroundImage: `url(${team_details_bg/* default */.Z.src})`
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "col-12",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "team__details-img",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: team_details,
                                    alt: "img",
                                    style: imgStyle
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(dots/* default */.Z, {})
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "team__details-content",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "sub-title",
                                    children: "our team member"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "title",
                                    children: "Online Games for Everyone Find the Best MMOs FOR YOU."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum sollicitudin is yaugue euismods Nulla ullamcorper. Morbi pharetra tellus miolslis, tincidunt massa venenatis. Lorem Ipsum is simply dummyd the printing and typesetting industry. Lorem Ipsum has been the industries standard dummy text ever since the 1500s, when an unknown printer took a galley. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which do not look even slightly believable."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum sollicitudin is yaugue euismods Nulla ullamcorper. Morbi pharetra tellus miolslis, tincidunt massa venenatis. Lorem Ipsum is simply dummyd the printing and typesetting industry. Lorem Ipsum has been the industries standard dummy text ever since the 1500s, when an unknown printer took a galley. There are many variations of passages."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("blockquote", {
                                    className: "team__details-quote",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum sollicitudin is yaugue euimods Nulla ullamcorper. Morbi pharetra tellus miolslis, tincidunt massa venenatis. Lorem Ipsum is simply dummyd the printing and typesetting industry."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("cite", {
                                            children: "SHAKH DANIAL"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum sollicitudin is yaugue euismods Nulla ullamcorper. Morbi pharetra tellus miolslis, tincidunt massa venenatis. Lorem Ipsum is simply dummyd the printing and typesetting industry. Lorem Ipsum has been the industries standard dummy text ever since the 1500s, when an unknown printer took a galley. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which do not look even slightly believable."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "team__details-inner-wrap",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-sm-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "team__details-inner-img",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: team_details01,
                                                        alt: "img",
                                                        style: imgStyle
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-sm-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "team__details-inner-img",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: team_details02,
                                                        alt: "img",
                                                        style: imgStyle
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Lorem ipsum dolor sit amet, consteur adipiscing Duis elementum sollicitudin is yaugue euismods Nulla ullamcorper. Morbi pharetra tellus miolslis, tincidunt massa venenatis. Lorem Ipsum is simply dummyd the printing and typesetting industry. Lorem Ipsum has been the industries standard dummy text ever since the 1500s, when an unknown printer took a galley. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which do not look even slightly believable."
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const team_details_area = (TeamDetailsArea);

// EXTERNAL MODULE: ./src/app/components/video/video-area.tsx
var video_area = __webpack_require__(84244);
// EXTERNAL MODULE: ./src/app/components/team/team-area.tsx + 6 modules
var team_area = __webpack_require__(62487);
;// CONCATENATED MODULE: ./src/app/team-details/page.tsx











const metadata = {
    title: "Team Details Page"
};
function TeamDetailsPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(wrapper/* default */.ZP, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main--area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb_area/* default */.Z, {
                        title: "SHAKH DANIAL",
                        subtitle: "TEAM DETAILS",
                        bg: breadcrumb_bg01/* default */.Z,
                        brd_img: breadcrumb_team
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(team_info_area, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(team_details_area, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(video_area/* default */.ZP, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(team_area/* default */.Z, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
}


/***/ }),

/***/ 19564:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/circle02.8fcaf716.svg","height":138,"width":138,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 7077:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/breadcrumb_team.e00904af.png","height":300,"width":335,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA50lEQVR42mMAAff/HXyatd7r1MJsf2uGWP/SqvVe5f1/Ag9Y0u//FBWNYo/NKlY2/w2aMv4pNaT/U7Kz+69Z4rEu4P8MeQaHZ5UXVB2t/0tbm/21nF3xP3vnlP+G/q5/FRws/zu+qD7LYH+39IKqtfV/Y2vbv5tbsv6fnl7139XJ6a+UrdV/xwfllxlcfzTZGFf4/pdnMP+/rCrh966u3N+yDGb/Dav9/rr9bbFmAAH7k3m5mtW+/+dWxP1f05L+X6PW97/d6bwMsKQmgzYziLZ6W2nvdzpvq+fp3E02H6psQGJ6cY7MABhpX+wfs7N3AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 7553:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_details.399ebf32.jpg","height":662,"width":1270,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAQACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAJMF/wD/xAAbEAACAgMBAAAAAAAAAAAAAAABAgMRAAQSMv/aAAgBAQABPwDWmNLK6I8iv6cXfR5IOf/EABkRAQEAAwEAAAAAAAAAAAAAAAECAAQRQf/aAAgBAgEBPwDbqosJUOeZ/8QAGhEBAQACAwAAAAAAAAAAAAAAAQIABBEhQf/aAAgBAwEBPwDWC4Wwp597z//Z","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 67651:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_details01.b3897d44.jpg","height":440,"width":620,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQT/2gAMAwEAAhADEAAAAI0FP//EAB0QAAMAAAcAAAAAAAAAAAAAAAECAwAEBRETIoH/2gAIAQEAAT8Anq+dvcyag4mBQpt18x//xAAXEQEBAQEAAAAAAAAAAAAAAAACAQAR/9oACAECAQE/AGCrOzf/xAAYEQACAwAAAAAAAAAAAAAAAAABAgADEf/aAAgBAwEBPwBLHUYDP//Z","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 89091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_details02.3915dd36.jpg","height":440,"width":620,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAgBh//8QAHxAAAgECBwAAAAAAAAAAAAAAAQIDBAUAERMhI0FR/9oACAEBAAE/ALfbopaeqWU8miGjdNsi3Z9x/8QAGBEBAAMBAAAAAAAAAAAAAAAAAgEDIQD/2gAIAQIBAT8AJKrrUxu9/8QAGREAAgMBAAAAAAAAAAAAAAAAAQIAAxES/9oACAEDAQE/AL0XVPI0z//Z","blurWidth":8,"blurHeight":6});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1697,7546,3773,9232,6438,1257,4250,7531,8255,5343,1220,885,4876,2966,7517,1047], () => (__webpack_exec__(17396)));
module.exports = __webpack_exports__;

})();