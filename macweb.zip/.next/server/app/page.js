(() => {
var exports = {};
exports.id = 1931;
exports.ids = [1931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 18631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1865);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26327);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50600)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16660)), "C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\stefa\\Desktop\\newMACwebsite\\mykd\\src\\app\\page.tsx"];
    
    const originalPathname = "/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 91868:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86646));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22365));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83463));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 69953));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68079));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 88986));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71686));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24797));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2305));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97207))

/***/ }),

/***/ 71686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ arcadearenabanner)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-parallax-mouse/dist/index.js
var dist = __webpack_require__(24323);
// EXTERNAL MODULE: ./public/assets/img/bg/team_bg.jpg
var team_bg = __webpack_require__(78403);
;// CONCATENATED MODULE: ./public/assets/img/others/ArcadeArena.png
/* harmony default export */ const ArcadeArena = ({"src":"/_next/static/media/ArcadeArena.5b7ce9bb.png","height":1250,"width":1250,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0klEQVR42mMAgbrJO5gZ0MBMxzlMYEZNw2wIo2qT5MVpjwU+974VYJh2QgRFdeWEA15d845cry5Yfqo+ZfGx3km7H7SlbIxngIHsjJ5zpYWL/89s3PB/asbi/7lFG/4XRvXfmM/AwMQwfcVCzabC2iepRuH/J+UU/y+PLfxnlTvtf3hOzY+aqgojBhD4//8/947eBR2h/lHfjJPzfpcu3z5v2d2XimDJHY0TmGBWnb7+UHLDncdyML5bShYjmHFn3w3GMtc0FpiEonMxy6QjF8AaAV7JWDZWbXV9AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape01.png
var slider_shape01 = __webpack_require__(47473);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape02.png
var slider_shape02 = __webpack_require__(76257);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape03.png
var slider_shape03 = __webpack_require__(31083);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape04.png
var slider_shape04 = __webpack_require__(16694);
;// CONCATENATED MODULE: ./src/app/components/arcadearena/arcadearenabanner.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










//import logo_1 from '@/assets/img/brand/brand_logo01.png';
//import logo_2 from '@/assets/img/brand/brand_logo02.png';
//import logo_3 from '@/assets/img/brand/brand_logo03.png';
// brands
//const brands:StaticImageData[] = [logo_1,logo_2,logo_3]
const HeroBanner = ()=>{
    const [hoveredIndex, setHoveredIndex] = (0,react_.useState)(null);
    return /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxContainer */.W7, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "slider__area slider__bg",
            style: {
                backgroundImage: `url(${team_bg["default"].src})`
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "slider-activee",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-slider",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container custom-container",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row justify-content-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-lg-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "slider__content",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "sub-title wow fadeInUp",
                                                    "data-wow-delay": ".2s",
                                                    children: "JOIN THE GRID!"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "title wow fadeInUp",
                                                    "data-wow-delay": ".5s",
                                                    children: "PLAY PIT"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "wow fadeInUp",
                                                    "data-wow-delay": ".8s",
                                                    children: "Arcade Arena"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "slider__btn wow fadeInUp",
                                                    "data-wow-delay": "1.2s",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        className: "tg-btn-1",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "coming soon"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-xxl-6 col-xl-5 col-lg-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxChild */.JV, {
                                            factorX: 0.03,
                                            factorY: 0.03,
                                            className: "slider__img text-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: ArcadeArena,
                                                alt: "img",
                                                style: {
                                                    height: "auto"
                                                },
                                                priority: true
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "slider__shapes",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape01/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape02/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape03/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape04/* default */.Z,
                            alt: "shape"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const arcadearenabanner = (HeroBanner);


/***/ }),

/***/ 83463:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ breadcrumb_area_2)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-parallax-mouse/dist/index.js
var dist = __webpack_require__(24323);
// EXTERNAL MODULE: ./public/assets/img/bg/team_bg.jpg
var team_bg = __webpack_require__(78403);
;// CONCATENATED MODULE: ./public/assets/img/others/roadmap.png
/* harmony default export */ const roadmap = ({"src":"/_next/static/media/roadmap.f0c5f0a2.png","height":2344,"width":2344,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA70lEQVR42mOAgd/Pypn//GcQ+fOPQeTvszxmBhj4/kyUEUT//88g9u5qeuP769ENIDYDAwPDl0dKjAxfHsrDFIgfmtl88ejUnEv//zNIg8XeSTAyrDg3CaQAhBnCoiv3VVuF7/7//z8rA0MzKwMM2Jcs4mR4+V/MPqjlfJah5+FTGv+FChhm8ekx5DMygMGt//zua967+VsWfuowyHu82/upegPDC64WvdnMDOYNS9kY+s7ZmXTt2Gavn/S/Uq7+/zrNHXOSGKaYVfIvYGGQq6xmlrMs9ZMrXNDK6jKtNYOhZ/F0pckrPURTIxkYGBgA6MNb1W5x8jYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape01.png
var slider_shape01 = __webpack_require__(47473);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape02.png
var slider_shape02 = __webpack_require__(76257);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape03.png
var slider_shape03 = __webpack_require__(31083);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape04.png
var slider_shape04 = __webpack_require__(16694);
;// CONCATENATED MODULE: ./src/app/components/breadcrumb/breadcrumb-area-2.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










// brands
//const brands:StaticImageData[] = [logo_1,logo_2,logo_3]
const BreadcrumbArea = ()=>{
    const [hoveredIndex, setHoveredIndex] = (0,react_.useState)(null);
    return /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxContainer */.W7, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "slider__area slider__bg",
            style: {
                backgroundImage: `url(${team_bg["default"].src})`
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "slider-activee",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-slider",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container custom-container",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row justify-content-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-lg-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "slider__content",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "sub-title wow fadeInUp",
                                                    "data-wow-delay": ".2s",
                                                    children: "QUEST BEGINS!"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "title wow fadeInUp",
                                                    "data-wow-delay": ".5s",
                                                    children: "Pixel Path"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "wow fadeInUp",
                                                    "data-wow-delay": ".8s",
                                                    children: "roadmap"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "slider__btn wow fadeInUp",
                                                    "data-wow-delay": "1.2s",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/services",
                                                        className: "tg-btn-1",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "Check now"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-xxl-6 col-xl-5 col-lg-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxChild */.JV, {
                                            factorX: 0.03,
                                            factorY: 0.03,
                                            className: "slider__img text-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: roadmap,
                                                alt: "img",
                                                style: {
                                                    height: "auto"
                                                },
                                                priority: true
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "slider__shapes",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape01/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape02/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape03/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape04/* default */.Z,
                            alt: "shape"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const breadcrumb_area_2 = (BreadcrumbArea);


/***/ }),

/***/ 22365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ hero_banner)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-parallax-mouse/dist/index.js
var dist = __webpack_require__(24323);
;// CONCATENATED MODULE: ./public/assets/img/slider/slider_bg.jpg
/* harmony default export */ const slider_bg = ({"src":"/_next/static/media/slider_bg.eac2c3ae.jpg","height":2000,"width":3000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwb/2gAMAwEAAhADEAAAAIIVzf/EABsQAAEEAwAAAAAAAAAAAAAAAAEAAgMxBAUT/9oACAEBAAE/AHSSa7IPB9Giv//EABkRAAEFAAAAAAAAAAAAAAAAAAIAAREhUf/aAAgBAgEBPwA6J41f/8QAGxEAAQQDAAAAAAAAAAAAAAAAAgABAwQRElH/2gAIAQMBAT8AvV4CsFtED46y/9k=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/slider/slider_img01.png
/* harmony default export */ const slider_img01 = ({"src":"/_next/static/media/slider_img01.46ff3813.png","height":8335,"width":8334,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAw0lEQVR42mNABseW3+Y6tew2B4qg0///jCD6kfYh9ccKB7XvOx3We8awRxVF0Yz3X2QmffhSWvv/j1/l//9yi55+DFh147U8XEHt/98ydf9/Rzb+/z1x6ecvVZtfv7sU/f+/OFxBxf8/2iX//1o2/f+dtfj9R6fFHz5OKv3/Vw+uYOWlF8oLH7wNKf3/z6rg/3+bnvdf4/o+fpVFcccD9yPaDxyO6F6vOGN2K+eUNkhs0rePjKjeXHGb61LXFTYwB+o7AJl3YnMsc7RYAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape01.png
var slider_shape01 = __webpack_require__(47473);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape02.png
var slider_shape02 = __webpack_require__(76257);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape03.png
var slider_shape03 = __webpack_require__(31083);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape04.png
var slider_shape04 = __webpack_require__(16694);
;// CONCATENATED MODULE: ./src/app/components/hero-banner/hero-banner.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









//import logo_1 from '@/assets/img/brand/brand_logo01.png';
//import logo_2 from '@/assets/img/brand/brand_logo02.png';
//import logo_3 from '@/assets/img/brand/brand_logo03.png';
// brands
//const brands:StaticImageData[] = [logo_1,logo_2,logo_3]
const HeroBanner = ()=>{
    const [hoveredIndex, setHoveredIndex] = (0,react_.useState)(null);
    return /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxContainer */.W7, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "slider__area slider__bg",
            style: {
                backgroundImage: `url(${slider_bg.src})`
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "slider-activee",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-slider",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container custom-container",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row justify-content-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-lg-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "slider__content",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "sub-title wow fadeInUp",
                                                    "data-wow-delay": ".2s",
                                                    children: "Game on!"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "title wow fadeInUp",
                                                    "data-wow-delay": ".5s",
                                                    children: "Welcome"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "wow fadeInUp",
                                                    "data-wow-delay": ".8s",
                                                    children: "to the playground"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "slider__btn wow fadeInUp",
                                                    "data-wow-delay": "1.2s"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-xxl-6 col-xl-5 col-lg-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxChild */.JV, {
                                            factorX: 0.03,
                                            factorY: 0.03,
                                            className: "slider__img text-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: slider_img01,
                                                alt: "img",
                                                style: {
                                                    height: "auto"
                                                },
                                                priority: true
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "slider__shapes",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape01/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape02/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape03/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape04/* default */.Z,
                            alt: "shape"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const hero_banner = (HeroBanner);


/***/ }),

/***/ 88986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_parallax_mouse__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24323);
/* harmony import */ var _assets_img_bg_team_bg_jpg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(78403);
/* harmony import */ var _assets_img_others_teambanner_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(12968);
/* harmony import */ var _assets_img_slider_slider_shape01_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(47473);
/* harmony import */ var _assets_img_slider_slider_shape02_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(76257);
/* harmony import */ var _assets_img_slider_slider_shape03_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(31083);
/* harmony import */ var _assets_img_slider_slider_shape04_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(16694);
/* __next_internal_client_entry_do_not_use__ default auto */ 










//import logo_1 from '@/assets/img/brand/brand_logo01.png';
//import logo_2 from '@/assets/img/brand/brand_logo02.png';
//import logo_3 from '@/assets/img/brand/brand_logo03.png';
// brands
//const brands:StaticImageData[] = [logo_1,logo_2,logo_3]
const HeroBanner = ()=>{
    const [hoveredIndex, setHoveredIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_parallax_mouse__WEBPACK_IMPORTED_MODULE_4__/* .MouseParallaxContainer */ .W7, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "slider__area slider__bg",
            style: {
                backgroundImage: `url(${_assets_img_bg_team_bg_jpg__WEBPACK_IMPORTED_MODULE_5__["default"].src})`
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "slider-activee",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "single-slider",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container custom-container",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row justify-content-between",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-lg-6",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "slider__content",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                    className: "sub-title wow fadeInUp",
                                                    "data-wow-delay": ".2s",
                                                    children: "WE ARE ONE!"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    className: "title wow fadeInUp",
                                                    "data-wow-delay": ".5s",
                                                    children: "BIT BRAINS"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "wow fadeInUp",
                                                    "data-wow-delay": ".8s",
                                                    children: "team"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "slider__btn wow fadeInUp",
                                                    "data-wow-delay": "1.2s",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        href: "/about",
                                                        className: "tg-btn-1",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: "Meet us"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-xxl-6 col-xl-5 col-lg-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_parallax_mouse__WEBPACK_IMPORTED_MODULE_4__/* .MouseParallaxChild */ .JV, {
                                            factorX: 0.03,
                                            factorY: 0.03,
                                            className: "slider__img text-center",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                src: _assets_img_others_teambanner_png__WEBPACK_IMPORTED_MODULE_6__["default"],
                                                alt: "img",
                                                style: {
                                                    height: "auto"
                                                },
                                                priority: true
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "slider__shapes",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: _assets_img_slider_slider_shape01_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: _assets_img_slider_slider_shape02_png__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: _assets_img_slider_slider_shape03_png__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: _assets_img_slider_slider_shape04_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                            alt: "shape"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroBanner);


/***/ }),

/***/ 68079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ tournamentbanner)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-parallax-mouse/dist/index.js
var dist = __webpack_require__(24323);
// EXTERNAL MODULE: ./public/assets/img/bg/team_bg.jpg
var team_bg = __webpack_require__(78403);
;// CONCATENATED MODULE: ./public/assets/img/others/breadcrumb_img01.png
/* harmony default export */ const breadcrumb_img01 = ({"src":"/_next/static/media/breadcrumb_img01.f42e9f4c.png","height":1250,"width":1250,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAtElEQVR42mMgGnTMP1Yf0bJpR1jr5h0tS0+3A4UY4ZI9DLsEJtZsOeeWPfG/Ze6E/83tOy5PZdghCFeQx7zRuI9l/bQU997voZ59P9oE1k4vZdhkDFeQw7DctIFpZ0tqyorXaamr3zTz727JYlhmClewyumkaF/Zlk3qdhn/NW1S//eXbdy6xvOsKFzBhmXnJOrrV8/VC+lYruXXtLyxftn8zasuSoEl3x15x8iAA3w88pERAFQpSQVjA490AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape01.png
var slider_shape01 = __webpack_require__(47473);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape02.png
var slider_shape02 = __webpack_require__(76257);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape03.png
var slider_shape03 = __webpack_require__(31083);
// EXTERNAL MODULE: ./public/assets/img/slider/slider_shape04.png
var slider_shape04 = __webpack_require__(16694);
;// CONCATENATED MODULE: ./src/app/components/tournament/tournamentbanner.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










//import logo_1 from '@/assets/img/brand/brand_logo01.png';
//import logo_2 from '@/assets/img/brand/brand_logo02.png';
//import logo_3 from '@/assets/img/brand/brand_logo03.png';
// brands
//const brands:StaticImageData[] = [logo_1,logo_2,logo_3]
const TournamentBanner = ()=>{
    const [hoveredIndex, setHoveredIndex] = (0,react_.useState)(null);
    return /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxContainer */.W7, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "slider__area slider__bg",
            style: {
                backgroundImage: `url(${team_bg["default"].src})`
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "slider-activee",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "single-slider",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "container custom-container",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row justify-content-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-lg-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "slider__content",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                    className: "sub-title wow fadeInUp",
                                                    "data-wow-delay": ".2s",
                                                    children: "VICTORY CALLS!"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    className: "title wow fadeInUp",
                                                    "data-wow-delay": ".5s",
                                                    children: "PIXEL PLAYOFFS"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "wow fadeInUp",
                                                    "data-wow-delay": ".8s",
                                                    children: "TOURNAMENT & LEADERBOARD"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "slider__btn wow fadeInUp",
                                                    "data-wow-delay": "1.2s",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: "tg-btn-1",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "coming soon"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-xxl-6 col-xl-5 col-lg-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* MouseParallaxChild */.JV, {
                                            factorX: 0.03,
                                            factorY: 0.03,
                                            className: "slider__img text-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: breadcrumb_img01,
                                                alt: "img",
                                                style: {
                                                    height: "auto"
                                                },
                                                priority: true
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "slider__shapes",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape01/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape02/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape03/* default */.Z,
                            alt: "shape"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: slider_shape04/* default */.Z,
                            alt: "shape"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const tournamentbanner = (TournamentBanner);


/***/ }),

/***/ 50600:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./src/layout/wrapper.tsx
var wrapper = __webpack_require__(9286);
// EXTERNAL MODULE: ./src/layout/header/header.tsx
var header = __webpack_require__(20685);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21913);
;// CONCATENATED MODULE: ./src/app/components/hero-banner/hero-banner.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\hero-banner\hero-banner.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const hero_banner = (__default__);
;// CONCATENATED MODULE: ./public/assets/img/bg/area_bg01.jpg
/* harmony default export */ const area_bg01 = ({"src":"/_next/static/media/area_bg01.de5dae01.jpg","height":1890,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAlQR//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./src/app/components/video/video-area.tsx
var video_area = __webpack_require__(84244);
;// CONCATENATED MODULE: ./src/app/components/breadcrumb/breadcrumb-area-2.tsx

const breadcrumb_area_2_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\breadcrumb\breadcrumb-area-2.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: breadcrumb_area_2_esModule, $$typeof: breadcrumb_area_2_$$typeof } = breadcrumb_area_2_proxy;
const breadcrumb_area_2_default_ = breadcrumb_area_2_proxy.default;


/* harmony default export */ const breadcrumb_area_2 = (breadcrumb_area_2_default_);
;// CONCATENATED MODULE: ./src/app/components/tournament/tournamentbanner.tsx

const tournamentbanner_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\tournament\tournamentbanner.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: tournamentbanner_esModule, $$typeof: tournamentbanner_$$typeof } = tournamentbanner_proxy;
const tournamentbanner_default_ = tournamentbanner_proxy.default;


/* harmony default export */ const tournamentbanner = (tournamentbanner_default_);
;// CONCATENATED MODULE: ./src/app/components/team1/teambanner.tsx

const teambanner_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\team1\teambanner.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: teambanner_esModule, $$typeof: teambanner_$$typeof } = teambanner_proxy;
const teambanner_default_ = teambanner_proxy.default;


/* harmony default export */ const teambanner = (teambanner_default_);
;// CONCATENATED MODULE: ./src/app/components/arcadearena/arcadearenabanner.tsx

const arcadearenabanner_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\stefa\Desktop\newMACwebsite\mykd\src\app\components\arcadearena\arcadearenabanner.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: arcadearenabanner_esModule, $$typeof: arcadearenabanner_$$typeof } = arcadearenabanner_proxy;
const arcadearenabanner_default_ = arcadearenabanner_proxy.default;


/* harmony default export */ const arcadearenabanner = (arcadearenabanner_default_);
// EXTERNAL MODULE: ./src/layout/footer/footer-2.tsx
var footer_2 = __webpack_require__(5894);
;// CONCATENATED MODULE: ./src/app/page.tsx




//import NftItemArea from "./components/nft-item/nft-item-area";
//import AboutArea from "./components/about-area/about-area";
//import GalleryArea from "./components/gallery/gallery-area";
//import TeamArea from "./components/team/team-area";






//import TrendingNftItems from "./components/nft-item/trending-nft-items";

function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(wrapper/* default */.ZP, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main--area",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(hero_banner, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(arcadearenabanner, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(tournamentbanner, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb_area_2, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(teambanner, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "area-background",
                        style: {
                            backgroundImage: `url(${area_bg01.src})`
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(video_area/* default */.ZP, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_2/* default */.ZP, {})
        ]
    });
}


/***/ }),

/***/ 69953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/area_bg01.de5dae01.jpg","height":1890,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAlQR//8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 78403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/team_bg.eac2c3ae.jpg","height":2000,"width":3000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwb/2gAMAwEAAhADEAAAAIIVzf/EABsQAAEEAwAAAAAAAAAAAAAAAAEAAgMxBAUT/9oACAEBAAE/AHSSa7IPB9Giv//EABkRAAEFAAAAAAAAAAAAAAAAAAIAAREhUf/aAAgBAgEBPwA6J41f/8QAGxEAAQQDAAAAAAAAAAAAAAAAAgABAwQRElH/2gAIAQMBAT8AvV4CsFtED46y/9k=","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 12968:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/teambanner.e8fbf98e.png","height":1563,"width":1563,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/UlEQVR42h3DMUsCcRgH4F/vfYYKhz6CkXWc6VFDYzkkIZhEUINIR3F6aSCWJS1Bbt5ag0HhUBTXUERTpKKDoyIIiuimCC6i8PfFBx7Avw8+542+gp/79FwMe0Aj8ISZcvBT6uj/4E5z1xQZT0a0tb/10pEFLuHG+KDbVB7cHnddiZg7KRLXeXsi/A5OOHuuU7wiwG3aoTkIHphDoyCWTrI1cMLWV4tQmYAvR8IPY+P0cYLiaG3TaoITAm9dQk2A29Le+0F6566Pqlg4zrXBCdvRF8mV+gZfDamRXkjR+xsXluzRsuAS3HCSAzL4yuW87ze56P+RITtUKFCh0BRDem3+tS16LAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 47473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/slider_shape01.10a1f01b.png","height":35,"width":33,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA8UlEQVR42jXLPyiEcRzH8U/RU1huOGU1mJ5FSpnIYlMmk8GC/Nm4ZELGK2W44RZJqavTlZwj9/SI69x2k5JiuTMwyuDuPL/vm2e41/SpT2/FyGj2vbT81rodg1BNq/ZuqKudXklR3+T7ZpJO1jdOhBUHsErfoWLuev3XmrtwqohjYWcJ97/d58USr/epRVlu2qjKyAvLeVAQXMpZIYlV9Cx2Bp86eZ+v4oyLTyt5WCC4ktmjb+JAC62jCT6CeUcoZ0E/9uBFlIXVp9qKsZ9MkxFWTkAtLkXjbpWo1rOlLrc9usbeSMOyw3A+9PITjs9J0h+fCZVS1V3QNwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 76257:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/slider_shape02.10a1f01b.png","height":35,"width":33,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA8UlEQVR42jXLPyiEcRzH8U/RU1huOGU1mJ5FSpnIYlMmk8GC/Nm4ZELGK2W44RZJqavTlZwj9/SI69x2k5JiuTMwyuDuPL/vm2e41/SpT2/FyGj2vbT81rodg1BNq/ZuqKudXklR3+T7ZpJO1jdOhBUHsErfoWLuev3XmrtwqohjYWcJ97/d58USr/epRVlu2qjKyAvLeVAQXMpZIYlV9Cx2Bp86eZ+v4oyLTyt5WCC4ktmjb+JAC62jCT6CeUcoZ0E/9uBFlIXVp9qKsZ9MkxFWTkAtLkXjbpWo1rOlLrc9usbeSMOyw3A+9PITjs9J0h+fCZVS1V3QNwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 31083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/slider_shape03.10a1f01b.png","height":35,"width":33,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA8UlEQVR42jXLPyiEcRzH8U/RU1huOGU1mJ5FSpnIYlMmk8GC/Nm4ZELGK2W44RZJqavTlZwj9/SI69x2k5JiuTMwyuDuPL/vm2e41/SpT2/FyGj2vbT81rodg1BNq/ZuqKudXklR3+T7ZpJO1jdOhBUHsErfoWLuev3XmrtwqohjYWcJ97/d58USr/epRVlu2qjKyAvLeVAQXMpZIYlV9Cx2Bp86eZ+v4oyLTyt5WCC4ktmjb+JAC62jCT6CeUcoZ0E/9uBFlIXVp9qKsZ9MkxFWTkAtLkXjbpWo1rOlLrc9usbeSMOyw3A+9PITjs9J0h+fCZVS1V3QNwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 16694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/slider_shape04.5f45a0c6.png","height":66,"width":61,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA3UlEQVR42iXJzSuDAQDH8V8ySWrJwcHVRfwFdlBycnD1D8hhOUh5ObGW2/4CeUloDl5aW0ptZPZwkJzlpZx3Uo9ijz2/r572uX6UaBWVbdYWQmpqu9F7wItSSnhvPR8/ZwlPM7DTb5+ncb3vspP1tRZvS7Ct2MdDcKToqzTHe2NjRb7ImEDmRPisByqySwP4Vh9is+v1pzzJb2UipiJcTcGV7GDUIqfl791ZwmAm4lr4Lh1zI/w0FSlBXmUOhe8HzaNoBvOED9NbSnwWct1eHd+nMNKmOBz+VccWJekf7l+FhhDbstIAAAAASUVORK5CYII=","blurWidth":7,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1697,7546,9232,6438,4323,4250,6410,1220], () => (__webpack_exec__(18631)));
module.exports = __webpack_exports__;

})();